<?php error_reporting(0);
            session_start();
            $servername = "localhost";
            $username = "root";
            $password = "";
            $conn = mysqli_connect($servername, $username, $password );
            if (!$conn){
                die("Sorry we failed to connect: " . mysqli_connect_error());
            }
                //echo "Connection was successful";

            $sql="SELECT * FROM `farmtech`.`tractor_lend`";
            $result = mysqli_query($conn, $sql);

            // setcookie('sno',10,time() + 3600);
            // session_start();


//             //$_SESSION['sno'] = $row['sno'];
//             if (isset($_GET['UEmail'])) {
// //                            $_SESSION['sno'] = $_GET['sno'];
//                 $UEmail = $_GET['UEmail'];
//             }
//             echo  "$UEmail";
?>
           

                    



<!Doctype html>
<HTML lang="en">
    <head>
        <style>
            body{
                margin:0px;
            }
            .button1 {
                position:absolute;
                right: 1125px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button2 {
                position:absolute;
                right: 950px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button3 {
                position:absolute;
                right: 765px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button4 {
                position:absolute;
                right:550px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button5 {
                position:absolute;
                right: 400px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button6 {
                position:absolute;
                right: 150px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button7 {
                position:absolute;  
                right: 0px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 125px;
            }
            .button8 {
                position:absolute;
                right:139px;
                cursor: pointer;
                margin-top: 35px;
            } 
            .button9 {
                position:absolute;
                right:8px;
                cursor: pointer;
                margin-top: 35px;
            }
            .button10 {
                position:absolute;  
                right: 10px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 20px;
            } 
            .Logo1 {
                height: 70px;
                width: 110px;
                margin:2px;
                margin-left:50px ;
                margin-top: 14px;
                border-radius: 20px;
                border:1px solid black;
                position: absolute;
            }
            header{
                background-color: aqua;
                height:100px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                margin-top:50px; 
            }
            .animate-charcter{
                text-transform: uppercase;
                background-image: linear-gradient(
                -225deg,
                #231557 0%,
                #44107a 29%,
                #ff1361 67%,
                #fff800 100%
                );
                background-size: auto auto;
                background-clip: border-box;
                background-size: 200% auto;
                color: #fff;
                background-clip: text;
                text-fill-color: transparent;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: textclip 2s linear infinite;
                display: inline-block;
                font-size: 28px;
                margin-top: 22px;
                margin-bottom: 10px;
                margin-left: 505px;
                position:absolute;
            }

            @keyframes textclip {
                to {
                background-position: 200% center;
                }
            }

            body {
                display: absolute;
                align-items: center;
                justify-content: center;
            }
            h1 {
                color: #160404;
                font-family: tahoma;
                font-size: 28px;
                font-weight 900px;
                text-transform: uppercase;
                overflow: hidden;
                position: absolute;
                width: 575px;
                margin-left: 575px;
                margin-top: 20px;
            }

            h1 span {
                font-size: 28px;
                margin-left: 115px;
                margin-top: 20px;
            }

            .message {
                background-color: rgb(244, 228, 84);
                color: #333;
                display: block;
                font-weight: 900px;
                overflow: hidden;
                font-size:28px;
                position: absolute;
                left: 350px;
                animation: openclose 5s ease-in-out infinite;
            }

            .word1, .word2, .word3 {
                font-family: tahoma;
            }

            @keyframes openclose {
                0% {
                    top: 0rem;
                    width: 0;
                }
                5% {
                    width: 40px;
                }
                15% {
                    width: 100px;
                }
                30% {
                    top: 0rem;
                    width: 160px;
                }
                33% {       
                    top: 0rem;
                    width: 0;
                }
                35% {
                    top: 0rem;
                    width: 0;
                }
                38% {
                top: -2.1rem;
    
                }
                48% {
                    top: -2.1rem;
                    width: 100px;
                }
                62% {
                    top: -2.1rem;
                    width: 200px;
                }
                66% {
                    top: -2.1rem;
                    width: 0;
                    text-indent: 0;
                }
                68% {
                    top: -2.1rem;   
                    width: 0;
                    text-indent: 0;
                }
                71% {
                    top: -4.2rem;
                    width: 0;
                }
                80% {
                    top: -4.2rem;
                    width: 100px;
                }
                95% {
                    top: -4.2rem;
                    width: 200px;
                }
                98% {
                    top: -4.2rem;
                    width: 0;
                }
                100% {
                    top: 0;
                    width: 0;
                }
                }   
                .homelogo {
                    height: 21px;
                    width: 21px;
                    border-radius: 20px;
                }
                .abtlogo{
                    height: 21px;
                    width: 21px;
                }
                .input{
                    width:500px;
                    height:25px;
                    float:right;
                    margin-right: 70px;
            }
            .H1{
                margin-left:25px;
                font-size:px;
                margin-top: 20px;
                margin: 0px;
            }
            .search{
                float:right;
                margin-top: 40px;
                margin-right: -47px;;
            }
            box{
                border:2px solid black;
            }
            .tractors{
                border:none;
                border:1px solid rgb(205, 204, 204);
                margin: 8px;
                padding: 0px;
                background-color: white;
                margin-left: 25px;
                margin-top: 55px;
            }
            main{
                margin-left: 25px;
                margin-top: 25px;;
            }
            .butimage{
                padding:0px;
                margin: 0px;
                height: 150px;
                width: 250px;
            }
            .book{
                background-color: rgb(71, 71, 245);
                height: 30px;
                margin-bottom: 0px;
                margin-top: 0px;
            }
            .book1{
                margin-bottom: 0px;;
                margin-top: -20px;
            }
            .text:hover{
                  color:red;
                  cursor:pointer;
            }
            button{
                cursor: pointer;
            }
            .book:hover
            {
                background-color: rgb(251, 41, 41);
            }

            @import url('https://fonts.googleapis.com/css2?family=Alfa+Slab+One&display=swap');
        .waviy {
                
                font-size: 20px;
                margin-top: -10x;

            }
            .waviy span {
                font-family: 'Alfa Slab One', simple;
                position: relative;
                display: inline-block;
                color: black;
                text-transform: uppercase;
                animation: waviy 1.25s infinite;
                animation-delay: calc(.1s * var(--i));
            }
            @keyframes waviy {
                0%,50%,100% {
                transform: translateY(0)
            }
                50% {
                transform: translateY(-20px)
            }
            }
            .ppprice{
                margin: 0px;
                font-size: 25px;
                color:rgb(251, 41, 41)
            }
            .HarButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }

            .Harvbar {
                
                right: 760px;
                position: absolute;
                display: inline-block;
            }

            .HarvContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .HarvContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .HarvContent a:hover {
                background-color: #ddd;
            }

            .Harvbar:hover .HarvContent {
                display: block;
            }

            .Harvbar:hover .HarButton {
                background-color: #3e8e41;
            }
            
            .ImpleButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Implebar {
                
                right: 550px;
                position: absolute;
                display: inline-block;
            }

            .ImpleContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .ImpleContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .ImpleContent a:hover {
                background-color: #ddd;
            }

            .Implebar:hover .ImpleContent {
                display: block;
            }

            .Implebar:hover .ImpleButton {
                background-color: #3e8e41;
            }

            .TracButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Tracbar {
                
                right: 400px;
                position: absolute;
                display: inline-block;
            }

            .TracContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .TracContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .TracContent a:hover {
                background-color: #ddd;
            }

            .Tracbar:hover .TracContent {
                display: block;
            }

            .Tracbar:hover .TracButton {
                background-color: #3e8e41;
            }

            .PlantButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Plantbar {
                
                right: 150px;
                position: absolute;
                display: inline-block;
            }

            .PlantContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .PlantContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .PlantContent a:hover {
                background-color: #ddd;
            }

            .Plantbar:hover .PlantContent {
                display: block;
            }

            .Plantbar:hover .PlantButton {
                background-color: #3e8e41;
            }
            .heading{
                margin-left: 627px;
                margin-top: 50px;
                font-size: x-large;
            }
            .a{
                text-decoration: none;
                color: white;
            }
            #land1{
                padding-left: 20px;
                padding-right: 20px;
            }
            .buttonland{
                margin-top: 0px;
                margin-left: 720px;
                padding: 15px;
                margin-bottom: -75px;
                background-color: #0088ff;
                border: none;
                color: white;
                border-radius: 5px;
            }
            .buttonland:hover{
                background-color:#ea570e;
            }
            hr{
                margin-left: 375px;
                margin-right: 375px;
                margin-top:100px ;
                margin-bottom: -20px;
                color: #44107a;
            }
            @import url('https://fonts.googleapis.com/css2?family=Alfa+Slab+One&display=swap');
        .waviy {
                
                font-size: 20px;
                margin-top: -10x;

            }
            .waviy span {
                font-family: 'Alfa Slab One', simple;
                position: relative;
                display: inline-block;
                color: black;
                text-transform: uppercase;
                animation: waviy 1.25s infinite;
                animation-delay: calc(.1s * var(--i));
            }
            @keyframes waviy {
                0%,50%,100% {
                transform: translateY(0)
            }
                50% {
                transform: translateY(-20px)
            }
            }
            .H1{
                margin-left:580px;
                font-size:px;
                margin-top: 20px;
            }
            .classbut{
                margin-top: 50px;
                margin-left:625px ;
            }
            .classbut1{
                margin-top: 50px;
            }
        </style>
        <meta charset="UTF-8">
        <title>
            Main Page
            </title>
            <link rel="icon" href="Logo.jpg">
        </head>
    <body>
            <div>
                <div>
                    <div">
                        <h3 class="animate-charcter"> Farm Tech:</h3>
                <h1>
                    <span>Lend/Borrow</span>
                    <div class="message">
                      <div class="word1">Tractors</div>
                      <div class="word2">Implements</div>
                      <div class="word3">Harvestors</div>
                    </div>
                  </h1>
                    </div>
                </div>
            </div>
            <a href="Login.php">
                <button class="button7" type="button">
                <b> 
                <font size="4" style="font-family:verdana">
                    Login
                </font>
                </b>
                </button>
            </a>&nbsp;
                        <a href="signin.php">
                <button class="button10" type="button">
                <b> 
                <font size="4" style="font-family:verdana">
                    Sign in
                </font>
                </b>
                </button>
            </a>&nbsp;  
            <header>
                <img src="../Images/Logo.jpg" alt="Logo.jpg" class="Logo1"/>
                <a href=../Home.html>
                    <button class="button1" type="button">
                    <img src="../Images/homelogo.jpg" class="homelogo">
                    <b>
                    <font size="5.75" style="font-family:verdana">
                        Home
                    </font><br>
                    </b>
                    </button>
                </a>&nbsp;
        
                <a href=AboutUS_without.html>
                    <button class="button2" type="button">
                    <img src="../Images/Abt.png" alt="Logo.jpg" class="abtlogo"/>
        
                    <b>
                    <font size="5.75" style="font-family:verdana">
                        About Us
                    </font>
                    </b>
                    </button>
                </a>&nbsp;
                <div class="Harvbar">
                <a href="harvester_without.php">
                    <button class="HarButton" type="button">
                    <img src="../Images/Harvestor.png" alt="Logo.jpg" class="abtlogo"/>
        
                    <b>
                    <font size="5.75" style="font-family:verdana">
                        Harvestor</font>
                    </b>
                    </button>
                    </a>&nbsp;
        
                    <div class="HarvContent">
                    <a href="harvester_without.php">Borrow</a>
                    <a href="harv_lend_1_without.php">Lend</a>
                </div>
                    </div>
                    <div class="Implebar">
                
                <a href="implements_without.php">
                    <button class="ImpleButton" type="button">
                    <img src="../Images/Implements.png" alt="Logo.jpg" class="abtlogo"/>
                    <b>
                    <font size="5.75" style="font-family:verdana">
                        Implements
                    </font>
                    </b>
                    </button>
                </a>&nbsp;
        
                <div class="ImpleContent">
                    <a href="Implements_without.php">Borrow</a>
                    <a href="imple_lend_1_without.php">Lend</a>
                </div>
                    </div>
                    <div class="Tracbar">
                <a href="tractor_without.php">
        
                    <button class="TracButton" type="button">
                    <img src="../Images/Tractor.png" alt="Logo.jpg" class="abtlogo"/>
                    <b>
                    <font size="5.75" style="font-family:verdana">
                        Tractor
                    </font>
                    </b>
                    </button>
                </a>&nbsp;
        
                    <div class="TracContent">
                        <a href="tractor_without.php">Borrow</a>
                        <a href="trac_lend_1_without.php">Lend</a>    
                    </div>
                        </div>
                        <div class="Plantbar">
        
                <a href="PlantNutrition_without.html">
        
                    <button class="PlantButton" type="button">
                    <img src="../Images/PlantNutrition.png" alt="Logo.jpg" class="abtlogo"/>
                    
            <b>
                <font size="5.75" style="font-family:verdana">
                    Plant Nutrition
                </font>
                </b>
                </button>
            </a>&nbsp;
            <div class="PlantContent">
                <a href="Soil Health_without.html">Soil Health</a>
                <a href="Soilissue_without.html">Soil Issue</a>
                <a href="Nutritions_without.html">Nutrients</a>
                <a href="Elements_without.html">Element</a>
                <a href="pesticides_without.html">Pesticides</a>
                <a href="Crops_without.html">Crops</a>    
                <a href="Plant Growth_without.html">Plant Growth</a>
                <a href="Preventation_without.html">Preventation</a>
            </div>
            </div> </header>
        <br>
        </header>
    <h1 class="H1">
                <div class="waviy">
                    <span style="--i:1">TRACTOR</span>
            </div>
            </h1>
        <main>
            
            <hr class="rl1">
            <p class="heading">Want to Lend your Tractor</p>
            <button class="buttonland" id="land1"><a href="trac_lend_1_without.php" class="a">LEND</a></button>
            <hr class="rl1">
            <form action="tractor_without.php" method="POST">
                <input type="text" name="Search" class="classbut" placeholder="Search Tractors">
                <input type="submit" name="submit" class="classbut1" placeholder="Search Tractors">
        </form>
        <?php
        if(isset($_POST['submit'])){
            $Search = $_POST['Search'];
            $sql="SELECT * FROM `farmtech`.`tractor_lend` where Company like '%$Search%' or Model like '%$Search%'";
            $result = mysqli_query($conn, $sql);
        }
        ?>
            <?php
           
            while($row=mysqli_fetch_assoc($result)){
                ?>

            
        <a href="Borrow_trac_without.php?sno=<?php echo $row['sno'];?>   ">

        
        <button class="tractors">
            <img src="../uploads/<?php echo $row["Images"]; ?>" class="butimage">
            <p class="text"><?php echo $row["Company"]; ?></p>
            <b><p class="ppprice">Rs <?php echo $row["Price"]; ?></p></b>
            <p class="text"><?php echo $row["Days"]; ?></p>
            <p class="book"><P class="book1">Book Now</p>
        </button> 
            </a>
        <?php

        }
            
            //echo $row["Images"];

        
        ?>
        </main>
        </body>
    </html>
