<?php error_reporting(0);



$servername = "localhost";
$username = "root";
$password = "";
// include_once "trac_lend_1.php";

$conn = mysqli_connect($servername, $username, $password );
if (!$conn){
    die("Sorry we failed to connect: " . mysqli_connect_error());
}


    $Company = $_POST['Company'];
    $ModelNO = $_POST['ModelNO'];
    $Year = $_POST['Year'];
$query = "Select MAX(sno) as maxx from `farmtech`.`tractor_lend`";
$ab = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($ab);
$Last_aa = $row['maxx'];

$or_query = "Select Model from `farmtech`.`tractor_lend` WHERE `sno` = $Last_aa";
$or_result = mysqli_query($conn, $or_query);
$or_data = mysqli_fetch_assoc($or_result);


$sql ="UPDATE `farmtech`.`tractor_lend` SET `Company` = '$Company' WHERE `sno` = $Last_aa";
$result = mysqli_query($conn, $sql);
$sql ="UPDATE `farmtech`.`tractor_lend` SET `Model` = '$ModelNO' Where `sno` = $Last_aa"; 
$result = mysqli_query($conn, $sql);
$sql ="UPDATE `farmtech`.`tractor_lend` SET `Year` = '$Year' Where `sno` = $Last_aa"; 
$result3 = mysqli_query($conn, $sql);

$new_query = "Select Model from `farmtech`.`tractor_lend` WHERE `sno` = $Last_aa";
$new_result = mysqli_query($conn, $new_query);
$new_data = mysqli_fetch_assoc($new_result);



if($or_data['Model'] !== $new_data['Model']){
    //echo"successfully inserted";
    header("Location: /PROFILE/Files/trac_lend_3_without.php");
}else{
    // echo"ERROR: $sql<br> $conn->error";
}










  

?>



<!Doctype html>
<HTML lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <script>
            function Com(val)
                {
                    switch (val)
                    {
                    case "Swaraj" :
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("855 FE","855 FE");
                        document.getElementById("ModelNO").options[2]=new Option("735 FE","735 FE");
                        document.getElementById("ModelNO").options[3]=new Option("744 FE","744 FE");
                        document.getElementById("ModelNO").options[4]=new Option("960 FE","960 FE");
                        document.getElementById("ModelNO").options[5]=new Option("Code","Code");
                        document.getElementById("ModelNO").options[6]=new Option("735 XT","735 XT");
                        document.getElementById("ModelNO").options[7]=new Option("963 FE","963 FE");
                        document.getElementById("ModelNO").options[8]=new Option("742 XT","742 XT");
                        document.getElementById("ModelNO").options[9]=new Option("855 FE 4WD","855 FE 4WD");
                        document.getElementById("ModelNO").options[10]=new Option("717","717");
                        document.getElementById("ModelNO").options[11]=new Option("744 FE 4WD","744 FE 4WD");
                        document.getElementById("ModelNO").options[12]=new Option("963 FE 4WD","963 FE 4WD");
                        document.getElementById("ModelNO").options[13]=new Option("834 XM","834 XM");
                        document.getElementById("ModelNO").options[14]=new Option("724 FE 4WD","724 FE 4WD");
                        document.getElementById("ModelNO").options[15]=new Option("855 DT Plus","855 DT Plus");
                        document.getElementById("ModelNO").options[16]=new Option("825 XM","825 XM");
                        document.getElementById("ModelNO").options[17]=new Option("969 FE","969 FE");
                        document.getElementById("ModelNO").options[17]=new Option("742 XM ORCHARD","742 XM ORCHARD");
                        document.getElementById("ModelNO").options[18]=new Option("742 FE","742 FE");
                        document.getElementById("ModelNO").options[19]=new Option("843 XM","843 XM");
                        document.getElementById("ModelNO").options[20]=new Option("724 XM","724 XM");
                        document.getElementById("ModelNO").options[21]=new Option("735 XM","735 XM");
                        document.getElementById("ModelNO").options[22]=new Option("724 XM ORCHARD NT","724 XM ORCHARD NT");
                        document.getElementById("ModelNO").options[23]=new Option("841 XM","841 XM");
                        document.getElementById("ModelNO").options[24]=new Option("744 XM","744 XM");
                        document.getElementById("ModelNO").options[25]=new Option("855 XM","855 XM");
                        document.getElementById("ModelNO").options[26]=new Option("843 XM-OSM","843 XM-OSM");
                        document.getElementById("ModelNO").options[27]=new Option("744 XM Potato Expert","744 XM Potato Expert");
                        break;
                    case "Massey Ferguson" :
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("1035 DI","1035 DI");
                        document.getElementById("ModelNO").options[2]=new Option("241 DI MAHA","241 DI MAHA");
                        document.getElementById("ModelNO").options[3]=new Option("245 DI","245 DI");
                        document.getElementById("ModelNO").options[4]=new Option("1035 DI MAHA SHAKTI","1035 DI MAHE SHAKTI");
                        document.getElementById("ModelNO").options[5]=new Option("7250 POWER UP","7250 POWER UP");
                        document.getElementById("ModelNO").options[6]=new Option("9500 SMART","9500 SMART");
                        document.getElementById("ModelNO").options[7]=new Option("1030 DI MAHA SHAKTI","1030 DI MAHA SHAKTI");
                        document.getElementById("ModelNO").options[8]=new Option("1035 DI PLANETARY PLUS","1035 DI PLANETARY PLUS");
                        document.getElementById("ModelNO").options[9]=new Option("8055 MAGNATRAK","8055 MAGNATRAK");
                        document.getElementById("ModelNO").options[10]=new Option("245 DI PLANETARY PLUS","245 DI PLANETARY PLUS");
                        document.getElementById("ModelNO").options[11]=new Option("246 DI DYNATRACK 4WD","246 DI DYNATRACK 4WD");
                        document.getElementById("ModelNO").options[12]=new Option("5118","5118");
                        document.getElementById("ModelNO").options[13]=new Option("241 DI PLANETARY PLUS","241 DI PLANETARY PLUS");
                        document.getElementById("ModelNO").options[14]=new Option("24 DI DYNATRACK","24 DI DYNATRACK");
                        document.getElementById("ModelNO").options[15]=new Option("9500 4WD","9500 4WD");
                        document.getElementById("ModelNO").options[16]=new Option("7250 POWER","7250 POWER");
                        document.getElementById("ModelNO").options[17]=new Option("1035 DI TONNER","1035 DI TONNER");
                        document.getElementById("ModelNO").options[18]=new Option("241 DI TONNER","241 DI TONNER");
                        document.getElementById("ModelNO").options[19]=new Option("241 R","241 R");
                        document.getElementById("ModelNO").options[20]=new Option("241 DI MAHAAN","241 DI MAHAAN");
                        document.getElementById("ModelNO").options[21]=new Option("6028 4WD","6028 4WD");
                        document.getElementById("ModelNO").options[22]=new Option("5245 DI 4WD","5245 DI 4WD");
                        document.getElementById("ModelNO").options[23]=new Option("9000 PLANETARY PLUS","9000 PLANETARY PLUS");
                        document.getElementById("ModelNO").options[24]=new Option("244 DI","244 DI");
                        document.getElementById("ModelNO").options[25]=new Option("246 DI DYNATRACK","246 DI DYNATRACK");
                        document.getElementById("ModelNO").options[26]=new Option("TAFE 30 DI ORCHARD PLUS","TAFE 30 DI ORCHARD PLUS");
                        document.getElementById("ModelNO").options[27]=new Option();
                        document.getElementById("ModelNO").options[28]=new Option();
                        document.getElementById("ModelNO").options[29]=new Option();
                        document.getElementById("ModelNO").options[27]=new Option();
                        document.getElementById("ModelNO").options[27]=new Option();
                        document.getElementById("ModelNO").options[27]=new Option();
                        document.getElementById("ModelNO").options[27]=new Option();
                        document.getElementById("ModelNO").options[27]=new Option(); 
                        break;
                    case "Mahindra" :
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("Arjun 555 DI","Arjun 555 DI");
                        document.getElementById("ModelNO").options[2]=new Option("575 DI XP Plus","575 DI XP Plus");
                        document.getElementById("ModelNO").options[3]=new Option("275 DI TU","275 DI TU");
                        document.getElementById("ModelNO").options[4]=new Option("265 DI","265 DI");
                        document.getElementById("ModelNO").options[5]=new Option("Arjun Novo 605 DI-I 2WD","Arjun Novo 605 DI-I 2WD");
                        document.getElementById("ModelNO").options[6]=new Option("475 DI","475 DI");
                        document.getElementById("ModelNO").options[7]=new Option("585 DI XP Plus","585 DI XP Plus");
                        document.getElementById("ModelNO").options[8]=new Option("Yuvraj 215 NXT","Yuvraj 215 NXT");
                        document.getElementById("ModelNO").options[9]=new Option("575 DI","575 DI");
                        document.getElementById("ModelNO").options[10]=new Option("JIVO 245 DI","JIVO 245 DI");
                        document.getElementById("ModelNO").options[11]=new Option("275 DI XP PLUS","275 DI XP PLUS");
                        document.getElementById("ModelNO").options[12]=new Option("JIVO 365 DI","JIVO 365 DI");
                        document.getElementById("ModelNO").options[13]=new Option("YUVO TECH Plus 275 DI","YUVO TECH Plus 275 DI");
                        document.getElementById("ModelNO").options[14]=new Option("YUVO TECH Plus 575","YUVO TECH Plus 575");
                        document.getElementById("ModelNO").options[15]=new Option("265 DI XP PLUS","265 DI XP PLUS");
                        document.getElementById("ModelNO").options[16]=new Option("Yuvo 475 DI","Yuvo 475 DI");
                        document.getElementById("ModelNO").options[17]=new Option("ARJUN NOVO 605 DI-i-4WD","ARJUN NOVO 605 DI-i-4WD");
                        document.getElementById("ModelNO").options[17]=new Option("YUVO TECH PLUS 475","YUVO TECH PLUS 475");
                        document.getElementById("ModelNO").options[18]=new Option("YUVO 575 DI 4WD","YUVO 575 DI 4WD");
                        document.getElementById("ModelNO").options[19]=new Option("265 DI POWERPLUS","265 DI POWERPLUS");
                        document.getElementById("ModelNO").options[20]=new Option("YUVO TECH PLUS 415 DI","YUVO TECH PLUS 415 DI");
                        document.getElementById("ModelNO").options[21]=new Option("YUVO 275 DI","YUVO 275 DI");
                        document.getElementById("ModelNO").options[22]=new Option("NOVO 755 DI","NOVO 755 DI");
                        document.getElementById("ModelNO").options[23]=new Option("ARJUN NOVO 605 DI-PS","ARJUN NOVO 605 DI-PS");
                        document.getElementById("ModelNO").options[24]=new Option("275 DI TU XP PLUS","275 DI TU XP PLUS");
                        document.getElementById("ModelNO").options[25]=new Option("ARJUN ULTRA 605 DI","ARJUN ULTRA 605 DI");
                        document.getElementById("ModelNO").options[26]=new Option("JIVO 225 DI 4WD","JIVO 225 DI 4WD");
                        document.getElementById("ModelNO").options[27]=new Option("YUVO TECH PLUS 575 4WD","YUVO TECH PLUS 575 4WD");
                        document.getElementById("ModelNO").options[28]=new Option("YUVO TECH PLUS 405 4WD","YUVO TECH PLUS 405 4WD");
                        document.getElementById("ModelNO").options[29]=new Option("NOVO 655 DI","NOVO 655 DI");
                        document.getElementById("ModelNO").options[30]=new Option("255 DI POWERPLUS","255 DI POWERPLUS");
                        document.getElementById("ModelNO").options[31]=new Option("585 DI POWERPLUS BP","585 DI POWERPLUS BP");
                        document.getElementById("ModelNO").options[32]=new Option("YUVO 585 MAT","YUVO 585 MAT");
                        document.getElementById("ModelNO").options[33]=new Option("575 DI SP PLUS","575 DI SP PLUS");
                        document.getElementById("ModelNO").options[34]=new Option("475 DI SP PLUS","475 DI SP PLUS");
                        document.getElementById("ModelNO").options[35]=new Option("ARJUN 605 DI PP DLX","ARJUN 605 DI PP DLX");
                        document.getElementById("ModelNO").options[36]=new Option("415 DI SP PLUS","415 DI SP PLUS");
                        document.getElementById("ModelNO").options[37]=new Option("275 DI TU PLUS","275 DI TU PLUS");
                        document.getElementById("ModelNO").options[38]=new Option("415 DI","415 DI");
                        document.getElementById("ModelNO").options[39]=new Option("585 DI SARPANCH","585 DI SARPANCH");
                        document.getElementById("ModelNO").options[40]=new Option("415 DI XP PLUS","415 DI XP PLUS");
                        document.getElementById("ModelNO").options[41]=new Option("ARJUN NOVO 605 DI-i-WITH AC CABIN","ARJUN NOVO 605 DI-i-WITH AC CABIN");
                        document.getElementById("ModelNO").options[42]=new Option("JIVO 305 DI","JIVO 305 DI");
                        document.getElementById("ModelNO").options[43]=new Option("YUVO 575 DI","YUVO 575 DI");
                        document.getElementById("ModelNO").options[44]=new Option("YUVO TECH PLUS 585","YUVO TECH PLUS 585");
                        document.getElementById("ModelNO").options[45]=new Option("YUVO 265 DI","YUVO 265 DI");
                        document.getElementById("ModelNO").options[46]=new Option("275 DI ECO","275 DI ECO");
                        document.getElementById("ModelNO").options[47]=new Option("595 DI TURBO","595 DI TURBO");
                        document.getElementById("ModelNO").options[48]=new Option("475 DI XP PLUS MS","475 DI XP PLUS MS");
                        document.getElementById("ModelNO").options[49]=new Option("YUVO 415 DI","YUVO 415 DI");
                        document.getElementById("ModelNO").options[50]=new Option("275 DI SP PLUS","275 DI SP PLUS");
                        document.getElementById("ModelNO").options[51]=new Option("JIVO 245 VINEYARD","JIVO 245 VINEYARD");
                        break;
                    
                    case "John Deere" :
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("5310","5310");
                        document.getElementById("ModelNO").options[2]=new Option("5405 GearPro","5405 GearPro");
                        document.getElementById("ModelNO").options[3]=new Option("5050 D","5050 D");
                        document.getElementById("ModelNO").options[4]=new Option("5210","5210");
                        document.getElementById("ModelNO").options[5]=new Option("5105","5105");
                        document.getElementById("ModelNO").options[6]=new Option("5045 D","5045 D");
                        document.getElementById("ModelNO").options[7]=new Option("5310 4WD","5310 4WD");
                        document.getElementById("ModelNO").options[8]=new Option("5050 D-4WD","5050 D-4WD");
                        document.getElementById("ModelNO").options[9]=new Option("5042 D-4WD","5042 D-4WD");
                        document.getElementById("ModelNO").options[10]=new Option("5042 d PowerPro","5042 d PowerPro");
                        document.getElementById("ModelNO").options[11]=new Option("5036 D","5036 D");
                        document.getElementById("ModelNO").options[12]=new Option("5405 Trem IV-4WD","5405 Trem IV-4WD");
                        document.getElementById("ModelNO").options[13]=new Option("5045 D 4WD","5045 D 4WD");
                        document.getElementById("ModelNO").options[14]=new Option("5210 GearPro","5210 GearPro");
                        document.getElementById("ModelNO").options[15]=new Option("5042 D","5042 D");
                        document.getElementById("ModelNO").options[16]=new Option("5039 D","5039 D");
                        document.getElementById("ModelNO").options[17]=new Option("6210 B","6210 B");
                        document.getElementById("ModelNO").options[17]=new Option("5050 E","5050 E");
                        document.getElementById("ModelNO").options[18]=new Option("YUVO 575 DI 4WD","YUVO 575 DI 4WD");
                        document.getElementById("ModelNO").options[19]=new Option("3028 EN","3028 EN");
                        document.getElementById("ModelNO").options[20]=new Option("5310 Perma Clutch","5310 Perma Clutch");
                        document.getElementById("ModelNO").options[21]=new Option("5205","5205");
                        document.getElementById("ModelNO").options[22]=new Option("5310 Trem IV-4WD","5310 Trem IV-4WD");
                        document.getElementById("ModelNO").options[23]=new Option("5075E-4WD","5075E-4WD");
                        document.getElementById("ModelNO").options[24]=new Option("5105 4WD","5105 4WD");
                        document.getElementById("ModelNO").options[25]=new Option("5305","5305");
                        document.getElementById("ModelNO").options[26]=new Option("6110 B","6110 B");
                        document.getElementById("ModelNO").options[27]=new Option("5060 E -4WD AC Cabin","5060 E -4WD AC Cabin");
                        document.getElementById("ModelNO").options[28]=new Option("5055 E","5055 E");
                        document.getElementById("ModelNO").options[29]=new Option("3036 E","3036 E");
                        document.getElementById("ModelNO").options[30]=new Option("5060 E-WD","5060 E-WD");
                        document.getElementById("ModelNO").options[31]=new Option("5038 D PowerPro","5038 D PowerPro");
                        document.getElementById("ModelNO").options[32]=new Option("5310 GearPro 4WD","5310 GearPro 4WD");
                        document.getElementById("ModelNO").options[33]=new Option("3036 EN","3036 EN");
                        document.getElementById("ModelNO").options[34]=new Option("5055 E 4WD","5055 E 4WD");
                        document.getElementById("ModelNO").options[35]=new Option("5055 E 4WD","5065 E 4WD");
                        document.getElementById("ModelNO").options[36]=new Option("5060 E","5060 E");
                        document.getElementById("ModelNO").options[37]=new Option("5310 GearPro","5310 GearPro");
                        document.getElementById("ModelNO").options[38]=new Option("5405 TremIV","5405 TremIV");
                        document.getElementById("ModelNO").options[39]=new Option("5075E Trem IV-WD","5075E Trem IV-WD");
                        document.getElementById("ModelNO").options[40]=new Option("5075E 4WD AC CABIN","5075E 4WD AC CABIN");
                        document.getElementById("ModelNO").options[41]=new Option("5065E 4WD AC CABIN","5065E 4WD AC CABIN");
                        document.getElementById("ModelNO").options[42]=new Option("5065 E","5065 E");
                        document.getElementById("ModelNO").options[43]=new Option("5305 TremIV","5305 TremIV");
                        document.getElementById("ModelNO").options[44]=new Option("5310 TremIV","5310 TremIV");
                        document.getElementById("ModelNO").options[45]=new Option("5075E-TremIV","5075E-TremIV");
                        document.getElementById("ModelNO").options[46]=new Option("5310 PowerTech 4WD","5310 PowerTech 4WD");
                        break;

                    case "Sonalika" :
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("SIKANDER DI 55 DLX","SIKANDER DI 55 DLX");
                        document.getElementById("ModelNO").options[2]=new Option("WT 60","WT 60");
                        document.getElementById("ModelNO").options[3]=new Option("SIKANDER DI 35","SIKANDER DI 35");
                        document.getElementById("ModelNO").options[4]=new Option("TIGER 50","TIGER 50");
                        document.getElementById("ModelNO").options[5]=new Option("GT 20","GT 20");
                        document.getElementById("ModelNO").options[6]=new Option("42 RX SIKANDER","42 RX SIKANDER");
                        document.getElementById("ModelNO").options[7]=new Option("42 DI SIKANDER","42 DI SIKANDER");
                        document.getElementById("ModelNO").options[8]=new Option("DI 750lll","DI 750lll");
                        document.getElementById("ModelNO").options[9]=new Option("50RX SIKANDER","50RX SIKANDER");
                        document.getElementById("ModelNO").options[10]=new Option("DI 35","DI 35");
                        document.getElementById("ModelNO").options[11]=new Option("MM-18","MM-18");
                        document.getElementById("ModelNO").options[12]=new Option("TIGER ELECTRIC","TIGER ELECRIC");
                        document.getElementById("ModelNO").options[13]=new Option("DI 745lll MAHARAJA","DI 745lll MAHARAJA");
                        document.getElementById("ModelNO").options[14]=new Option("Worldtrac 90 Rx 4WD","Worldtrac 90 Rx 4WD");
                        document.getElementById("ModelNO").options[15]=new Option("DI 60","DI 60");
                        document.getElementById("ModelNO").options[16]=new Option("DI 35 RX","DI 60 RX");
                        document.getElementById("ModelNO").options[17]=new Option("35 RX Sikander","35 RX Sikander");
                        document.getElementById("ModelNO").options[18]=new Option("DI 50 RX","DI 50 RX");
                        document.getElementById("ModelNO").options[19]=new Option("DI 750 lll s3","DI 750 lll s3");
                        document.getElementById("ModelNO").options[20]=new Option("DI 745 lll","DI 745 lll");
                        document.getElementById("ModelNO").options[21]=new Option("DI 50 DLX","DI 50 DLX");
                        document.getElementById("ModelNO").options[22]=new Option("TIGER 60","TIGER 60");
                        document.getElementById("ModelNO").options[23]=new Option("DI 42 RX","DI 42 RX");
                        document.getElementById("ModelNO").options[24]=new Option("DI 47 RX","DI 47 RX");
                        document.getElementById("ModelNO").options[25]=new Option("DI 30 BAAGBAN SUPER","DI 30 BAAGBAN SUPER");
                        document.getElementById("ModelNO").options[26]=new Option("Sikander DI 55 DLX 4WD","Sikander DI 55 DLX 4WD");
                        document.getElementById("ModelNO").options[27]=new Option("TIGER 47","TIGER 47");
                        document.getElementById("ModelNO").options[28]=new Option("GT 22","GT 22");
                        document.getElementById("ModelNO").options[29]=new Option("DI 745 DLX","DI 745 DLX");
                        document.getElementById("ModelNO").options[30]=new Option("DI 734 POWER PLUS","DI 734 POWER PLUS");
                        document.getElementById("ModelNO").options[31]=new Option("DI 30 RX BAGBAN SUPER ","DI 30 RX BAGBAN SUPER ");
                        document.getElementById("ModelNO").options[32]=new Option("DI 750 SIKANDER","DI 750 SIKANDER",);
                        document.getElementById("ModelNO").options[33]=new Option("47 RX SIKANDER","47 RX SIKANDER");
                        document.getElementById("ModelNO").options[34]=new Option("DI 50 SIKANDER","DI 50 SIKANDER");
                        document.getElementById("ModelNO").options[35]=new Option("DI  750 lll RX SIKANDER ","DI  750 lll RX SIKANDER ");
                        document.getElementById("ModelNO").options[36]=new Option("DI 750 lll DLX","DI 750 lll DLX");
                        document.getElementById("ModelNO").options[37]=new Option("GT 26","GT 26");
                        document.getElementById("ModelNO").options[38]=new Option("TIGER 55 ","TIGER 55 ");
                        document.getElementById("ModelNO").options[39]=new Option("RX 55 DLX","RX 55 DLX");
                        document.getElementById("ModelNO").options[40]=new Option("TIGER 26", "TIGER 26 ");
                        document.getElementById("ModelNO").options[41]=new Option("DI 32 BAAGBAN ","DI 32 BAAGBAN ");
                        document.getElementById("ModelNO").options[42]=new Option("MM 35 DI","MM 35 DI");
                        document.getElementById("ModelNO").options[43]=new Option("DI 734 (S1)","DI 734 (S1)");
                        document.getElementById("ModelNO").options[44]=new Option("DI 60 MM SUPER ","DI 60 MM SUPER ");
                        document.getElementById("ModelNO").options[45]=new Option("DI 60 SIKANDER","DI 60 MM SUPER ");
                        document.getElementById("ModelNO").options[46]=new Option("WT 60 RX SIKANDER  ","WT 60 RX SIKANDER  ");
                        document.getElementById("ModelNO").options[47]=new Option("RX 60 DLX ","RX 60 DLX");
                        document.getElementById("ModelNO").options[48]=new Option("RX 750 lll DLX","RX 750 lll DLX");
                        document.getElementById("ModelNO").options[49]=new Option("MM+ 39 DI","MM+ 39 DI");
                        document.getElementById("ModelNO").options[50]=new Option("MM+ 41 DI" ,"MM+ 41 DI");
                        document.getElementById("ModelNO").options[51]=new Option("RX 42 MAHABALI ","RX 42 MAHABALI ");
                        document.getElementById("ModelNO").options[52]=new Option("SIKANDER WORLDTAC 60 ","SIKANDER WORLDTAC 60 ");
                        document.getElementById("ModelNO").options[53]=new Option("DI 60 4WD ","DI 60 4WD ");
                        document.getElementById("ModelNO").options[54]=new Option("TIGER DI 65 4WD ","TIGER DI 65 4WD ");
                        document.getElementById("ModelNO").options[55]=new Option("DI 60 RX","DI 60 RX");
                        document.getElementById("ModelNO").options[56]=new Option("TIGER DI 75 ","TIGER DI 75 ");
                        document.getElementById("ModelNO").options[57]=new Option("TIGER DI 75 4WD " ,"TIGER DI 75 4WD ");
                        document.getElementById("ModelNO").options[58]=new Option("DI 42 POWER PLUS","DI 42 POWER PLUS");
                        document.getElementById("ModelNO").options[59]=new Option("DI 30 BAAGBAN","DI 30 BAAGBAN");
                        document.getElementById("ModelNO").options[60]=new Option("DI-60MM SUPER RX ","DI-60MM SUPER RX ");
                        document.getElementById("ModelNO").options[61]=new Option("DI 750 lll MULTI SPEED DLX","DI 750 lll MULTI SPEED DLX");
                        document.getElementById("ModelNO").options[62]=new Option("60 RX SIKANDER ","60 RX SIKANDER ");
                        document.getElementById("ModelNO").options[63]=new Option("DI 60 DLX ","DI 60 DLX");
                        document.getElementById("ModelNO").options[64]=new Option("MM+ 45 DI ","MM+ 45 DI ");
                        document.getElementById("ModelNO").options[65]=new Option("MM+ 50 ","MM+ 50 ");
                        document.getElementById("ModelNO").options[66]=new Option("RX 47 MAHABALI ","RX 47 MAHABALI ");
                        document.getElementById("ModelNO").options[67]=new Option("TIGER DI 65","TIGER DI 65");
                        document.getElementById("ModelNO").options[68]=new Option("DI 60 RX- 4WD ","DI 60 RX- 4WD ");
                        document.getElementById("ModelNO").options[69]=new Option("WORLDTRAC 75 RX 2WD / 4WD","WORLDTRAC 75 RX 2WD / 4WD");
                        document.getElementById("ModelNO").options[70]=new Option("745 DI lll SIKANDER","745 DI lll SIKANDER");
                        break;
                    case "New Holland" : 
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("3230 NX","3230 NX");
                        document.getElementById("ModelNO").options[2]=new Option("3630 TX Plus","3630 TX Plus");
                        document.getElementById("ModelNO").options[3]=new Option("3630 Tx Special Edition","3630 Tx Special Edition ");
                        document.getElementById("ModelNO").options[4]=new Option("3600 -2 TX All Rounder Plus","3600 -2 TX All Rounder Plus ");
                        document.getElementById("ModelNO").options[5]=new Option("3600 Tx Heritage Edition","3600 Tx Heritage Edition ");
                        document.getElementById("ModelNO").options[6]=new Option("3032 Nx","3032 Nx ");
                        document.getElementById("ModelNO").options[7]=new Option("3037 TX","3037 TX ");
                        document.getElementById("ModelNO").options[8]=new Option("3600-2TX","3600-2TX ");
                        document.getElementById("ModelNO").options[9]=new Option("3230 TX Super","3230 TX Super ");
                        document.getElementById("ModelNO").options[10]=new Option("5630 Tx Plus 4WD","5630 Tx Plus 4WD ");
                        document.getElementById("ModelNO").options[11]=new Option("Excel 4710"," Excel 4710");
                        document.getElementById("ModelNO").options[12]=new Option("3630 TX Super Plus +","3630 TX Super Plus +");
                        document.getElementById("ModelNO").options[13]=new Option("5620 Tx Plus","5620 Tx Plus ");
                        document.getElementById("ModelNO").options[14]=new Option("3630-TX Super"," 3630-TX Super ");
                        document.getElementById("ModelNO").options[15]=new Option("3600-2 Excel","3600-2 Excel");
                        document.getElementById("ModelNO").options[16]=new Option("5500 Turbo Super","5500 Turbo Super ");
                        document.getElementById("ModelNO").options[17]=new Option("5620 TX Plus CRDI","5620 TX Plus CRDI ");
                        document.getElementById("ModelNO").options[17]=new Option("Simba 30"," Simba 30 ");
                        document.getElementById("ModelNO").options[18]=new Option("TD 5.90","TD 5.90");
                        document.getElementById("ModelNO").options[19]=new Option("Excel 6010","Excel 6010 ");
                        document.getElementById("ModelNO").options[20]=new Option("Excel 9010","Excel 9010 ");
                        document.getElementById("ModelNO").options[21]=new Option("3600-2 TX All Rounder Plus 4 WD ","3600-2 TX All Rounder Plus 4 WD ");
                        document.getElementById("ModelNO").options[22]=new Option("3600 Tx Super Heritage Edition","3600 Tx Super Heritage Edition ");
                        document.getElementById("ModelNO").options[23]=new Option("3600-2 Tx Super","3600-2 Tx Super ");
                        document.getElementById("ModelNO").options[24]=new Option("6510","6510");
                        document.getElementById("ModelNO").options[25]=new Option("Excel 4710 Red"," Excel 4710 Red");
                        document.getElementById("ModelNO").options[26]=new Option("3630 TX Super Plus+ 4 WD","3630 TX Super Plus+ 4 WD");
                        document.getElementById("ModelNO").options[27]=new Option("4710 Turbo Super","4710 Turbo Super ");
                        document.getElementById("ModelNO").options[28]=new Option("Excel 4710 Paddy Special"," Excel 4710 Paddy Special ");
                        document.getElementById("ModelNO").options[29]=new Option("Excel 5510"," Excel 5510");
                        document.getElementById("ModelNO").options[30]=new Option("4510","4510");
                        document.getElementById("ModelNO").options[31]=new Option("5630 Tx Plus","5630 Tx Plus ");
                        document.getElementById("ModelNO").options[32]=new Option("3037 NX","3037 NX ");
                        document.getElementById("ModelNO").options[33]=new Option("4710 2WD WITH CANOPY","4710 2WD WITH CANOPY ");
                        document.getElementById("ModelNO").options[34]=new Option("7500 Turbo Super 2WD","7500 Turbo Super 2WD ");
                        document.getElementById("ModelNO").options[35]=new Option("6500 Turbo Super","6500 Turbo Super ");
                        document.getElementById("ModelNO").options[36]=new Option("7500 Turbo Super","7500 Turbo super");
                        document.getElementById("ModelNO").options[37]=new Option("Excel 6010 2WD"," Excel 6010 2WD ");
                        document.getElementById("ModelNO").options[38]=new Option("7510","7510");
                        document.getElementById("ModelNO").options[39]=new Option("5500 Turbo Super 2WD","5500 Turbo Super 2WD ");
                        document.getElementById("ModelNO").options[40]=new Option("3230 TX","3230 TX ");
                        document.getElementById("ModelNO").options[41]=new Option("3510","3510 ");
                        document.getElementById("ModelNO").options[42]=new Option("4010","4010 ");
                        document.getElementById("ModelNO").options[43]=new Option("Excel 9010 2Wd"," Excel 9010 2Wd ");
                        document.getElementById("ModelNO").options[44]=new Option("Excel 8010 2Wd "," Excel 8010 2Wd ");
                        document.getElementById("ModelNO").options[45]=new Option("Excel 5510 2Wd "," Excel 5510 2Wd ");
                        document.getElementById("ModelNO").options[46]=new Option("Excel 8010"," Excel 8010");
                        document.getElementById("ModelNO").options[47]=new Option("3230 TX 2WD","3230 TX 2WD ");
                        document.getElementById("ModelNO").options[48]=new Option("3037 TX Super","3037 TX Super ");
                        document.getElementById("ModelNO").options[49]=new Option("3037 TX Super 4WD","3037 TX Super 4WD ");
                        document.getElementById("ModelNO").options[50]=new Option("6500 Turbo Super 2WD","6500 Turbo Super 2WD ");
                        break;
                    case "PowerTrac" : 
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("Euro 439","Euro 439");
                        document.getElementById("ModelNO").options[2]=new Option("Euro 55 Next","Euro 55 Next");
                        document.getElementById("ModelNO").options[3]=new Option("Euro 50","Euro 50");
                        document.getElementById("ModelNO").options[4]=new Option("Euro 45","Euro 45");
                        document.getElementById("ModelNO").options[5]=new Option("439 Plus","439 Plus");
                        document.getElementById("ModelNO").options[6]=new Option("434","434");
                        document.getElementById("ModelNO").options[7]=new Option("425 N","425 N");
                        document.getElementById("ModelNO").options[8]=new Option("Euro 50 Next","Euro 50 Next");
                        document.getElementById("ModelNO").options[9]=new Option("Euro 47 PowerHouse","Euro 47 PowerHouse");
                        document.getElementById("ModelNO").options[10]=new Option("Euro 42 Plus","Euro 42 Plus");
                        document.getElementById("ModelNO").options[11]=new Option("Euro 55","Euro 55");
                        break;
                    case "Farmtrac" : 
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("45 Powermax","45 Powermax");
                        document.getElementById("ModelNO").options[2]=new Option("60 Powermax","60 Powermax");
                        document.getElementById("ModelNO").options[3]=new Option("6055 Powermax","6055 Powermax");
                        document.getElementById("ModelNO").options[4]=new Option("Champion 35 All Rounder","Champion 35 All Rounder");
                        document.getElementById("ModelNO").options[5]=new Option("60","60");
                        document.getElementById("ModelNO").options[6]=new Option("45","45");
                        document.getElementById("ModelNO").options[7]=new Option("60 EPI T20","60 EPI T20");
                        document.getElementById("ModelNO").options[8]=new Option("Atom 26","Atom 26");
                        document.getElementById("ModelNO").options[9]=new Option("60 Powermaxx T20","60 Powermaxx T20");
                        document.getElementById("ModelNO").options[10]=new Option("50 Powermaxx T20","50 Powermaxx T20");
                        document.getElementById("ModelNO").options[11]=new Option("45 Classic Supermaxx","45 Classic Supermaxx");
                        break;
                    case "Eicher" : 
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("380","485");
                        document.getElementById("ModelNO").options[2]=new Option("241","241");
                        document.getElementById("ModelNO").options[3]=new Option("333","333");
                        document.getElementById("ModelNO").options[4]=new Option("242","242");
                        document.getElementById("ModelNO").options[5]=new Option("380 Super Power","380 Super Power");
                        document.getElementById("ModelNO").options[6]=new Option("557","557");
                        document.getElementById("ModelNO").options[7]=new Option("485 Super Plus","485 Super Plus");
                        document.getElementById("ModelNO").options[8]=new Option("368","368");
                        document.getElementById("ModelNO").options[9]=new Option("551","551");
                        document.getElementById("ModelNO").options[10]=new Option("480","480");
                        document.getElementById("ModelNO").options[11]=new Option("650 4WD","650 4WD");
                        break;
                    case "Kartar" : 
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("5936","5936");
                        document.getElementById("ModelNO").options[2]=new Option("4036","4036");
                        document.getElementById("ModelNO").options[3]=new Option("5936 2 WD","5936 2 WD");
                        document.getElementById("ModelNO").options[4]=new Option("5036 4WD","5036 4WD");
                        document.getElementById("ModelNO").options[5]=new Option("4536","4536");
                        document.getElementById("ModelNO").options[6]=new Option("5136 Plus","5136 Plus");
                        document.getElementById("ModelNO").options[7]=new Option("5136","5136");
                        document.getElementById("ModelNO").options[8]=new Option("5036","5036");
                        document.getElementById("ModelNO").options[9]=new Option("5136 CR","5136 CR");
                        document.getElementById("ModelNO").options[10]=new Option("4536 Plus","4536 Plus");
                        break;
                    case "PowerTrac" : 
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("MU 4501 2WD","MU 4501 2WD");
                        document.getElementById("ModelNO").options[2]=new Option("MU 5501","MU 5501");
                        document.getElementById("ModelNO").options[3]=new Option("MU 5502 2WD","MU 5502 2WD");
                        document.getElementById("ModelNO").options[4]=new Option("MU 5502 4WD","MU 5502 4WD");
                        document.getElementById("ModelNO").options[5]=new Option("MU 4501 4WD","MU 4501 4WD");
                        document.getElementById("ModelNO").options[6]=new Option("NeoStar B2741S 4WD","NeoStar B2741S 4WD");
                        document.getElementById("ModelNO").options[7]=new Option("A211N-OP","A211N-OP");
                        document.getElementById("ModelNO").options[8]=new Option("NeoStar A211N 4WD","NeoStar A211N 4WD");
                        document.getElementById("ModelNO").options[9]=new Option("L3408","L3408");
                        document.getElementById("ModelNO").options[10]=new Option("L4508","L4508");
                        document.getElementById("ModelNO").options[11]=new Option("MU 5501 4WD","MU 5501 4WD");
                        break;
                    case "PowerTrac" : 
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("VT 180D HS/JAI-4D Tractor","VT 180D HS/JAI-4D Tractor");
                        document.getElementById("ModelNO").options[2]=new Option("MT 270 - VIRAAT 4WD","MT 270 - VIRAAT 4WD");
                        document.getElementById("ModelNO").options[3]=new Option("932","932");
                        document.getElementById("ModelNO").options[4]=new Option("MT180d/JAI-2W","MT180d/JAI-2W");
                        document.getElementById("ModelNO").options[5]=new Option("927","927");
                        document.getElementById("ModelNO").options[6]=new Option("MT 270 - VIRAAT 4WD Plus","MT 270 - VIRAAT 4WD Plus");
                        document.getElementById("ModelNO").options[7]=new Option("VT 224-1D","VT 224-1D");
                        document.getElementById("ModelNO").options[8]=new Option("Viraaj XT 9045 DI","Viraaj XT 9045 DI");
                        document.getElementById("ModelNO").options[9]=new Option("5011 Pro","5011 Pro");
                        document.getElementById("ModelNO").options[10]=new Option("MT 171 DI - SAMRAAT","MT 171 DI - SAMRAAT");
                        document.getElementById("ModelNO").options[11]=new Option("MT 270 High Torque","MT 270 High Torque");
                        break;
                    case "Standard" :
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("DI 335"," DI 335");
                        document.getElementById("ModelNO").options[2]=new Option("DI 450"," DI 450");
                        document.getElementById("ModelNO").options[3]=new Option("DI 460"," DI 460");
                        document.getElementById("ModelNO").options[4]=new Option("DI 345"," DI 345");
                        document.getElementById("ModelNO").options[5]=new Option("DI 355"," DI 355");
                        document.getElementById("ModelNO").options[6]=new Option("DI 475"," DI 475");
                        document.getElementById("ModelNO").options[7]=new Option("DI 490"," DI 490");
                        break;
                    case "ACE" :
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("DI 6500","DI 6500");
                        document.getElementById("ModelNO").options[2]=new Option("DI-350NG","DI-350NG");
                        document.getElementById("ModelNO").options[3]=new Option("DI-550 STAR"," DI-550 STAR ");
                        document.getElementById("ModelNO").options[4]=new Option("DI-450 NG","DI- 450 NG ");
                        document.getElementById("ModelNO").options[5]=new Option("DI- 450 NG 4WD","  DI- 450 NG 4WD ");
                        document.getElementById("ModelNO").options[6]=new Option("DI-854 NG"," DI-854 NG ");
                        document.getElementById("ModelNO").options[7]=new Option("DI 550 NG"," DI 550 NG");
                        document.getElementById("ModelNO").options[8]=new Option("DI 9000 4WD"," DI 9000 4WD ");
                        document.getElementById("ModelNO").options[9]=new Option("DI 7575"," DI 7575");
                        document.getElementById("ModelNO").options[10]=new Option("DI 6500 4WD"," DI 6500 4WD ");
                        document.getElementById("ModelNO").options[11]=new Option("DI 550 NG 4WD"," DI 550 NG 4WD ");
                        break;
                    case "Autonxt" :
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("X45H2"," X45H2");
                        document.getElementById("ModelNO").options[2]=new Option("X20H4"," X20H4 ");
                        document.getElementById("ModelNO").options[3]=new Option("X35H2"," X35H2");
                        break;
                    case "Cellestial" :
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("55HP","55HP");
                        document.getElementById("ModelNO").options[2]=new Option("35HP","35HP");
                        document.getElementById("ModelNO").options[3]=new Option("27HP","27HP");
                        break;
                    case "Escorts" :
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("Steeltrac"," Steeltrac ");
                        break;
                    case "HAV" :
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("50 S1","50 S1");
                        document.getElementById("ModelNO").options[2]=new Option("45 S1","45 S1");
                        document.getElementById("ModelNO").options[3]=new Option("50 S2 Cng Hybrid","50 S2 Cng Hybrid ");
                        document.getElementById("ModelNO").options[4]=new Option("50 S1 Plus","50 S1 Plus ");
                        document.getElementById("ModelNO").options[5]=new Option("55 S1 Plus","55 S1 Plus ");
                        document.getElementById("ModelNO").options[6]=new Option("55 S1","55 S1");
                        break;
                    case "Valdo" :
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("939 -SDI","939 -SDI ");
                        document.getElementById("ModelNO").options[2]=new Option("945 - SDI"," 945 - SDI ");
                        document.getElementById("ModelNO").options[3]=new Option("950 -SDI","950- SDI");
                        break;
                    case "Trakstar" :
                        document.getElementById("ModelNO").options[0]=new Option("Select Model","");
                        document.getElementById("ModelNO").options[1]=new Option("536"," 536");
                        document.getElementById("ModelNO").options[2]=new Option("540","540");
                        document.getElementById("ModelNO").options[3]=new Option("545"," 545");
                        document.getElementById("ModelNO").options[4]=new Option("550"," 550");
                        document.getElementById("ModelNO").options[5]=new Option(" 450","  450");
                        document.getElementById("ModelNO").options[6]=new Option("531"," 531");
                        break;
                    case "Captain" :
                        document.getElementById("ModelNO").options[0]=new Option("SELECT MODEL","");
                        document.getElementById("ModelNO").options[1]=new Option("283 4WD- 8G","283 4WD- 8G");
                        document.getElementById("ModelNO").options[2]=new Option("263 4WD- 8G","263 4WD- 8G");
                        document.getElementById("ModelNO").options[3]=new Option("200 DI","200 DI");
                        document.getElementById("ModelNO").options[4]=new Option("200 DI-4WD","200 DI-4WD");
                        document.getElementById("ModelNO").options[5]=new Option("250 DI-4WD","250 DI-4WD");
                        document.getElementById("ModelNO").options[6]=new Option("280 DI","280 DI");
                        document.getElementById("ModelNO").options[7]=new Option("250 DI","250 DI");
                        document.getElementById("ModelNO").options[8]=new Option("280 4 WD","280 4 WD");
                        break;
                    case "Hindustan":
                        document.getElementById("ModelNO").options[0]=new Option("SELECT MODEL","");
                        document.getElementById("ModelNO").options[1]=new Option("60","60");
                        break;
                    case "Force":
                        document.getElementById("ModelNO").options[0]=new Option("SELECT MODEL","");
                        document.getElementById("ModelNO").options[1]=new Option("ORCHARD MINI","ORCHARD MINI");
                        document.getElementById("ModelNO").options[2]=new Option("ORCHARD DLX LT","ORCHARD DLX LT");
                        document.getElementById("ModelNO").options[3]=new Option("BALWAN 450","BALWAN 450");
                        document.getElementById("ModelNO").options[4]=new Option("SANMAN 6000","SANMAN 6000");
                        document.getElementById("ModelNO").options[5]=new Option("BALWAN 400 SUPER","BALWAN 400 SUPER");
                        document.getElementById("ModelNO").options[6]=new Option("BALWAN 550","BALWAN 550");
                        document.getElementById("ModelNO").options[7]=new Option("AMHIMAN","AMHIMAN");
                        document.getElementById("ModelNO").options[8]=new Option("SANMAN 6000LT","SANMAN 6000LT");
                        document.getElementById("ModelNO").options[9]=new Option("ORCHARD DELUXE","ORCHARD DELUXE");
                        document.getElementById("ModelNO").options[10]=new Option("BALWAN 400","BALWAN 400");
                        document.getElementById("ModelNO").options[11]=new Option("BALWAN 500","BALWAN 500");
                        break;
                    case "Digitrac":
                        document.getElementById("ModelNO").options[0]=new Option("SELECT MODEL","");
                        document.getElementById("ModelNO").options[1]=new Option("pp 51i","pp 51i");
                        document.getElementById("ModelNO").options[2]=new Option("pp 46i","pp 46i");
                        document.getElementById("ModelNO").options[3]=new Option("pp 43i","pp 43i");
                        break;
                    case "Same Deutz fahr":
                        document.getElementById("ModelNO").options[0]=new Option("SELECT MODEL","");
                        document.getElementById("ModelNO").options[1]=new Option("agrolux 50 turbo pro","agrolux 50 turbo pro");
                        document.getElementById("ModelNO").options[2]=new Option("AGROLUX 50 4WD","AGROLUX 50 4WD");
                        document.getElementById("ModelNO").options[3]=new Option("AGROMAXX 4080E","AGROMAXX 4080E");
                        document.getElementById("ModelNO").options[4]=new Option("AGROLUX 45","AGROLUX 45");
                        document.getElementById("ModelNO").options[5]=new Option("AGROLUX 60 4WD","AGROLUX 60 4WD");
                        document.getElementById("ModelNO").options[6]=new Option("AGROLUX 80 PROFILINE","AGROLUX 80 PROFILINE");
                        document.getElementById("ModelNO").options[7]=new Option("AGROMAXX 45 E","AGROMAXX 45 E");
                        document.getElementById("ModelNO").options[8]=new Option("AGROLUX 50 2WD","AGROLUX 50 2WD");
                        document.getElementById("ModelNO").options[9]=new Option("AGROLUX 70","AGROLUX 70");
                        document.getElementById("ModelNO").options[10]=new Option("AGROMAXX 55 2WD","AGROMAXX 55 2WD");
                        break;
                    case "Indo Farm":
                        document.getElementById("ModelNO").options[0]=new Option("SELECT MODEL","");
                        document.getElementById("ModelNO").options[1]=new Option("3040 DI","3040 DI");
                        document.getElementById("ModelNO").options[2]=new Option("3055 DI 4WD","3055 DI 4WD");
                        document.getElementById("ModelNO").options[3]=new Option("3048 DI 2WD","3048 DI 2WD");
                        document.getElementById("ModelNO").options[4]=new Option("1026 E" ,"1026 E");
                        document.getElementById("ModelNO").options[5]=new Option("2042 DI","2042 DI");
                        document.getElementById("ModelNO").options[6]=new Option("2035 DI","2035 DI");
                        document.getElementById("ModelNO").options[7]=new Option("3048 DI","3048 DI");
                        document.getElementById("ModelNO").options[8]=new Option("2030 DI","2030 DI");
                        document.getElementById("ModelNO").options[9]=new Option("3055 NV","3055 NV");
                        document.getElementById("ModelNO").options[10]=new Option("3055 DI","3055 DI");
                        break;
                    case "Preet":
                        document.getElementById("ModelNO").options[0]=new Option("SELECT MODEL","");
                        document.getElementById("ModelNO").options[1]=new Option("6049","6049");
                        document.getElementById("ModelNO").options[2]=new Option("6049 4wd","6049 4wd");
                        document.getElementById("ModelNO").options[3]=new Option("955","955");
                        document.getElementById("ModelNO").options[4]=new Option("6049 SUPER","6049 SUPER");
                        document.getElementById("ModelNO").options[5]=new Option("4049","4049");
                        document.getElementById("ModelNO").options[6]=new Option("4549","4549");
                        document.getElementById("ModelNO").options[7]=new Option("3049","3049");
                        document.getElementById("ModelNO").options[8]=new Option("2549 4WD","2549 4WD");
                        document.getElementById("ModelNO").options[9]=new Option("4049 4WD","4049 4WD");
                        document.getElementById("ModelNO").options[10]=new Option("2549","2549");
                        break;
                    case "solis":
                        document.getElementById("ModelNO").options[0]=new Option("SELECT MODEL","");
                        document.getElementById("ModelNO").options[1]=new Option("4515 E","4515 E");
                        document.getElementById("ModelNO").options[2]=new Option("4215 E","4215 E");
                        document.getElementById("ModelNO").options[3]=new Option("5015 E","5015 E");
                        document.getElementById("ModelNO").options[4]=new Option("HYBRID 5015 E"," HYBRID 5015 E");
                        document.getElementById("ModelNO").options[5]=new Option("5024 S 4WD","5024 S 4WD");
                        document.getElementById("ModelNO").options[6]=new Option("6024 S","6024 S");
                        document.getElementById("ModelNO").options[7]=new Option("5024 S 2WD","5024 S 2WD");
                        document.getElementById("ModelNO").options[8]=new Option("4415 E 4WD","4415 E 4WD");
                        document.getElementById("ModelNO").options[9]=new Option("2516 SN","2516 SN");
                        document.getElementById("ModelNO").options[10]=new Option("5515 E","5515 E");
                        break;

                    }
                    return true;

                }
            </script>
        <style>
            body{
                margin:0px;
            }
            .button1 {
                position:absolute;
                right: 1125px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button2 {
                position:absolute;
                right: 950px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button3 {
                position:absolute;
                right: 765px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button4 {
                position:absolute;
                right:550px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button5 {
                position:absolute;
                right: 400px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button6 {
                position:absolute;
                right: 150px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button7 {
                position:absolute;  
                right: 0px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 125px;
            }
            .button8 {
                position:absolute;
                right:139px;
                cursor: pointer;
                margin-top: 35px;
            } 
            .button9 {
                position:absolute;
                right:8px;
                cursor: pointer;
                margin-top: 35px;
            }
            .button10 {
                position:absolute;  
                right: 10px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 20px;
            } 
            .Logo1 {
                height: 70px;
                width: 110px;
                margin:2px;
                margin-left:50px ;
                margin-top: 14px;
                border-radius: 20px;
                border:1px solid black;
                position: absolute;
            }
            header{
                background-color: aqua;
                height:100px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                margin-top:50px; 
            }
            .animate-charcter{
                text-transform: uppercase;
                background-image: linear-gradient(
                -225deg,
                #231557 0%,
                #44107a 29%,
                #ff1361 67%,
                #fff800 100%
                );
                background-size: auto auto;
                background-clip: border-box;
                background-size: 200% auto;
                color: #fff;
                background-clip: text;
                text-fill-color: transparent;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: textclip 2s linear infinite;
                display: inline-block;
                font-size: 28px;
                margin-top: 22px;
                margin-bottom: 10px;
                margin-left: 505px;
                position:absolute;
            }

            @keyframes textclip {
                to {
                background-position: 200% center;
                }
            }

            body {
                display: absolute;
                align-items: center;
                justify-content: center;
            }
            h1 {
                color: #160404;
                font-family: tahoma;
                font-size: 28px;
                font-weight 900px;
                text-transform: uppercase;
                overflow: hidden;
                position: absolute;
                width: 575px;
                margin-left: 575px;
                margin-top: 20px;
            }

            h1 span {
                font-size: 28px;
                margin-left: 115px;
                margin-top: 20px;
            }

            .message {
                background-color: rgb(244, 228, 84);
                color: #333;
                display: block;
                font-weight: 900px;
                overflow: hidden;
                font-size:28px;
                position: absolute;
                left: 350px;
                animation: openclose 5s ease-in-out infinite;
            }

            .word1, .word2, .word3 {
                font-family: tahoma;
            }

            @keyframes openclose {
                0% {
                    top: 0rem;
                    width: 0;
                }
                5% {
                    width: 40px;
                }
                15% {
                    width: 100px;
                }
                30% {
                    top: 0rem;
                    width: 160px;
                }
                33% {       
                    top: 0rem;
                    width: 0;
                }
                35% {
                    top: 0rem;
                    width: 0;
                }
                38% {
                top: -2.1rem;
    
                }
                48% {
                    top: -2.1rem;
                    width: 100px;
                }
                62% {
                    top: -2.1rem;
                    width: 200px;
                }
                66% {
                    top: -2.1rem;
                    width: 0;
                    text-indent: 0;
                }
                68% {
                    top: -2.1rem;   
                    width: 0;
                    text-indent: 0;
                }
                71% {
                    top: -4.2rem;
                    width: 0;
                }
                80% {
                    top: -4.2rem;
                    width: 100px;
                }
                95% {
                    top: -4.2rem;
                    width: 200px;
                }
                98% {
                    top: -4.2rem;
                    width: 0;
                }
                100% {
                    top: 0;
                    width: 0;
                }
                }   
                .homelogo {
                    height: 21px;
                    width: 21px;
                    border-radius: 20px;
                }
                .abtlogo{
                    height: 21px;
                    width: 21px;
                }
                .input{
                    width:500px;
                    height:25px;
                    float:right;
                    margin-right: 70px;
            }
            .H1{
                margin-left:250px;
                font-size:px;
                margin-top: 20px;
            }
            .search{
                float:right;
                margin-top: 40px;
                margin-right: -47px;;
            }
            box{
                border:2px solid black;
            }
            .tractors{
                border:none;
                border:1px solid rgb(205, 204, 204);
                margin: 8px;
                padding: 0px;
                background-color: white;
                margin-left: 0px;
            }
            main{
                margin-left: 550px;
                margin-top: 125px;
             }
            .butimage{
                padding:0px;
                margin: 0px;
            }
            .book{
                background-color: rgb(71, 71, 245);
                height: 30px;
                margin-bottom: 0px;
                margin-top: 0px;
            }
            .book1{
                margin-bottom: 0px;;
                margin-top: -20px;
            }
            .text:hover{
                  color:red;
                  cursor:pointer;
            }
            button{
                cursor: pointer;
            }
            .book:hover
            {
                background-color: rgb(251, 41, 41);
            }

            @import url('https://fonts.googleapis.com/css2?family=Alfa+Slab+One&display=swap');
        .waviy {
                
                font-size: 20px;
                margin-top: -10x;

            }
            .waviy span {
                font-family: 'Alfa Slab One', simple;
                position: relative;
                display: inline-block;
                color: black;
                text-transform: uppercase;
                animation: waviy 1.25s infinite;
                animation-delay: calc(.1s * var(--i));
            }
            @keyframes waviy {
                0%,50%,100% {
                transform: translateY(0)
            }
                50% {
                transform: translateY(-20px)
            }
            }
            form{
                
                border: 1px solid black;
                margin-left: 550px;
                margin-top: 110px;
                width: 400px;
                box-shadow: 0px 5px 10px black;
            }
            select{
                display: block;
                margin:50px;
            }
            .sele{
                width: 300px;
                height: 30px;
            }
            .info{
                text-align: center;
                background-color:orange ;
                margin-left: 0px;
                margin-top: 0px;
                height: 45px;
            }
            .atab{
                        border: 1px solid rgb(147, 144, 144);
                        padding: 5px;
                        text-decoration: none;
                        margin-top: 0px;
                        margin-left: 15px;
                        margin-right: -50px;
                        background-color: rgb(123, 251, 251);
                        color: black;
                }
                .at{
                 margin-left:125px;
                 margin-top: -50px;
                 margin-bottom:20px ;
                 padding: 5px;
                 cursor: pointer;
                 background-color:rgb(127, 249, 249);
                 border: 1px solid rgb(147, 144, 144);
                }
            
            .HarButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }

            .Harvbar {
                
                right: 760px;
                position: absolute;
                display: inline-block;
            }

            .HarvContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .HarvContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .HarvContent a:hover {
                background-color: #ddd;
            }

            .Harvbar:hover .HarvContent {
                display: block;
            }

            .Harvbar:hover .HarButton {
                background-color: #3e8e41;
            }
            
            .ImpleButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Implebar {
                
                right: 550px;
                position: absolute;
                display: inline-block;
            }

            .ImpleContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .ImpleContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .ImpleContent a:hover {
                background-color: #ddd;
            }

            .Implebar:hover .ImpleContent {
                display: block;
            }

            .Implebar:hover .ImpleButton {
                background-color: #3e8e41;
            }

            .TracButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Tracbar {
                
                right: 400px;
                position: absolute;
                display: inline-block;
            }

            .TracContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .TracContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .TracContent a:hover {
                background-color: #ddd;
            }

            .Tracbar:hover .TracContent {
                display: block;
            }

            .Tracbar:hover .TracButton {
                background-color: #3e8e41;
            }

            .PlantButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Plantbar {
                
                right: 150px;
                position: absolute;
                display: inline-block;
            }

            .PlantContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .PlantContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .PlantContent a:hover {
                background-color: #ddd;
            }

            .Plantbar:hover .PlantContent {
                display: block;
            }

            .Plantbar:hover .PlantButton {
                background-color: #3e8e41;
            }
                
        </style>
        <meta charset="UTF-8">
        <title>
            Main Page
            </title>
            <link rel="icon" href="Logo.jpg">
        </head>
    <body>
            <div>
                <div>
                    <div">
                        <h3 class="animate-charcter"> Farm Tech:</h3>
                <h1>
                    <span>Lend/Borrow</span>
                    <div class="message">
                      <div class="word1">Tractors</div>
                      <div class="word2">Implements</div>
                      <div class="word3">Harvestors</div>
                    </div>
                  </h1>
                    </div>
                </div>
            </div>
            

<a href="Login.php">
    <button class="button7" type="button">
    <b> 
    <font size="4" style="font-family:verdana">
        Login
    </font>
    </b>
    </button>
</a>&nbsp;
            <a href="signin.php">
    <button class="button10" type="button">
    <b> 
    <font size="4" style="font-family:verdana">
        Sign in
    </font>
    </b>
    </button>
</a>&nbsp;  
<header>
    <img src="../Images/Logo.jpg" alt="Logo.jpg" class="Logo1"/>
    <a href=Home.html>
        <button class="button1" type="button">
        <img src="../Images/homelogo.jpg" class="homelogo">
        <b>
        <font size="5.75" style="font-family:verdana">
            Home
        </font><br>
        </b>
        </button>
    </a>&nbsp;

    <a href=AboutUS.html>
        <button class="button2" type="button">
        <img src="../Images/Abt.png" alt="Logo.jpg" class="abtlogo"/>

        <b>
        <font size="5.75" style="font-family:verdana">
            About Us
        </font>
        </b>
        </button>
    </a>&nbsp;
    <div class="Harvbar">
    <a href="harvester.php">
        <button class="HarButton" type="button">
        <img src="../Images/Harvestor.png" alt="Logo.jpg" class="abtlogo"/>

        <b>
        <font size="5.75" style="font-family:verdana">
            Harvestor</font>
        </b>
        </button>
        </a>&nbsp;

        <div class="HarvContent">
        <a href="harvester.php">Borrow</a>
        <a href="harv_lend_1.php">Lend</a>
    </div>
        </div>
        <div class="Implebar">
    
    <a href="implements.php">
        <button class="ImpleButton" type="button">
        <img src="../Images/Implements.png" alt="Logo.jpg" class="abtlogo"/>
        <b>
        <font size="5.75" style="font-family:verdana">
            Implements
        </font>
        </b>
        </button>
    </a>&nbsp;

    <div class="ImpleContent">
        <a href="Implements.php">Borrow</a>
        <a href="imple_lend_1.php">Lend</a>
    </div>
        </div>
        <div class="Tracbar">
    <a href="tractor.php">

        <button class="TracButton" type="button">
        <img src="../Images/Tractor.png" alt="Logo.jpg" class="abtlogo"/>
        <b>
        <font size="5.75" style="font-family:verdana">
            Tractor
        </font>
        </b>
        </button>
    </a>&nbsp;

        <div class="TracContent">
            <a href="tractor.php">Borrow</a>
            <a href="trac_lend_1.php">Lend</a>    
        </div>
            </div>
            <div class="Plantbar">

    <a href="PlantNutrition.html">

        <button class="PlantButton" type="button">
        <img src="../Images/PlantNutrition.png" alt="Logo.jpg" class="abtlogo"/>
        
<b>
    <font size="5.75" style="font-family:verdana">
        Plant Nutrition
    </font>
    </b>
    </button>
</a>&nbsp;
<div class="PlantContent">
    <a href="Soil Health.html">Soil Health</a>
    <a href="Soilissue.html">Soil Issue</a>
    <a href="Nutritions.html">Nutrients</a>
    <a href="Elements.html">Element</a>
    <a href="pesticides.html">Pesticides</a>
    <a href="Crops.html">Crops</a>    
    <a href="Plant Growth.html">Plant Growth</a>
    <a href="Preventation.html">Preventation</a>
</div>
</div> </header>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
       
            </form>
            <form action ="trac_lend_2_without.php" method ="POST">
            
            

            <h2 class="info">Information - Tractor</h2>
        <select id="Company" name="Company" onchange="javascript: Com(this.options[this.selectedIndex].value);" class="sele" required>
            <option value="Select Company">Select Company</option>    
            <option value="Swaraj">Swaraj</option>
            <option value="Massey Ferguson">Massey Ferguson</option>
            <option value="Mahindra">Mahindra</option>
            <option value="Sonalika">Sonalika</option>
            <option value="New Holland">New Holland</option>
            <option value="John Deere">John Deere</option>
            <option value="Powertrack">Powertrack</option>
            <option value="Farmtrac">Farmtrac</option>
            <option value="Eicher">Eicher</option>
            <option value="Kartar">Kartar</option>
            <option value="Kubota">Kubota</option>
            <option value="VST">VST</option>
            <option value="Solis">Solis</option>
            <option value="Preet">Preet</option>
            <option value="Indo Farm">Indo Farm</option>
            <option value="Same Deutz Fahr">Same Deutz Fahr</option>
            <option value="Digitrac">Digitrac</option>
            <option value="Force">Force</option>
            <option value="Hindustan">Hindustan</option>
            <option value="Captain">Captain</option>
            <option value="ACE">ACE</option>
            <option value="Escorts">Escorts</option>
            <option value="Autonxt">Autonxt</option>
            <option value="Trakstar">Trakstar</option>
            <option value="Standard">Standard</option>
            <option value="HAV">HAV</option>	
            <option value="Cellestial">Cellestial</option>
            <option value="Valdo">Valdo</option>
        </select>
        <script type="text/javascript" language="JavaScript">
            document.write('<select name="ModelNO" id="ModelNO" class="sele" ><option value="">Select Model </option></select>')
            </script>
            <main2>
            <noscript>
            <select id="ModelNo" name="ModelNO" >
                <option value=""></option>
                <option value=""></option>
            </noscript>
            </select>
            <select id="Year" name="Year" class="sele">
                <option value="Year of Purchase">Year of Purchase</option>
                <option value="1991">1991</option>
                <option value="1992">1992</option>
                <option value="1993">1993</option>
                <option value="1994">1994</option>
                <option value="1995">1995</option>  
                <option value="1997">1996</option>
                <option value="1998">1998</option>
                <option value="1999">1999</option>
                <option value="2000">2000</option>
                <option value="2001">2001</option>
                <option value="2002">2002</option>
                <option value="2003">2003</option>
                <option value="2004">2004</option>
                <option value="2005">2005</option>
                <option value="2006">2006</option>
                <option value="2007">2007</option>
                <option value="2008">2008</option>
                <option value="2009">2009</option>
                <option value="2010">2010</option>
                <option value="2011">2011</option>
                <option value="2012">2012</option>
                <option value="2013">2013</option>
                <option value="2014">2014</option>
                <option value="2015">2015</option>
                <option value="2016">2016</option>
                <option value="2017">2017</option>
                <option value="2018">2018</option>
                <option value="2019">2019</option>
                <option value="2020">2020</option>
                <option value="2021">2021</option>
                <option value="2022">2022</option>
                <option value="2023">2023</option>
            </select>
            <input type="submit" value="submit" class="at">
            </form>  
            </form>
        </body>
    </html> 
    