<?php   error_reporting(0);



$servername = "localhost";
$username = "root";
$password = "";

$conn = mysqli_connect($servername, $username, $password );
if (!$conn){
    die("Sorry we failed to connect: " . mysqli_connect_error());
}
    //echo "Connection was successful";

$Device = $_POST['Device'];
$Company = $_POST['Company'];
$Year = $_POST['Year'];

$query = "Select MAX(sno) as maxx from `farmtech`.`imple_lend`";
$ab = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($ab);
$Last_aa = $row['maxx'];

$or_query = "Select Device from `farmtech`.`imple_lend` WHERE `sno` = $Last_aa";
$or_result = mysqli_query($conn, $or_query);
$or_data = mysqli_fetch_assoc($or_result);


$sql ="UPDATE `farmtech`.`imple_lend` SET `Device` = '$Device' WHERE `sno` = $Last_aa";
$result = mysqli_query($conn, $sql);
$sql ="UPDATE `farmtech`.`imple_lend` SET `Company` = '$Company' Where `sno` = $Last_aa"; 
$result = mysqli_query($conn, $sql);
$sql ="UPDATE `farmtech`.`imple_lend` SET `Year` = '$Year' Where `sno` = $Last_aa"; 
$result = mysqli_query($conn, $sql);





$new_query = "Select Device from `farmtech`.`imple_lend` WHERE `sno` = $Last_aa";
$new_result = mysqli_query($conn, $new_query);
$new_data = mysqli_fetch_assoc($new_result);



if($or_data['Device'] !== $new_data['Device']){
    //echo"successfully inserted";
    header("Location: imple_lend_3.php");
}else{
    // echo"ERROR: $sql<br> $conn->error";
}





?>


<?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    
    $conn = mysqli_connect($servername, $username, $password );
    if (!$conn){
        die("Sorry we failed to connect: " . mysqli_connect_error());
    }
        //echo "Connection was successful";
session_start();
if(isset($_GET['UEmail']))
{
$EmailId = $_GET['UEmail'];

}
//echo "$EmailId";

?>



<!Doctype html>
<HTML lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <style>
            body{
                margin:0px;
            }
            .button1 {
                position:absolute;
                right: 1125px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button2 {
                position:absolute;
                right: 950px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button3 {
                position:absolute;
                right: 765px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button4 {
                position:absolute;
                right:550px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button5 {
                position:absolute;
                right: 400px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button6 {
                position:absolute;
                right: 150px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button7 {
                position:absolute;  
                right: 0px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 125px;
            }
            .button8 {
                position:absolute;
                right:139px;
                cursor: pointer;
                margin-top: 35px;
            } 
            .button9 {
                position:absolute;
                right:8px;
                cursor: pointer;
                margin-top: 35px;
            }
            .button10 {
                position:absolute;  
                right: 10px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 20px;
            } 
            .Logo1 {
                height: 70px;
                width: 110px;
                margin:2px;
                margin-left:50px ;
                margin-top: 14px;
                border-radius: 20px;
                border:1px solid black;
                position: absolute;
            }
            header{
                background-color: aqua;
                height:100px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                margin-top:50px; 
            }
            .animate-charcter{
                text-transform: uppercase;
                background-image: linear-gradient(
                -225deg,
                #231557 0%,
                #44107a 29%,
                #ff1361 67%,
                #fff800 100%
                );
                background-size: auto auto;
                background-clip: border-box;
                background-size: 200% auto;
                color: #fff;
                background-clip: text;
                text-fill-color: transparent;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: textclip 2s linear infinite;
                display: inline-block;
                font-size: 28px;
                margin-top: 22px;
                margin-bottom: 10px;
                margin-left: 505px;
                position:absolute;
            }

            @keyframes textclip {
                to {
                background-position: 200% center;
                }
            }

            body {
                display: absolute;
                align-items: center;
                justify-content: center;
            }
            h1 {
                color: #160404;
                font-family: tahoma;
                font-size: 28px;
                font-weight 900px;
                text-transform: uppercase;
                overflow: hidden;
                position: absolute;
                width: 575px;
                margin-left: 575px;
                margin-top: 20px;
            }

            h1 span {
                font-size: 28px;
                margin-left: 115px;
                margin-top: 20px;
            }

            .message {
                background-color: rgb(244, 228, 84);
                color: #333;
                display: block;
                font-weight: 900px;
                overflow: hidden;
                font-size:28px;
                position: absolute;
                left: 350px;
                animation: openclose 5s ease-in-out infinite;
            }

            .word1, .word2, .word3 {
                font-family: tahoma;
            }

            @keyframes openclose {
                0% {
                    top: 0rem;
                    width: 0;
                }
                5% {
                    width: 40px;
                }
                15% {
                    width: 100px;
                }
                30% {
                    top: 0rem;
                    width: 160px;
                }
                33% {       
                    top: 0rem;
                    width: 0;
                }
                35% {
                    top: 0rem;
                    width: 0;
                }
                38% {
                top: -2.1rem;
    
                }
                48% {
                    top: -2.1rem;
                    width: 100px;
                }
                62% {
                    top: -2.1rem;
                    width: 200px;
                }
                66% {
                    top: -2.1rem;
                    width: 0;
                    text-indent: 0;
                }
                68% {
                    top: -2.1rem;   
                    width: 0;
                    text-indent: 0;
                }
                71% {
                    top: -4.2rem;
                    width: 0;
                }
                80% {
                    top: -4.2rem;
                    width: 100px;
                }
                95% {
                    top: -4.2rem;
                    width: 200px;
                }
                98% {
                    top: -4.2rem;
                    width: 0;
                }
                100% {
                    top: 0;
                    width: 0;
                }
                }   
                .homelogo {
                    height: 21px;
                    width: 21px;
                    border-radius: 20px;
                }
                .abtlogo{
                    height: 21px;
                    width: 21px;
                }
                .input{
                    width:500px;
                    height:25px;
                    float:right;
                    margin-right: 70px;
            }
            .H1{
                margin-left:250px;
                font-size:px;
                margin-top: 20px;
            }
            .search{
                float:right;
                margin-top: 40px;
                margin-right: -47px;;
            }
            box{
                border:2px solid black;
            }
            .tractors{
                border:none;
                border:1px solid rgb(205, 204, 204);
                margin: 8px;
                padding: 0px;
                background-color: white;
                margin-left: 0px;
            }
            main{
                margin-left: 550px;
                margin-top: 125px;;
            }
            .butimage{
                padding:0px;
                margin: 0px;
            }
            .book{
                background-color: rgb(71, 71, 245);
                height: 30px;
                margin-bottom: 0px;
                margin-top: 0px;
            }
            .book1{
                margin-bottom: 0px;;
                margin-top: -20px;
            }
            .text:hover{
                  color:red;
                  cursor:pointer;
            }
            button{
                cursor: pointer;
            }
            .book:hover
            {
                background-color: rgb(251, 41, 41);
            }

            @import url('https://fonts.googleapis.com/css2?family=Alfa+Slab+One&display=swap');
        .waviy {
                
                font-size: 20px;
                margin-top: -10x;

            }
            .waviy span {
                font-family: 'Alfa Slab One', simple;
                position: relative;
                display: inline-block;
                color: black;
                text-transform: uppercase;
                animation: waviy 1.25s infinite;
                animation-delay: calc(.1s * var(--i));
            }
            @keyframes waviy {
                0%,50%,100% {
                transform: translateY(0)
            }
                50% {
                transform: translateY(-20px)
            }
            }
            form{
                border:1px solid black;
                width: 275px;
                margin-left: 625px;
                box-shadow: 0px 5px 10px black;
            }
            .select{
                display: flex;
                margin: 10px;
                width: 250px;
                height: 30px;
                margin-top: 45px;
            }
            .info{
                text-align: center;
                  font-size: larger;
                  font-weight: 1000;
                  background-color: orange;
                  height: 45px;
                  margin-top: 0px;

            }
            .atab{
                        border: 1px solid rgb(147, 144, 144);
                        padding: 5px;
                        text-decoration: none;
                        margin-top: 50px;
                        margin-left: 15px;
                        margin-right: -50px;
                        background-color: rgb(123, 251, 251);
                        color: black;
                }
                .at{
                 margin-left:70px;
                 margin-top: -0px;
                 margin-bottom:20px ;
                 padding: 5px;
                 cursor: pointer;
                 background-color:rgb(127, 249, 249);
                 border: 1px solid rgb(147, 144, 144);
                }
            
            .HarButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }

            .Harvbar {
                
                right: 760px;
                position: absolute;
                display: inline-block;
            }

            .HarvContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .HarvContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .HarvContent a:hover {
                background-color: #ddd;
            }

            .Harvbar:hover .HarvContent {
                display: block;
            }

            .Harvbar:hover .HarButton {
                background-color: #3e8e41;
            }
            
            .ImpleButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Implebar {
                
                right: 550px;
                position: absolute;
                display: inline-block;
            }

            .ImpleContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .ImpleContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .ImpleContent a:hover {
                background-color: #ddd;
            }

            .Implebar:hover .ImpleContent {
                display: block;
            }

            .Implebar:hover .ImpleButton {
                background-color: #3e8e41;
            }

            .TracButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Tracbar {
                
                right: 400px;
                position: absolute;
                display: inline-block;
            }

            .TracContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .TracContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .TracContent a:hover {
                background-color: #ddd;
            }

            .Tracbar:hover .TracContent {
                display: block;
            }

            .Tracbar:hover .TracButton {
                background-color: #3e8e41;
            }

            .PlantButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Plantbar {
                
                right: 150px;
                position: absolute;
                display: inline-block;
            }

            .PlantContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .PlantContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .PlantContent a:hover {
                background-color: #ddd;
            }

            .Plantbar:hover .PlantContent {
                display: block;
            }

            .Plantbar:hover .PlantButton {
                background-color: #3e8e41;
            }
.EmaillButton {
    color: black;
    padding: 4px;
    font-size: 10px;
    margin-top: 33px;
    border-bottom:1px solid rgb(0, 0, 0);
    border-top: 1px solid rgb(0, 0, 0);
    border-left: 1px solid rgb(0, 0, 0);
    border-right: 1px solid rgb(0, 0, 0);
    border-radius: 20px;
}

.Emaillbar {
    
    right: 5px;
    position: absolute;
    display: inline-block;
}

.EmaillContent {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
    text-align: center  ;
}

.EmaillContent a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.EmaillContent a:hover {
    background-color: #ddd;
}

.Emaillbar:hover .EmaillContent {
    display: block;
}

.Emaillbar:hover .EmaillButton {
    background-color: #3e8e41;

}
        </style>
        <meta charset="UTF-8">
        <title>
            Main Page
            </title>
            <link rel="icon" href="Logo.jpg">
        </head>
    <body>
            <div>
                <div>
                    <div">
                        <h3 class="animate-charcter"> Farm Tech:</h3>
                <h1>
                    <span>Lend/Borrow</span>
                    <div class="message">
                      <div class="word1">Tractors</div>
                      <div class="word2">Implements</div>
                      <div class="word3">Harvestors</div>
                    </div>
                  </h1>
                    </div>
                </div>
            </div>
           
       
        

        <div class="Emaillbar">

<button class="EmaillButton" type="button">
<a href="Tractor.html">
</a>&nbsp;
<b>
<font size="3" style="font-family:verdana">
    <?php
    echo "$EmailId";
    ?>
</font>
</b>
</button>
<div class="EmaillContent">
    <a href="Tractor.html">Profile</a>
    <a href="../Home.html">LogOut</a>    
</div>
    </div>
    <br>
<br>
<header>
<img src="../Images/Logo.jpg" alt="Logo.jpg" class="Logo1"/>
<a href="../homeloggedin.php?UEmail=<?php echo "$EmailId";?>">
<button class="button1" type="button">
<img src="../Images/homelogo.jpg" class="homelogo">
<b>
<font size="5.75" style="font-family:verdana">
Home
</font><br>
</b>
</button>
</a>&nbsp;

<a href="AboutUS.php?UEmail=<?php echo "$EmailId";?>">
<button class="button2" type="button">
<img src="../Images/Abt.png" alt="Logo.jpg" class="abtlogo"/>

<b>
<font size="5.75" style="font-family:verdana">
About Us
</font>
</b>
</button>
</a>&nbsp;
<div class="Harvbar">
<a href="harvester.php?UEmail=<?php echo "$EmailId";?>">
<button class="HarButton" type="button">
<img src="../Images/Harvestor.png" alt="Logo.jpg" class="abtlogo"/>

<b>
<font size="5.75" style="font-family:verdana">
Harvestor</font>
</b>
</button>
</a>&nbsp;

<div class="HarvContent">
<a href="harvester.php?UEmail=<?php echo "$EmailId";?>">Borrow</a>
<a href="harv_lend_1.php?UEmail=<?php echo "$EmailId";?>">Lend</a>
</div>
</div>
<div class="Implebar">

<a href="implements.php?UEmail=<?php echo "$EmailId";?>">
<button class="ImpleButton" type="button">
<img src="../Images/Implements.png" alt="Logo.jpg" class="abtlogo"/>
<b>
<font size="5.75" style="font-family:verdana">
Implements
</font>
</b>
</button>
</a>&nbsp;

<div class="ImpleContent">
<a href="Implements.php?UEmail=<?php echo "$EmailId";?>">Borrow</a>
<a href="imple_lend_1.php?UEmail=<?php echo "$EmailId";?>">Lend</a>
</div>
</div>
<div class="Tracbar">
<a href="tractor.php?UEmail=<?php echo "$EmailId";?>">

<button class="TracButton" type="button">
<img src="../Images/Tractor.png" alt="Logo.jpg" class="abtlogo"/>
<b>
<font size="5.75" style="font-family:verdana">
Tractor
</font>
</b>
</button>
</a>&nbsp;

<div class="TracContent">
<a href="tractor.php?UEmail=<?php echo "$EmailId";?>">Borrow</a>
<a href="trac_lend_1.php?UEmail=<?php echo "$EmailId";?>">Lend</a>    
</div>
</div>
<div class="Plantbar">

<a href="PlantNutrition.php?UEmail=<?php echo "$EmailId";?>">

<button class="PlantButton" type="button">
<img src="../Images/PlantNutrition.png" alt="Logo.jpg" class="abtlogo"/>

<b>
<font size="5.75" style="font-family:verdana">
Plant Nutrition
</font>
</b>
</button>
</a>&nbsp;
<div class="PlantContent">
<a href="Soil Health.php?UEmail=<?php echo "$EmailId";?>">Soil Health</a>
<a href="Soilissue.php?UEmail=<?php echo "$EmailId";?>">Soil Issue</a>
<a href="Nutritions.php?UEmail=<?php echo "$EmailId";?>">Nutrients</a>
<a href="Elements.php?UEmail=<?php echo "$EmailId";?>">Element</a>
<a href="pesticides.php?UEmail=<?php echo "$EmailId";?>">Pesticides</a>
<a href="Crops.php?UEmail=<?php echo "$EmailId";?>">Crops</a>    
<a href="Plant Growth.php?UEmail=<?php echo "$EmailId";?>">Plant Growth</a>
<a href="Preventation.php?UEmail=<?php echo "$EmailId";?>">Preventation</a>
</div>
</div> 
</header>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
            </form>
            <form action ="imple_lend_2.php" method ="post">
            <p class="info">Information - Implements</p>
        <select id ="Device" name="Device" class="select">
            <option value="Select Device">Select Device</option>    
            <option value="Rotavator">Rotavator</option>
            <option value="Plough">Plough</option>
            <option value="Cultivator">Cultivator</option>
            <option value="Tractor Mounted Sprayer">Tractor Mounted Sprayer</option>
            <option value="Thresher">Thresher</option>
            <option value="Harrow">Harrow</option>
            <option value="Disc Harrow">Disc Harrow</option>
            <option value="Baller">Baller</option>
            <option value="Laser Land Leveler">Laser Land Leveler</option>
            <option value="Tractor Trailer">Tractor Trailer</option>
            <option value="Mulcher">Mulcher</option>
            <option value="Power Harrow">Power Harrow</option>
            <option value="Power Tiller">Power Tiller</option>
            <option value="Seed Cum Fertilizer Drill">Seed Cum Fertilizer Drill</option>
            <option value="Roto Seed Drill">Roto Seed Drill</option>
            <option value="Precision Planter">Precision Planter</option>
            <option value="Disc Plough">Disc Plough</option>
            <option value="Power Weeder">Power Weeder</option>
            <option value="Post Hole Diggers">Post Hole Diggers</option>
            <option value="Straw Reaper">Straw Reaper</option>
            <option value="Super Seeder">Super Seeder</option>
            <option value="Seed Drill">Seed Drill</option>
            <option value="Ridger">Ridger</option>
            <option value="Land Leveller">Land Leveller</option>
            <option value="Rice Transplanter">Rice Transplanter</option>
            <option value="Repears">Repears</option>	
            <option value="Transplanter">Transplanter</option>
            <option value="Slasher">Slasher</option>
            <option value="Subsoiler">Subsoiler</option>
            <option value="Hey Rake">Hey Rake</option>
            <option value="Potato Planter">Potato Planter</option>
            <option value="Happy Seeder">Happy Seeder</option>
            <option value="Shredder">Shredder</option>
            <option value="Dozer/Blade">Dozer/Blade</option>
            <option value="Fertilizer Broadcaster">Fertilizer Broadcaster</option>
            <option value="Spreader">Spreader</option>
            <option value="Rotary Tiller">Rotary Tiller</option>
            <option value="Boom Sprayer">Boom Sprayer</option>
            <option value="Mini Rotary Tiller">Mini Rotary Tiller</option>
            <option value="Chopper">Chopper</option>
            <option value="Front End Loaders">Front End Loaders</option>
            <option value="Grooming Mower">Grooming Mower</option>
            <option value="Spray Pump">Spray Pump</option>
            </select>
            <select class="select" name="Company" id="Company">
                <option value="Select Company">Select Company</option>
                <option value="Agripro">Agripro</option>
                <option value="Agristar">Agristar</option>
                <option value="Bakshish">Bakshish</option>
                <option value="Bullz Power">Bullz Power</option>
                <option value="Captain">Captain</option>
                <option value="CAT">CAT</option>
                <option value="Claas">Claas</option>
                <option value="Dasmesh">Dasmesh</option>
                <option value="Farmking">Farmking</option>
                <option value="Fieldking">Fieldking</option>
                <option value="Gahir">Gahir</option>
                <option value="Garud">Garud</option>
                <option value="Greaves Cotton">Greaves Cotton</option>
                <option value="Hind Agro">Hind Agro</option>
                <option value="Honda">Honda</option>
                <option value="Indo Farm">Indo Farm</option>
                <option value="Jagatjit">Jagatjit</option>
                <option value="John Deere">John Deere</option>
                <option value="Kartar">Kartar</option>
                <option value="Khedut">Khedut</option>
                <option value="KMW By Kirloskar">KMW By Kirloskar</option>
                <option value="KS Group">KS Group</option>
                <option value="Kubota">Kubota</option>
                <option value="LandForce">LandForce</option>
                <option value="Lemken">Lemken</option>
                <option value="Mahindra">Mahindra</option>
                <option value="Malkit">Malkit</option>
                <option value="Maschio Gaspardo">Maschio Gaspardo</option>
                <option value="MITRA">MITRA</option>
                <option value="Neptune">Neptune</option>
                <option value="New Holland">New Holland</option>
                <option value="Pagro">Pagro</option>
                <option value="Shaktiman">Shaktiman</option>
                <option value="Shrachi">Shrachi</option>
                <option value="Soil Master">Soil Master</option>
                <option value="SoilTech">SoilTech</option>
                <option value="Solis">Solis</option>
                <option value="Sonalika">Sonalika</option>
                <option value="Stihl">Stihl</option>
                <option value="Swaraj">Swaraj</option>
                <option value="Universal">Universal</option>
                <option value="Vishal">Vishal</option>
                <option value="VST">VST</option>
                <option value="Yanmar">Yanmar</option>
                </select>
                <select id="Year" name="Year" class="select">
                    <option value="">Year of Purchase</option>
                    <option value="1991">1991</option>
                    <option value="1992">1992</option>
                    <option value="1993">1993</option>
                    <option value="1994">1994</option>
                    <option value="1995">1995</option>  
                    <option value="1997">1996</option>
                    <option value="1998">1998</option>
                    <option value="1999">1999</option>
                    <option value="2000">2000</option>
                    <option value="2001">2001</option>
                    <option value="2002">2002</option>
                    <option value="2003">2003</option>
                    <option value="2004">2004</option>
                    <option value="2005">2005</option>
                    <option value="2006">2006</option>
                    <option value="2007">2007</option>
                    <option value="2008">2008</option>
                    <option value="2009">2009</option>
                    <option value="2010">2010</option>
                    <option value="2011">2011</option>
                    <option value="2012">2012</option>
                    <option value="2013">2013</option>
                    <option value="2014">2014</option>
                    <option value="2015">2015</option>
                    <option value="2016">2016</option>
                    <option value="2017">2017</option>
                    <option value="2018">2018</option>
                    <option value="2019">2019</option>
                    <option value="2020">2020</option>
                    <option value="2021">2021</option>
                    <option value="2022">2022</option>
                    <option value="2023">2023</option>
                </select>
                <input type="submit" value="submit" class="at">
               
                </form>
           </form>
        </body>
    </html>