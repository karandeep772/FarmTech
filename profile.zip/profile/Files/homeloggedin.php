<?php   error_reporting(0);

    $servername = "localhost";
    $username = "root";
    $password = "";
    
    $conn = mysqli_connect($servername, $username, $password );
    if (!$conn){
        die("Sorry we failed to connect: " . mysqli_connect_error());
    }
        //echo "Connection was successful";
session_start();
if(isset($_GET['Email']))
{
$EmailId = $_GET['Email'];

}
//echo "$EmailId";

?>
<!Doctype html>
<HTML lang="en">
    <head>
        <style>
            body{
                margin:0px;
            }
            .button1 {
                position:absolute;
                right: 1125px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button2 {
                position:absolute;
                right: 950px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button3 {
                position:absolute;
                right: 765px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button4 {
                position:absolute;
                right:550px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button5 {
                position:absolute;
                right: 400px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button6 {
                position:absolute;
                right: 150px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button7 {
                position:absolute;  
                right: 10px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            } 
            .button8 {
                position:absolute;
                right:139px;
                cursor: pointer;
                margin-top: 35px;
            } 
            .button9 {
                position:absolute;
                right:8px;
                cursor: pointer;
                margin-top: 35px;
            }
            .Logo1 {
                height: 70px;
                width: 110px;
                margin:2px;
                margin-left:50px ;
                margin-top: 14px;
                border-radius: 20px;
                border:1px solid black;
                position: absolute;
            }
            header{
                background-color: aqua;
                height:100px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                margin-top:50px; 
            }
            .animate-charcter{
                text-transform: uppercase;
                background-image: linear-gradient(
                -225deg,
                #231557 0%,
                #44107a 29%,
                #ff1361 67%,
                #fff800 100%
                );
                background-size: auto auto;
                background-clip: border-box;
                background-size: 200% auto;
                color: #fff;
                background-clip: text;
                text-fill-color: transparent;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: textclip 2s linear infinite;
                display: inline-block;
                font-size: 28px;
                margin-top: 22px;
                margin-bottom: 10px;
                margin-left: 505px;
                position:absolute;
            }

            @keyframes textclip {
                to {
                background-position: 200% center;
                }
            }

            body {
                display: absolute;
                align-items: center;
                justify-content: center;
            }
            h1 {
                color: #160404;
                font-family: tahoma;
                font-size: 28px;
                font-weight 900px;
                text-transform: uppercase;
                overflow: hidden;
                position: absolute;
                width: 575px;
                margin-left: 575px;
                margin-top: 20px;
            }

            h1 span {
                font-size: 28px;
                margin-left: 115px;
                margin-top: 20px;
            }

            .message {
                background-color: rgb(244, 228, 84);
                color: #333;
                display: block;
                font-weight: 900px;
                overflow: hidden;
                font-size:28px;
                position: absolute;
                left: 350px;
                animation: openclose 5s ease-in-out infinite;
            }

            .word1, .word2, .word3 {
                font-family: tahoma;
            }

            @keyframes openclose {
                0% {
                    top: 0rem;
                    width: 0;
                }
                5% {
                    width: 40px;
                }
                15% {
                    width: 100px;
                }
                30% {
                    top: 0rem;
                    width: 160px;
                }
                33% {       
                    top: 0rem;
                    width: 0;
                }
                35% {
                    top: 0rem;
                    width: 0;
                }
                38% {
                top: -2.1rem;
    
                }
                48% {
                    top: -2.1rem;
                    width: 100px;
                }
                62% {
                    top: -2.1rem;
                    width: 200px;
                }
                66% {
                    top: -2.1rem;
                    width: 0;
                    text-indent: 0;
                }
                68% {
                    top: -2.1rem;   
                    width: 0;
                    text-indent: 0;
                }
                71% {
                    top: -4.2rem;
                    width: 0;
                }
                80% {
                    top: -4.2rem;
                    width: 100px;
                }
                95% {
                    top: -4.2rem;
                    width: 200px;
                }
                98% {
                    top: -4.2rem;
                    width: 0;
                }
                100% {
                    top: 0;
                    width: 0;
                }
                }   
                .homelogo {
                    height: 21px;
                    width: 21px;
                }
                .abtlogo{
                    height: 21px;
                    width: 21px;
                }
                .EmaillButton {
                    color: black;
                    padding: 4px;
                    font-size: 10px;
                    margin-top: 33px;
                    border-bottom:1px solid rgb(0, 0, 0);
                    border-top: 1px solid rgb(0, 0, 0);
                    border-left: 1px solid rgb(0, 0, 0);
                    border-right: 1px solid rgb(0, 0, 0);
                    border-radius: 20px;
                }
                
                .Emaillbar {
                    
                    right: 5px;
                    position: absolute;
                    display: inline-block;
                }

                .EmaillContent {
                    display: none;
                    position: absolute;
                    background-color: #f1f1f1;
                    min-width: 160px;
                    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                    z-index: 1;
                    text-align: center  ;
                }

                .EmaillContent a {
                    color: black;
                    padding: 12px 16px;
                    text-decoration: none;
                    display: block;
                }

                .EmaillContent a:hover {
                    background-color: #ddd;
                }

                .Emaillbar:hover .EmaillContent {
                    display: block;
                }

                .Emaillbar:hover .EmaillButton {
                    background-color: #3e8e41;

                }.TracButton {
                    color: black;
                    padding: 4px;
                    font-size: 16px;
                    margin-top: 33px;
                    border-bottom:1px solid rgb(0, 0, 0);
                    border-top: 1px solid rgb(0, 0, 0);
                    border-left: 1px solid rgb(0, 0, 0);
                    border-right: 1px solid rgb(0, 0, 0);
                    border-radius: 20px;
                }
                
                .Tracbar {
                    
                    right: 400px;
                    position: absolute;
                    display: inline-block;
                }

                .TracContent {
                    display: none;
                    position: absolute;
                    background-color: #f1f1f1;
                    min-width: 160px;
                    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                    z-index: 1;
                    text-align: center  ;
                }

                .TracContent a {
                    color: black;
                    padding: 12px 16px;
                    text-decoration: none;
                    display: block;
                }

                .TracContent a:hover {
                    background-color: #ddd;
                }

                .Tracbar:hover .TracContent {
                    display: block;
                }

                .Tracbar:hover .TracButton {
                    background-color: #3e8e41;
                }
            .HarButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }

            .Harvbar {
                
                right: 760px;
                position: absolute;
                display: inline-block;
            }

            .HarvContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .HarvContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .HarvContent a:hover {
                background-color: #ddd;
            }

            .Harvbar:hover .HarvContent {
                display: block;
            }

            .Harvbar:hover .HarButton {
                background-color: #3e8e41;
            }
            
            .ImpleButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Implebar {
                
                right: 550px;
                position: absolute;
                display: inline-block;
            }

            .ImpleContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .ImpleContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .ImpleContent a:hover {
                background-color: #ddd;
            }

            .Implebar:hover .ImpleContent {
                display: block;
            }

            .Implebar:hover .ImpleButton {
                background-color: #3e8e41;
            }

            .TracButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Tracbar {
                
                right: 400px;
                position: absolute;
                display: inline-block;
            }

            .TracContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .TracContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .TracContent a:hover {
                background-color: #ddd;
            }

            .Tracbar:hover .TracContent {
                display: block;
            }

            .Tracbar:hover .TracButton {
                background-color: #3e8e41;
            }

            .PlantButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Plantbar {
                
                right: 150px;
                position: absolute;
                display: inline-block;
            }

            .PlantContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .PlantContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .PlantContent a:hover {
                background-color: #ddd;
            }

            .Plantbar:hover .PlantContent {
                display: block;
            }

            .Plantbar:hover .PlantButton {
                background-color: #3e8e41;
            }.class1{
                text-align: center;
                margin-left: 450px;
            }
            .class2{
                text-align: center;
                margin-left: 475px;
            }
            .Farm{
                margin-top: 75px;
                margin-left: 50px;
                margin-right:50px ;
                font-size: large;
            }
            .Farm1{
                margin-top: 50px;
                margin-left: 25px;
                /* margin-right:50px; */
                font-size: large;   
            }
            .Farm2{
                margin-top: 45px;
                margin-left: 50px;
                margin-right:50px ;
                font-size: large;
            }
            .tractors{
                border:none;
                border:1px solid rgb(205, 204, 204);
                margin: 20px;
                padding: 0px;
                background-color: white;
                margin-left: 45px;
            }
            .butimage{
                padding:0px;
                margin: 0px;
            }
            .text:hover{
                color:red;
                cursor:pointer;
            }
            #Farmid{
                font-size: x-large;
                margin-bottom:5px ;
            }
            #Farmid1{
                font-size: x-large;
                margin-bottom:5px ;
                margin-top: 50px;
            }
            .far{
                margin-left: 50px;
                font-size: large;
            }
            .img1{
                margin-top: 0px;
            }
            .footer{
                background-color:rgb(98, 244, 98);
                height:30px;
                margin-bottom: 0px;
            }
            .tab1{
                text-align:inherit;
                margin-top: 100px;
                text-align: center;
                font-size: larger;
                margin-left: 77px;
                margin-right: 77px;
            }
            .tab2,.tab3,.tab6{
                text-align:inherit;
                text-align: center;
                font-size: larger;
                margin-top: 50px;
                margin-left: 77px;
                margin-right: 77px;
            }
            .tab4{
                margin-left:90px;
                margin-top: 50px;
                font-size: larger;
            }
            .tab5{
                margin-left: 175px;
                font-size: larger;
            }
            .agri{
                margin-left: 500px;
            }
            .tab6{
                text-align:inherit;
                text-align: center;
                font-size: larger;
                margin-top: 50px;
                margin-left: 77px;
                margin-right: 77px;
            }
        </style>

        <meta charset="UTF-8">
        <title>
            Main Page
            </title>
        </head>
    <body>
            <div>
                <div>
                    <div">
                        <h3 class="animate-charcter"> Farm Tech:</h3>
                <h1>
                    <span>Lend/Borrow</span>
                    <div class="message">
                      <div class="word1">Tractors</div>
                      <div class="word2">Implements</div>
                      <div class="word3">Harvestors</div>
                    </div>
                  </h1>
                    </div>
                </div>
            </div>
<div class="Emaillbar">

<button class="EmaillButton" type="button">
<a href="Tractor.html">
</a>&nbsp;
<b>
<font size="3" style="font-family:verdana">
    <?php
    echo "$EmailId";
    ?>
</font>
</b>
</button>
<div class="EmaillContent">
    <a href="Tractor.html">Profile</a>
    <a href="../Home.html">LogOut</a>    
</div>
    </div>
    <br>
<br>
<header>
<img src="../Images/Logo.jpg" alt="Logo.jpg" class="Logo1"/>
<a href="../homeloggedin.php?UEmail=<?php echo "$EmailId";?>">
<button class="button1" type="button">
<img src="../Images/homelogo.jpg" class="homelogo">
<b>
<font size="5.75" style="font-family:verdana">
Home
</font><br>
</b>
</button>
</a>&nbsp;

<a href="AboutUS.php?UEmail=<?php echo "$EmailId";?>">
<button class="button2" type="button">
<img src="../Images/Abt.png" alt="Logo.jpg" class="abtlogo"/>

<b>
<font size="5.75" style="font-family:verdana">
About Us
</font>
</b>
</button>
</a>&nbsp;
<div class="Harvbar">
<a href="harvester.php?UEmail=<?php echo "$EmailId";?>">
<button class="HarButton" type="button">
<img src="../Images/Harvestor.png" alt="Logo.jpg" class="abtlogo"/>

<b>
<font size="5.75" style="font-family:verdana">
Harvestor</font>
</b>
</button>
</a>&nbsp;

<div class="HarvContent">
<a href="harvester.php?UEmail=<?php echo "$EmailId";?>">Borrow</a>
<a href="harv_lend_1.php?UEmail=<?php echo "$EmailId";?>">Lend</a>
</div>
</div>
<div class="Implebar">

<a href="implements.php?UEmail=<?php echo "$EmailId";?>">
<button class="ImpleButton" type="button">
<img src="../Images/Implements.png" alt="Logo.jpg" class="abtlogo"/>
<b>
<font size="5.75" style="font-family:verdana">
Implements
</font>
</b>
</button>
</a>&nbsp;

<div class="ImpleContent">
<a href="Implements.php?UEmail=<?php echo "$EmailId";?>">Borrow</a>
<a href="imple_lend_1.php?UEmail=<?php echo "$EmailId";?>">Lend</a>
</div>
</div>
<div class="Tracbar">
<a href="tractor.php?UEmail=<?php echo "$EmailId";?>">

<button class="TracButton" type="button">
<img src="../Images/Tractor.png" alt="Logo.jpg" class="abtlogo"/>
<b>
<font size="5.75" style="font-family:verdana">
Tractor
</font>
</b>
</button>
</a>&nbsp;

<div class="TracContent">
<a href="tractor.php?UEmail=<?php echo "$EmailId";?>">Borrow</a>
<a href="trac_lend_1.php?UEmail=<?php echo "$EmailId";?>">Lend</a>    
</div>
</div>
<div class="Plantbar">

<a href="PlantNutrition.php?UEmail=<?php echo "$EmailId";?>">

<button class="PlantButton" type="button">
<img src="../Images/PlantNutrition.png" alt="Logo.jpg" class="abtlogo"/>

<b>
<font size="5.75" style="font-family:verdana">
Plant Nutrition
</font>
</b>
</button>
</a>&nbsp;
<div class="PlantContent">
<a href="Soil Health.php?UEmail=<?php echo "$EmailId";?>">Soil Health</a>
<a href="Soilissue.php?UEmail=<?php echo "$EmailId";?>">Soil Issue</a>
<a href="Nutritions.php?UEmail=<?php echo "$EmailId";?>">Nutrients</a>
<a href="Elements.php?UEmail=<?php echo "$EmailId";?>">Element</a>
<a href="pesticides.php?UEmail=<?php echo "$EmailId";?>">Pesticides</a>
<a href="Crops.php?UEmail=<?php echo "$EmailId";?>">Crops</a>    
<a href="Plant Growth.php?UEmail=<?php echo "$EmailId";?>">Plant Growth</a>
<a href="Preventation.php?UEmail=<?php echo "$EmailId";?>">Preventation</a>
</div>
</div> 
</header>
        <img src="../Images/image.jpg" width="757" height="300" class="img1">
        <img src="../Images/image1.jpg" width="757" height="300" class="img1">
        <h1 class="class1">About FarmTech</h1>
        <p class="tab1">FarmTech as Farm means 'Farmer' and Tech means 'Technology'. Farmer Technology mean use technology in the agriculture fields.  Many Farmers are not able for purchase agriculture Tools because high cost Tools are come in market. In india poverty rate is more so many farmers are not able to purchase Tools. So they are take Tools at rent for their use.</p>
        <p class="tab2">First, Why farmers take Tools at rent- Because by Tools the work in agriculture field is very easy and time saving. In agriculture feild many work like plough in field are very hard by the hand and animals use so the farmers are use Tools. By Tools work is very easy to complete in very minimum time.</p> 
        <p class="tab3">In this application we provides Tools for farmers. As, method In Lend farmer are give their detail for own and their tools to whom give for rent. In Borrow the farmer who take Tools at rent.
            Mainly we provide the Tools who farmer are not able to purchace Tools. Farmer are able to take Tools by their sutiable location. 
        </p>
        <p class="tab4">we provides agriculture tools as:-</p>
        <ul type="square" class="tab5">
            <li>Harvestors</li>
            <li>Implements</li>
            <li>Tractors</li>
        </ul>
        <p class="tab6">We do better Way to this Tech to help for farmers. To provide Tools for farmers in Low coast by farmers. By help of Tools Farmers are able to complete are work.</p>
        
        <br><br>
        <h1 class="agri">Agriculture Tools and Uses</h1>
        <p class="Farm" id="Farmid">Harvestors</p>
        <button class="tractors">
            <img src="../Images/harvestor1.jpg" class="butimage" width="175px" height="100px">
            <p class="text">Kartar 4000</p>
        </button>
        <button class="tractors">
            <img src="../Images/harvestor2.jpg" class="butimage"  width="175px" height="100px">
            <p class="text">Preet 987</p>
        </button>
        <button class="tractors">
            <img src="../Images/harvestor3.jpg" class="butimage"  width="175px" height="100px">
            <p class="text">Mahindra MSI 457 3A</p>
        </button>
        <button class="tractors"> 
            <img src="../Images/harvestor4.jpg" class="butimage"  width="200px" height="100px">
            <p class="text">Claas Crop Tiger 40 Multicrop</p>
        </button>
        <button class="tractors">
            <img src="../Images/harvestor5.jpg" class="butimage"  width="175px" height="100px">
            <p class="text">Kartar 4000 Maize</p>
        </button>
        <button class="tractors">
            <img src="../Images/harvester6.jpg" class="butimage"   width="175px" height="100px">
            <p class="text">Claas JAGUAR 870-830</p>
        </button>
        <p class="Farm" id="Farmid1">Implements</p>
        <button class="tractors">
            <img src="../Images/r1.jpg" class="butimage" width="175px" height="100px">
            <p class="text">Reverse Forward Rotary Tiller</p>
        </button>
        <button class="tractors">
            <img src="../Images/c1.jpg" class="butimage" width="175px" height="100px">
            <p class="text">Heavy Duty Rigid Cultivator</p>
        </button>
        <button class="tractors">
            <img src="../Images/p1.jpg" class="butimage" width="175px" height="100px">
            <p class="text">Reversible MB Plough</p>
        </button>
        <button class="tractors">
            <img src="../Images/h1.png" class="butimage" width="200px" height="100px">
            <p class="text">Hydraulic Harrow Heavy Series</p>
        </button>
        <button class="tractors">
            <img src="../Images/t1.jpg" class="butimage" width="175px" height="100px">
            <p class="text">Trolley</p>
        </button>
        <button class="tractors">
            <img src="../Images/ta1.jpg" class="butimage" width="175px" height="100px">
            <p class="text">BS-21 Battery</p>
        </button>
        <p class="Farm" id="Farmid1">Tractor</p>
        <button class="tractors">
            <img src="../Images/tractor1.jpg" class="butimage" width="175px" height="100px">
            <p class="text">Massey Ferguson 241 DI</p>
        </button>
        <button class="tractors">
            <img src="../Images/tractor2.jpg" class="butimage" width="175px" height="100px">
            <p class="text">Swaraj 735 FE</p>
        </button>
        <button class="tractors">
            <img src="../Images/tractor3.jpg" class="butimage" width="175px" height="100px">
            <p class="text">Swaraj 855 FE</p>
        </button>
        <button class="tractors">
            <img src="../Images/tractor4.jpg" class="butimage" width="175px" height="100px">
            <p class="text">Farmtrac 45 Powermaxx</p>
        </button>
        <button class="tractors">
            <img src="../Images/tractor5.jpg" class="butimage" width="175px" height="100px">
            <p class="text">Powertrac Euro 55 Next</p>
        </button>
        <button class="tractors">
            <img src="../Images/tractor6.jpg" class="butimage" width="175px" height="100px">
            <p class="text">Swaraj 960 FE</p>
        </button>
        <h3 class="Farm" id="Farmid">
            Harvester
        </h3>
        <p class="far">Harvesting is the process of gathering a ripe crops from the fields. Reaping the crop very fast in one time</p>
        <h3 class="Farm" id="Farmid">
            Implements
        </h3>
        <p class="far">Implements are agriculture decrease labour work for farmers. By implements work as soil improve by plough in past time plough are use by hand. After Technology PLough are convert into machine many plough in one Tools.</p>
        <h3 class="Farm" id="Farmid">
            Tractors
        </h3>
        <p class="far">Tractor are more important part in agriculture. Tractor are the first priority in agriculture. Harvestor, Implements Tools are also used by tractor. Tractor are used as ploughing, give seed, pesticides, give water.</p>
        <p class="footer">

        </p>
        </body>
    </html>