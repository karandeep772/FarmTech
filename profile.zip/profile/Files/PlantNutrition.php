
<?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    
    $conn = mysqli_connect($servername, $username, $password );
    if (!$conn){
        die("Sorry we failed to connect: " . mysqli_connect_error());
    }
        //echo "Connection was successful";
session_start();
if(isset($_GET['UEmail']))
{
$EmailId = $_GET['UEmail'];

}
//echo "$EmailId";

?>
<!Doctype html>
<HTML lang="en">
    <head>
        <style>
            body{
                margin:0px;
            }
            .button1 {
                position:absolute;
                right: 1125px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button2 {
                position:absolute;
                right: 950px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button3 {
                position:absolute;
                right: 765px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button4 {
                position:absolute;
                right:550px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button5 {
                position:absolute;
                right: 400px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button6 {
                position:absolute;
                right: 150px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button7 {
                position:absolute;  
                right: 0px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 125px;
            }
            .button8 {
                position:absolute;
                right:139px;
                cursor: pointer;
                margin-top: 35px;
            } 
            .button9 {
                position:absolute;
                right:8px;
                cursor: pointer;
                margin-top: 35px;
            }
            .button10 {
                position:absolute;  
                right: 10px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 20px;
            } 
            .Logo1 {
                height: 70px;
                width: 110px;
                margin:2px;
                margin-left:50px ;
                margin-top: 14px;
                border-radius: 20px;
                border:1px solid black;
                position: absolute;
            }
            header{
                background-color: aqua;
                height:100px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                margin-top:50px; 
            }
            .animate-charcter{
                text-transform: uppercase;
                background-image: linear-gradient(
                -225deg,
                #231557 0%,
                #44107a 29%,
                #ff1361 67%,
                #fff800 100%
                );
                background-size: auto auto;
                background-clip: border-box;
                background-size: 200% auto;
                color: #fff;
                background-clip: text;
                text-fill-color: transparent;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: textclip 2s linear infinite;
                display: inline-block;
                font-size: 28px;
                margin-top: 22px;
                margin-bottom: 10px;
                margin-left: 505px;
                position:absolute;
            }

            @keyframes textclip {
                to {
                background-position: 200% center;
                }
            }

            body {
                display: absolute;
                align-items: center;
                justify-content: center;
            }
            h1 {
                color: #160404;
                font-family: tahoma;
                font-size: 28px;
                font-weight 900px;
                text-transform: uppercase;
                overflow: hidden;
                position: absolute;
                width: 575px;
                margin-left: 575px;
                margin-top: 20px;
            }

            h1 span {
                font-size: 28px;
                margin-left: 115px;
                margin-top: 20px;
            }

            .message {
                background-color: rgb(244, 228, 84);
                color: #333;
                display: block;
                font-weight: 900px;
                overflow: hidden;
                font-size:28px;
                position: absolute;
                left: 350px;
                animation: openclose 5s ease-in-out infinite;
            }

            .word1, .word2, .word3 {
                font-family: tahoma;
            }

            @keyframes openclose {
                0% {
                    top: 0rem;
                    width: 0;
                }
                5% {
                    width: 40px;
                }
                15% {
                    width: 100px;
                }
                30% {
                    top: 0rem;
                    width: 160px;
                }
                33% {       
                    top: 0rem;
                    width: 0;
                }
                35% {
                    top: 0rem;
                    width: 0;
                }
                38% {
                top: -2.1rem;
    
                }
                48% {
                    top: -2.1rem;
                    width: 100px;
                }
                62% {
                    top: -2.1rem;
                    width: 200px;
                }
                66% {
                    top: -2.1rem;
                    width: 0;
                    text-indent: 0;
                }
                68% {
                    top: -2.1rem;   
                    width: 0;
                    text-indent: 0;
                }
                71% {
                    top: -4.2rem;
                    width: 0;
                }
                80% {
                    top: -4.2rem;
                    width: 100px;
                }
                95% {
                    top: -4.2rem;
                    width: 200px;
                }
                98% {
                    top: -4.2rem;
                    width: 0;
                }
                100% {
                    top: 0;
                    width: 0;
                }
                }   
                .homelogo {
                    height: 21px;
                    width: 21px;
                    border-radius: 20px;
                }
                .abtlogo{
                    height: 21px;
                    width: 21px;
                }
                .input{
                    width:500px;
                    height:25px;
                    float:right;
                    margin-right: 70px;
            }
            .H1{
                margin-left:580px;
                font-size:px;
                margin-top: 20px;
            }
            .search{
                float:right;
                margin-top: 40px;
                margin-right: -47px;;
            }
            box{
                border:2px solid black;
            }
            .tractors{
                border:none;
                border:1px solid rgb(205, 204, 204);
                margin: 8px;
                padding: 0px;
                background-color: white;
                margin-left: 0px;
            }
            main{
                margin-left: 130px;
                margin-top: 50px;
            }
            .butimage{
                padding:0px;
                margin: 0px;
            }
            .book{
                background-color: rgb(71, 71, 245);
                height: 30px;
                margin-bottom: 0px;
                margin-top: 0px;
            }
            .book1{
                margin-bottom: 0px;;
                margin-top: -20px;
            }
            .text:hover{
                  color:red;
                  cursor:pointer;
            }
            button{
                cursor: pointer;
            }
            .book:hover
            {
                background-color: rgb(251, 41, 41);
            }

            @import url('https://fonts.googleapis.com/css2?family=Alfa+Slab+One&display=swap');
        .waviy {
                
                font-size: 20px;
                margin-top: -10x;

            }
            .waviy span {
                font-family: 'Alfa Slab One', simple;
                position: relative;
                display: inline-block;
                color: black;
                text-transform: uppercase;
                animation: waviy 1.25s infinite;
                animation-delay: calc(.1s * var(--i));
            }
            @keyframes waviy {
                0%,50%,100% {
                transform: translateY(0)
            }
                50% {
                transform: translateY(-20px)
            }
            }
            .but{
                margin-left: 145px;
                margin-top: 75px;
                padding: 0px;
                border-top-right-radius: 75px;
               border-top-left-radius: 75px;
               border-bottom-left-radius: 20px;
               border-bottom-right-radius: 20px;
            }
            .imgbut{
                margin: 0px;
               border-top-right-radius: 75px;
               border-top-left-radius: 75px;
            }
            .para{
                background-color: #f6f157;
                height:5px;
                margin-top: 75px;
                margin-bottom: 0px;
            }
            .soil{
                    background-color: rgb(124, 1, 1);
                    height: 100px;
                    text-align: center;
                    color:white;
                    margin-top: 0px;
                    margin-left: 0px;
                    margin-right: 0px;
                    width: 1519px;
                 }
                 s{
                    display: flex;
                    margin-top: 100px;

                }
                .para2{
                    text-align: center;
                    margin-left: 100px;
                    margin-right:100px ;
                    font-size: larger;
                    margin-top: 125px;
                }
                .para1{
                    text-align: left;
                    margin-left: 100px;
                    margin-right:100px ;
                    font-size: larger;
                    margin-top: 50px;
                }
                .cl{
                    margin-bottom: 0px;
                }
                .ero{
                    background-color: rgb(231, 169, 114);
                    width: 1536px;
                    height: 100px;
                    text-align:center;
                    color: white;
                    margin: 0px;
                }
                .para3{
                    text-align: center;
                    margin-left: 100px;
                    margin-right:100px ;
                    font-size: larger;
                    margin-top: 125px;
                }
                .erosion{
                    padding: 0px;
                    margin:50px;
                }
                .erosion1{
                    padding:0px;
                }
                .eros{
                    font-size: larger;
                }
                erosion4{
                    margin-left: 50px;
                }
                erosion2{
                    margin-left: 190px;
                }
                .para3{
                    text-align: left;
                    margin-left: 100px;
                    margin-right:100px ;
                    font-size: larger;
                    margin-top: 30px;
                }
                .NUT{
                    background-color: #1eee71;
                    height: 100px;
                    text-align: center;
                    color:white;
                    margin-top: 0px;
                    margin-left: 0px;
                    margin-right: 0px;
                    width: 1520px;
                 }
                ab{
                    display: flex;
                    margin-top: 100px;
                }
                .elements{
                    background-color: rgb(56, 215, 38);
                    width: 1520px;
                    height: 100px;
                    text-align:center;
                    color: white;
                    margin: 0px;
                }
                .para4{
                    text-align: center;
                    margin-left: 100px;
                    margin-right:100px ;
                    font-size: larger;
                    margin-top: 50px;
                }
                .foot{
                    background-color:rgb(250, 204, 144) ;
                    height: 30px;
                    margin-bottom: 0px;
                }
                .pesc{
                    background-color: rgb(15, 67, 1);
                    height: 100px;
                    text-align: center;
                    color:white;
                    margin-top: 0px;
                    margin-left: 0px;
                    margin-right: 0px;
                    width: 1520px;
                 }
                 abcd{
                    display: flex;
                    margin-top: 100px;
                }
                .crop{
                    background-color: rgb(54, 217, 45);
                    height: 100px;
                    text-align: center;
                    color:white;
                    margin-top: 0px;
                    margin-left: 0px;
                    margin-right: 0px;
                    width: 1520px;
                 }
                 .foot1{
                    background-color:rgb(184, 211, 232) ;
                    height: 30px;
                    margin-bottom: 0px;
                }
                .growth{
                    background-color: rgb(54, 217, 45);
                    height: 100px;
                    text-align: center;
                    color:white;
                    margin-top: 0px;
                    margin-left: 0px;
                    margin-right: 0px;
                    width: 1520px;
                 }
                 .pesc{
                    background-color: rgb(15, 67, 1);
                    height: 100px;
                    text-align: center;
                    color:white;
                    margin-top: 0px;
                    margin-left: 0px;
                    margin-right: 0px;
                    width: 1520px;
                 }
                 .foot3{
                    background-color:rgb(20, 19, 19) ;
                    height: 30px;
                    margin-bottom: 0px;
                }
            .HarButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }

            .Harvbar {
                
                right: 760px;
                position: absolute;
                display: inline-block;
            }

            .HarvContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .HarvContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .HarvContent a:hover {
                background-color: #ddd;
            }

            .Harvbar:hover .HarvContent {
                display: block;
            }

            .Harvbar:hover .HarButton {
                background-color: #3e8e41;
            }
            
            .ImpleButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Implebar {
                
                right: 550px;
                position: absolute;
                display: inline-block;
            }

            .ImpleContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .ImpleContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .ImpleContent a:hover {
                background-color: #ddd;
            }

            .Implebar:hover .ImpleContent {
                display: block;
            }

            .Implebar:hover .ImpleButton {
                background-color: #3e8e41;
            }

            .TracButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Tracbar {
                
                right: 400px;
                position: absolute;
                display: inline-block;
            }

            .TracContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .TracContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .TracContent a:hover {
                background-color: #ddd;
            }

            .Tracbar:hover .TracContent {
                display: block;
            }

            .Tracbar:hover .TracButton {
                background-color: #3e8e41;
            }

            .PlantButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Plantbar {
                
                right: 150px;
                position: absolute;
                display: inline-block;
            }

            .PlantContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .PlantContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .PlantContent a:hover {
                background-color: #ddd;
            }

            .Plantbar:hover .PlantContent {
                display: block;
            }

            .Plantbar:hover .PlantButton {
                background-color: #3e8e41;
            }
.EmaillButton {
    color: black;
    padding: 4px;
    font-size: 10px;
    margin-top: 33px;
    border-bottom:1px solid rgb(0, 0, 0);
    border-top: 1px solid rgb(0, 0, 0);
    border-left: 1px solid rgb(0, 0, 0);
    border-right: 1px solid rgb(0, 0, 0);
    border-radius: 20px;
}

.Emaillbar {
    
    right: 5px;
    position: absolute;
    display: inline-block;
}

.EmaillContent {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
    text-align: center  ;
}

.EmaillContent a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.EmaillContent a:hover {
    background-color: #ddd;
}

.Emaillbar:hover .EmaillContent {
    display: block;
}

.Emaillbar:hover .EmaillButton {
    background-color: #3e8e41;

}
        </style>
        <meta charset="UTF-8">
        <title>
            Main Page
            </title>
            <link rel="icon" href="Logo.jpg">
        </head>
    <body>
            <div>
                <div>
                    <div">
                        <h3 class="animate-charcter"> Farm Tech:</h3>
                <h1>
                    <span>Lend/Borrow</span>
                    <div class="message">
                      <div class="word1">Tractors</div>
                      <div class="word2">Implements</div>
                      <div class="word3">Harvestors</div>
                    </div>
                  </h1>
                    </div>
                </div>
            </div>
            

            <div class="Emaillbar">

                <button class="EmaillButton" type="button">
                <a href="Tractor.html">
                </a>&nbsp;
                <b>
                <font size="3" style="font-family:verdana">
                    <?php
                    echo "$EmailId";
                    ?>
                </font>
                </b>
                </button>
                <div class="EmaillContent">
                    <a href="Tractor.html">Profile</a>
                    <a href="../Home.html">LogOut</a>    
                </div>
                    </div>
                    <br>
                <br>
                <header>
                <img src="../Images/Logo.jpg" alt="Logo.jpg" class="Logo1"/>
                <a href="../homeloggedin.php?UEmail=<?php echo "$EmailId";?>">
                <button class="button1" type="button">
                <img src="../Images/homelogo.jpg" class="homelogo">
                <b>
                <font size="5.75" style="font-family:verdana">
                Home
                </font><br>
                </b>
                </button>
                </a>&nbsp;
                
                <a href="AboutUS.php?UEmail=<?php echo "$EmailId";?>">
                <button class="button2" type="button">
                <img src="../Images/Abt.png" alt="Logo.jpg" class="abtlogo"/>
                
                <b>
                <font size="5.75" style="font-family:verdana">
                About Us
                </font>
                </b>
                </button>
                </a>&nbsp;
                <div class="Harvbar">
                <a href="harvester.php?UEmail=<?php echo "$EmailId";?>">
                <button class="HarButton" type="button">
                <img src="../Images/Harvestor.png" alt="Logo.jpg" class="abtlogo"/>
                
                <b>
                <font size="5.75" style="font-family:verdana">
                Harvestor</font>
                </b>
                </button>
                </a>&nbsp;
                
                <div class="HarvContent">
                <a href="harvester.php?UEmail=<?php echo "$EmailId";?>">Borrow</a>
                <a href="harv_lend_1.php?UEmail=<?php echo "$EmailId";?>">Lend</a>
                </div>
                </div>
                <div class="Implebar">
                
                <a href="implements.php?UEmail=<?php echo "$EmailId";?>">
                <button class="ImpleButton" type="button">
                <img src="../Images/Implements.png" alt="Logo.jpg" class="abtlogo"/>
                <b>
                <font size="5.75" style="font-family:verdana">
                Implements
                </font>
                </b>
                </button>
                </a>&nbsp;
                
                <div class="ImpleContent">
                <a href="Implements.php?UEmail=<?php echo "$EmailId";?>">Borrow</a>
                <a href="imple_lend_1.php?UEmail=<?php echo "$EmailId";?>">Lend</a>
                </div>
                </div>
                <div class="Tracbar">
                <a href="tractor.php?UEmail=<?php echo "$EmailId";?>">
                
                <button class="TracButton" type="button">
                <img src="../Images/Tractor.png" alt="Logo.jpg" class="abtlogo"/>
                <b>
                <font size="5.75" style="font-family:verdana">
                Tractor
                </font>
                </b>
                </button>
                </a>&nbsp;
                
                <div class="TracContent">
                <a href="tractor.php?UEmail=<?php echo "$EmailId";?>">Borrow</a>
                <a href="trac_lend_1.php?UEmail=<?php echo "$EmailId";?>">Lend</a>    
                </div>
                </div>
                <div class="Plantbar">
                
                <a href="PlantNutrition.php?UEmail=<?php echo "$EmailId";?>">
                
                <button class="PlantButton" type="button">
                <img src="../Images/PlantNutrition.png" alt="Logo.jpg" class="abtlogo"/>
                
                <b>
                <font size="5.75" style="font-family:verdana">
                Plant Nutrition
                </font>
                </b>
                </button>
                </a>&nbsp;
                <div class="PlantContent">
                <a href="Soil Health.php?UEmail=<?php echo "$EmailId";?>">Soil Health</a>
                <a href="Soilissue.php?UEmail=<?php echo "$EmailId";?>">Soil Issue</a>
                <a href="Nutritions.php?UEmail=<?php echo "$EmailId";?>">Nutrients</a>
                <a href="Elements.php?UEmail=<?php echo "$EmailId";?>">Element</a>
                <a href="pesticides.php?UEmail=<?php echo "$EmailId";?>">Pesticides</a>
                <a href="Crops.php?UEmail=<?php echo "$EmailId";?>">Crops</a>    
                <a href="Plant Growth.php?UEmail=<?php echo "$EmailId";?>">Plant Growth</a>
                <a href="Preventation.php?UEmail=<?php echo "$EmailId";?>">Preventation</a>
                </div>
                </div> 
                </header>
    <br>
    <br>
        <a href="Soil Health.html" blank>
          <button class="but">
            <img src="../Images/soilHealth.jpg" width="200px" height="200px" class="imgbut">
            <h3>Soil Health</h3>
          </button>
          </a>
          <a href="Soilissue.html">
          <button class="but">
            <img src="../Images/SoilIssue.jpg" width="200px" height="200px" class="imgbut">
            <h3>Soil Issue</h3>
          </button>
          </a>
          <a href="Nutritions.html">
          <button class="but">
            <img src="../Images/PlantNut.jpg" width="200px" height="200px" class="imgbut">
            <h3>Nutritions</h3>
          </button>
          </a>
          <a href="Elements.html">
          <button class="but">
            <img src="../Images/Elements.jpg" width="200px" height="200px" class="imgbut">
            <h3>Elements</h3>
          </button>
        </a>
        <a href="pesticides.html">
          <button class="but">
            <img src="../Images/Pesticide.jpg" width="200px" height="200px" class="imgbut">
            <h3>Pesticides</h3>
          </button>
        </a>
        <a href="Crops.html">
          <button class="but">
            <img src="../Images/Crops.jpg" width="200px" height="200px" class="imgbut">
            <h3>Crops</h3>
          </button>
          </a>
          <a href="Plant Growth.html">
          <button class="but">
            <img src="../Images/Plantgrowth.jpg" width="200px" height="200px" class="imgbut">
            <h3>Plant Growth</h3>
          </button>
       </a>
          <a href="Preventation.html">
          <button class="but">
            <img src="../Images/Prevention.jpg" width="200px" height="200px" class="imgbut">
            <h3>Preventions</h3>
          </button>
          </a>
          <p class="para"></p>
          <br>
          <h1 class="soil">Soil Health</h1>
          <br>
            <s>
            <img src="../Images/soil1.jpg" width="750px" height="250px">
            <img src="../Images/soil2.jpg" width="825px" height="250px">
            </s>
            <p class="para2">Soil health is a concept where all aspects of soil, that is, physical structure, chemical components and biological life are considered together. A soil does not have to be agriculturally productive to be healthy. However, many agricultural practices can make soils less healthy than they were in their natural state.</p>
            <p class="para2">By managing structure, nutrients and biology in the soil, farmers can use soils within their capability so that the soils can be used productively without being degraded. 
            To maintain and improve soil health, farmers need to manage their production system so that it doesn’t degrade the soil by; </p>
            <ul>
                <li class="para1">Maintaining Soil Structure</li>
                <li class="para1">Controlling Erosion </li>
                <li class="para1">Maintaining or improving soil organic matter levels </li>
                <li class="para1">Maintaining or improving nutrient levels and water holding capacity of the soil </li>
                <li class="para1">Fostering beneficial soil biological activity </li>
            </ul>
            <img src="../Images/soil3.jpg" width="1516px" height="33px" class="cl">
            <br>
            <br>
            <h1 class="ero">Soil Issues</h1>
            <p class="para2">Soil issues are those things that impact soil functions, reducing its health. NSW DPI has information on soil health and several of the soil issues facing agriculture today. </p>
            <erosion4>
            <button class="erosion">
                <img src="../Images/Erosion.jpg" width="275px" height="175px">
                <p class="eros">Soil Erosion</p>
            </button>
            <button class="erosion">
                <img src="../Images/acidity (2).jpg" width="275px" height="175px">
                <p class="eros">Soil Acidity</p>
            </button>
            <button class="erosion1">
                <img src="../Images/Bio.jpg" width="275px" height="175px">
                <p class="eros">Soil Biology</p>
            </button>
            <button class="erosion">
                <img src="../Images/carbon.jpg" width="275px" height="175px">
                <p class="eros">Soil Carbon</p>
            </button>
           <erosion2>
            <button class="erosion">
                <img src="../Images/fer.jpg" width="275px" height="175px">
                <p class="eros">Soil Fertilizers</p>
            </button>
            <button class="erosion">
                <img src="../Images/structure and sodicity.jpg" width="275px" height="175px">
                <p class="eros">Soil Structure and Sodicity</p>
            </button>
            <button class="erosion">
                <img src="../Images/type.jpg" width="275px" height="175px">
                <p class="eros">Soil Types and Condition </p>
            </button>
            </erosion2>
            </erosion4>
            <h1 class="NUT">Plant Nutrients In The Soil </h1>
            <s>
            <img src="../Images/Nutrition.jpg" width="750px" height="250px">
            <img src="../Images/Nutritions2.jpg" width="825px" height="250px">
            </s>
            <p class="para2">Soil is a major source of nutrients needed by plants for growth. The three main nutrients are nitrogen (N), phosphorus (P) and potassium (K). Together they make up the trio known as NPK. Other important nutrients are calcium, magnesium and sulfur. Plants also need small quantities of iron, manganese, zinc, copper, boron and molybdenum, known as trace elements because only traces are needed by the plant. The role these nutrients play in plant growth is complex, and this document provides only a brief outline</p>
            <p class="para4">Essential Element</p>
            <p class="para1">Source from air, water and soil.</p>
            <ul>
                <li class="para3">carbon</li>
                <li class="para3">Hydrogen</li>
                <li class="para3">Oxygen</li>
                <li class="para3">Nitrogen</li>
            </ul>
            <br>
            <p class="para1">Sources from soil, and / or fertilizers.</p>
            <ul>
                <li class="para3">Phosphrous</li>
                <li class="para3">Potassium</li>
                <li class="para3">Calcium</li>
                <li class="para3">Magnesium</li>
                <li class="para3">Sulfur</li>
                <li class="para3">Boron</li>
                <li class="para3">Zinc</li>
                <li class="para3">Copper</li>
                <li class="para3">Manganese</li>
                <li class="para3">Iron</li>
                <li class="para3">Chloride</li>
                <li class="para3">Molybdenum</li>
            </ul>
            <img src="../Images/Nutritions3.jpg" width="1517px" height="33px">
            <br><br>
            <h1 class="elements">Major Elements</h1>
            <ab>
            <img src="../Images/Nutritions2.jpg" width="800px" height="250px">
            <img src="../Images/nutt.jpg" width="800px" height="250px">
            </ab>
            <h2 class="para1">Nitrogen (N)</h2>
            <p class="para3">Nitrogen is a key element in plant growth. It is found in all plant cells, in plant proteins and hormones, and in chlorophyll. 

                Atmospheric nitrogen is a source of soil nitrogen. Some plants such as legumes fix atmospheric nitrogen in their roots; otherwise fertiliser factories use nitrogen from the air to make ammonium sulfate, ammonium nitrate and urea. When applied to soil, nitrogen is converted to mineral form, nitrate, so that plants can take it up. 
                
                Soils high in organic matter such as chocolate soils are generally higher in nitrogen than podzolic soils. Nitrate is easily leached out of soil by heavy rain, resulting in soil acidification. You need to apply nitrogen in small amounts often so that plants use all of it, or in organic form such as composted manure, so that leaching is reduced. </p>

                <h2 class="para1">Phosphorus (P)</h2>
            <p class="para3">Phosphorus helps transfer energy from sunlight to plants, stimulates early root and plant growth, and hastens maturity. 

                Very few Australian soils have enough phosphorus for sustained crop and pasture production and the North Coast is no exception. The most common phosphorus source on the North Coast is superphosphate, made from rock phosphate and sulfuric acid. All manures contain phosphorus; manure from grain-fed animals is a particularly rich source.  </p>

                <h2 class="para1">Potassium (K)</h2>
            <p class="para3">Potassium increases vigour and disease resistance of plants, helps form and move starches, sugars and oils in plants, and can improve fruit quality. 

                Potassium is low or deficient on many of the sandier soils of the North Coast. Also, heavy potassium removal can occur on soils used for intensive grazing and intensive horticultural crops (such as bananas and custard apples). 
                
                Muriate of potash and sulfate of potash are the most common sources of potassium.  </p>

                <h2 class="para1">Calcium (Ca) </h2>
            <p class="para3">Calcium is essential for root health, growth of new roots and root hairs, and the development of leaves. It is generally in short supply in the North Coast's acid soils. Lime, gypsum, dolomite and superphosphate (a mixture of calcium phosphate and calcium sulfate) all supply calcium. Lime is the cheapest and most suitable option for the North Coast; dolomite is useful for magnesium and calcium deficiencies, but if used over a long period will unbalance the calcium/magnesium ratio. Superphosphate is useful where calcium and phosphorus are needed.  </p>

                <h2 class="para1">Magnesium (Mg) </h2>
            <p class="para3">Magnesium is a key component of chlorophyll, the green colouring material of plants, and is vital for photosynthesis (the conversion of the sun's energy to food for the plant). Deficiencies occur mainly on sandy acid soils in high rainfall areas, especially if used for intensive horticulture or dairying. Heavy applications of potassium in fertilisers can also produce magnesium deficiency, so banana growers need to watch magnesium levels because bananas are big potassium users. 

                Magnesium deficiency can be overcome with dolomite (a mixed magnesium-calcium carbonate), magnesite (magnesium oxide) or epsom salts (magnesium sulfate).  </p>

                <h2 class="para1">Sulfur (S) </h2>
            <p class="para3">Sulfur is a constituent of amino acids in plant proteins and is involved in energy-producing processes in plants. It is responsible for many flavour and odour compounds in plants such as the aroma of onions and cabbage. 

                Sulfur deficiency is not a problem in soils high in organic matter, but it leaches easily. On the North Coast seaspray is a major source of atmospheric sulfur. Superphosphate, gypsum, elemental sulfur and sulfate of ammonia are the main fertiliser sources. 
                
                Trace elements </p>
                <br><br>
                <h1 class="pesc">Pesticides</h1>
            <abcd>
            <img src="../Images/pes.jpg" width="750px" height="250px">
            <img src="../Images/pes1.jpg" width="825px" height="250px">
            </abcd>
            <p class="para2">Pesticides are chemical compounds that are used to kill pests, including insects, rodents, fungi and unwanted plants (weeds). Over 1000 different pesticides are used around the world.Pesticides are used in public health to kill vectors of disease, such as mosquitoes, and in agriculture to kill pests that damage crops. </p>
            <p class="para2">Pesticides are chemical substances that are meant to kill pests. In general, a pesticide is a chemical or a biological agent such as a virus, bacterium, antimicrobial, or disinfectant that deters, incapacitates, kills, pests </p>
            <p class="para2">This use of pesticides is so common that the term pesticide is often treated as synonymous with plant protection product. It is commonly used to eliminate or control a variety of agricultural pests that can damage crops and livestock and reduce farm productivity. The most commonly applied pesticides are insecticides to kill insects, herbicides to kill weeds, rodenticides to kill rodents, and fungicides to control fungi, mould, and mildew </p>
            <p class="para1">Types Of Pesticides</p>
            <p class="para1">These are grouped according to the types of pests which they kill:</p>
            <p class="para1">Grouped by Types of Pests They Kill </p>
            <ol>
                <li class="para1">Insecticides – insects </li>
                <li class="para1">Herbicides – plants </li>
                <li class="para1">Rodenticides – rodents (rats & mice) </li>
                <li class="para1">Bactericides – bacteria  </li>
                <li class="para1">Fungicides – fungi </li>
                <li class="para1">Larvicides – larvae  </li>
            </ol>
            <p class="para1">Based on how biodegradable they are: </p>
            <p class="para1">Pesticides can also be considered as:  </p>
        <ul>
            <li class="para1">Biodegradable: The biodegradable kind is those which can be broken down by microbes and other living beings into harmless compounds. </li>
            <li class="para1">Persistent: While the persistent ones are those which may take months or years to break down. </li>
        </ul>
        <p class="foot"></p>
        <br><br>
        <h1 class="crop">Crops</h1>
            <abcd>
            <img src="../Images/crop.jpg" width="825px" height="250px">
            <img src="../Images/crop1.jpg" width="825px" height="250px">
            </abcd>
            <p class="para2">Cropping Seasons in India  </p>
            <p class="para2">India ranks second in the world when it comes to arable land. With 394.6 million acres of agricultural land, India grows the following crops; to name a few; in massive quantities: </p>
            <ul>
                <li class="para1">Rice</li>
                <li class="para1">Wheat</li>
                <li class="para1">Cotton</li>
                <li class="para1">Sugar Cane</li>
                <li class="para1">Fruit and vegetables of various kinds </li>
                <li class="para1">Maize </li>
            </ul>
            <h2 class="para2">Every crop has its own distinct processes of planting, harvesting, and processing. But, broadly speaking, each crop can be differentiated according to cropping season. And in India, there are three main cropping seasons: </h2>
            <ul>
                <li class="para1">Kharif</li>
                <li class="para1">Rabi</li>
                <li class="para1">Zaid</li>
            </ul>
             <br><br>
            <p class="para1">Kharif Crops</p>
            <p class="para1">Interestingly, the word ‘Kharif’ means autumn in Arabic and this best denotes the season for Kharif crops too! Also known as monsoon crops, Kharif crops are sown at the start of the monsoon season and harvested at the end of the same. Typically, this period ranges from May to October, give or take a month or so, depending on the crop.  Zaid crops also help the farmers make money on produce such as melons of various kinds, pumpkins, and cucumber. These seasonal fruits are mostly grown in the Gangetic belts of India. Fodder crops are examples of Zaid crops too.</p>
            <br>
            <p class="para1">Rabi Crops</p>
            <p class="para1">Rabi crops are planted around the October or middle of November, well after the rainy season. The crops are harvested in April or May, depending on the type of crop. The word ‘Rabi’ comes from Arabic for spring. They are also known as winter crops. India grows Rabi crops such as wheat, mustard, barley, peas, chickpea, cumin, fennel, Coriander, and gram to name a few. States such as Jammu & Kashmir, Uttar Pradesh, Punjab, Himachal Pradesh, and Uttarakhand are a few of the states that lead in Rabi crop production. Uttar Pradesh is the largest producer of wheat followed by Haryana and Punjab</p>
            <br>
            <p class="para1">Zaid Crops</p>
            <p class="para1">Summer belongs to the Zaid crops! They are sometimes known as the ‘filler’ crops between Rabi & Kharif. Typically, the crops are planted in March and harvested in June. This is a short season, but Zaid crops need warm, dry weather, and mature early as well.</p>

        </ul>
        <p class="foot1"></p>
        <br><br>
        <h1 class="growth">Plant Growth</h1>
            <abcd>
            <img src="../Images/growth.jpg" width="825px" height="250px">
            <img src="../Images/growth1.jpg" width="825px" height="250px">
            </abcd>
            <p class="para2">GROWTH OF PLANTS</p>
            <p class="para2">Gardening can be a deeply rewarding hobby. It can relieve stress, beautify your home and supply you with fresh food. But growing your plants can be a tricky process. Not all of us are born with green thumbs; we learn the best ways on how to encourage growth of your plants through trial and error. </p>
            <p class="par">Our landscaping experts at ABC Scapes got their green thumbs from years of experience working with our client’s plants, lawns and gardens. Here’s ten things that they know will help you encourage growth of plants.  </p>
            <br><br>
            <h3 class="para1">Preparation Is Key </h3>
            <p class="para1">The key to growing plants the right way is to make sure that the soil is prepared properly before you start planting. Loosen soil to at least six inches, mix in organic matter such as manure, peat moss or compost, and then level it by raking. Also do your due diligence by researching the plants you want to grow and see what environmental conditions they’ll need to survive and thrive in.  </p>
            <br><br>
            <h3 class="para1">Use The Right Fertilizer  </h3>
            <p class="para1">If you’re trying to grow something very quickly, you’ll want to use a liquid fertilizer. If you’re growing something over a long stretch of time, use a granular fertilizer. Granular fertilizers are coated in a resin that slowly releases nutrients into the soil over time. These are great for flower beds and other long-term projects. Liquid fertilizers tend to be more expensive and need to be used every few weeks to maintain their effectiveness, but they do encourage faster growth than the granular fertilizers are capable of.   </p>
            <p class="para1">You’ll also want to check to see if the fertilizer you’re using contains plant food. If you’re just growing one type of plant, this won’t be a problem. If you’re growing a variety of different plants close together, you’re better off picking a fertilizer that doesn’t contain plant food. Always check to see what nutrients your plants need most when picking your fertilizer.  </p>
            <br><br>
            <h3 class="para1">Soak Seeds In Tea </h3>
            <p class="para1">One way to encourage seeds to germinate is to soak them in cold tea before planting. The tannins in the tea will soften the casing of the seed, which will make it much easier for your plant to grow. Chamomile tea is especially effective, as it contains anti-fungal properties that reduce “damping off” — a horticultural disease that weakens or kills seeds before they have a chance to germinate.  </p>
            <br><br>
            <h3 class="para1">Grow Seedlings Inside </h3>
            <p class="para1">If you are going to grow plants outside and it isn’t spring yet, try growing your seeds inside. Seedlings take between four to 12 weeks to sprout. If you let the seedlings sprout inside and then transplant them to your garden, the plants will end up growing four to six weeks earlier than if you had planted them directly into the flower bed! There are some plants that will not transplant well, though, so you’ll have to be careful. Beans, beets, zucchini, peas, corn, spinach and turnip don’t transplant very well, while tomatoes, melons, eggplants and peppers take to it quickly.  </p>
            <br><br>
            <h3 class="para1">Spice It Up  </h3>
            <p class="para1">If you want to keep ravenous insects away from your plants, consider growing some curry plants. Most insects tend to avoid these kinds of plants. You can also repel insects away from your plants by periodically sprinkling lines of curry or cayenne pepper on your flower bed. </p>
            <p class="para1">If you’re having ant problems, you can keep them at bay by growing a lavender bush. Ants hate the aroma of flowering lavender. You can also deal with your ant problems by placing half a squeezed orange on the ground. Wait for the ants to swarm the orange; once you got a large horde on there devouring the citrus, pick it up and leave the fruit in a place with birds nearby. They’ll happily swoop in to take care of your ant problem. </p>
            <br><br>
            <h3 class="para1">Support Your Plants  </h3>
            <p class="para1">As plants flower from seedlings into full-blown adult forms, they may need physical support to help them grow into their maturity. Certain tall flowers and plants may have to be tied to stakes to keep them growing right. You may have to pinch out the centers of young flowering plants to encourage them to have more bushy side-growth. And you might need to prune out branches and leaf clusters that block sunlight from feeding the interior of the plant, or removing faded flower-heads from your bushes to encourage new growth from your plants. </p>
            <br><br>
            <h3 class="para1">Take Their Pulse </h3>
            <p class="para1">Water is the lifeblood of your plants. Too much water can stunt them; not enough will kill them. One way to know if your plant is getting enough water is to stick a spade about 6 to 12 inches into the soil. Pull the soil back and inspect it: if it looks and feel moist, you’re good to go. If it’s bone dry, you’ll need to water your plants immediately. </p> 
        </ul>
        <p class="foot"></p>
    
<br><br>
    <h1 class="pesc">Pesticides</h1>
      <abcd>
      <img src="../Images/pes.jpg" width="825px" height="250px">
      <img src="../Images/pes1.jpg" width="825px" height="250px">
      </abcd>
      <p class="para2">Pesticides are chemical compounds that are used to kill pests, including insects, rodents, fungi and unwanted plants (weeds). Over 1000 different pesticides are used around the world.Pesticides are used in public health to kill vectors of disease, such as mosquitoes, and in agriculture to kill pests that damage crops. </p>
      <p class="para2">Pesticides are chemical substances that are meant to kill pests. In general, a pesticide is a chemical or a biological agent such as a virus, bacterium, antimicrobial, or disinfectant that deters, incapacitates, kills, pests </p>
      <p class="para2">This use of pesticides is so common that the term pesticide is often treated as synonymous with plant protection product. It is commonly used to eliminate or control a variety of agricultural pests that can damage crops and livestock and reduce farm productivity. The most commonly applied pesticides are insecticides to kill insects, herbicides to kill weeds, rodenticides to kill rodents, and fungicides to control fungi, mould, and mildew </p>
      <p class="para1">Types Of Pesticides</p>
      <p class="para1">These are grouped according to the types of pests which they kill:</p>
      <p class="para1">Grouped by Types of Pests They Kill </p>
      <ol>
          <li class="para1">Insecticides – insects </li>
          <li class="para1">Herbicides – plants </li>
          <li class="para1">Rodenticides – rodents (rats & mice) </li>
          <li class="para1">Bactericides – bacteria  </li>
          <li class="para1">Fungicides – fungi </li>
          <li class="para1">Larvicides – larvae  </li>
      </ol>
      <p class="para1">Based on how biodegradable they are: </p>
      <p class="para1">Pesticides can also be considered as:  </p>
  <ul>
      <li class="para1">Biodegradable: The biodegradable kind is those which can be broken down by microbes and other living beings into harmless compounds. </li>
      <li class="para1">Persistent: While the persistent ones are those which may take months or years to break down. </li>
  </ul>
       
  <p class="foot3"></p>
        </body>
    </html>