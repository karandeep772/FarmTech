<?php


if(isset($_POST['FirstName'])){
$servername = "localhost";
$username = "root";
$password = "";

$conn = mysqli_connect($servername, $username, $password );
if (!$conn){
    die("Sorry we failed to connect: " . mysqli_connect_error());
}
    //echo "Connection was successful";

$FirstName = $_POST['FirstName'];
$LastName = $_POST['LastName'];
$Gender = $_POST['Gender'];
$Age = $_POST['Age'];
$MobileNumber = $_POST['MobileNumber'];
$EmailId = $_POST['EmailId'];
$State = $_POST['State'];
$District = $_POST['District'];
$Tehsil = $_POST['Tehsil'];
$Pincode = $_POST['Pincode'];
$Password = $_POST['Password'];
$ConfirmPassword = $_POST['ConfirmPassword']; 

$sql ="INSERT INTO `farmtech`.`users` (`FirstName`, `LastName`, `Gender`, `Age`,
 `MobileNumber`, `EmailId`, `State`, `District`, `Tehsil`, `Pincode`, `Password`,
  `ConfirmPassword`, `dt`) VALUES ('$FirstName', '$LastName', '$Gender', '$Age', '$MobileNumber',
  '$EmailId', '$State', '$District', '$Tehsil','$Pincode', '$Password',
  '$ConfirmPassword', current_timestamp())";
  
if($conn->query($sql)==true){
    //echo"successfully inserted";
}else{
    echo"ERROR: $sql<br> $conn->error";
}
$conn->close();
}
?>



<!Doctype html>
<HTML lang="en">
    <head>
        <style>
            body{
                margin:0px;
            }
            .button1 {
                position:absolute;
                right: 1125px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button2 {
                position:absolute;
                right: 950px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button3 {
                position:absolute;
                right: 765px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button4 {
                position:absolute;
                right:550px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button5 {
                position:absolute;
                right: 400px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button6 {
                position:absolute;
                right: 150px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button7 {
                position:absolute;  
                right: 0px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 125px;
            } 
            .button8 {
                position:absolute;
                right:139px;
                cursor: pointer;
                margin-top: 35px;
            } 
            .button9 {
                position:absolute;
                right:8px;
                cursor: pointer;
                margin-top: 35px;
            }
            .button10 {
                position:absolute;  
                right: 10px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 20px;
            } 
            .Logo1 {
                height: 70px;
                width: 110px;
                margin:2px;
                margin-left:50px ;
                margin-top: 14px;
                border-radius: 20px;
                border:1px solid black;
                position: absolute;
            }
            header{
                background-color: aqua;
                height:100px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                margin-top:50px; 
            }
            .about1
            {
                text-align: center;
            }
           .aboutusbutton{
            padding:0px;
            border:none;
            background-color: white;
            margin:85px;
            margin-bottom: 45sspx;;
            cursor: pointer;
            border-radius: 10px;
           }
           .image{
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
           }
          .hr1{
            margin-left:150px;
            margin-right:150px;
          }
          .roles{
            margin-top: 50px;
            text-align: center;
          }
          #about2{
            font-weight:bolder;
          }
          .role{
             margin-left: 50px;;
          }
          .contant{
            margin-left: 100px;
          }
            .animate-charcter{
                text-transform: uppercase;
                background-image: linear-gradient(
                -225deg,
                #231557 0%,
                #44107a 29%,
                #ff1361 67%,
                #fff800 100%
                );
                background-size: auto auto;
                background-clip: border-box;
                background-size: 200% auto;
                color: #fff;
                background-clip: text;
                text-fill-color: transparent;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: textclip 2s linear infinite;
                display: inline-block;
                font-size: 28px;
                margin-top: 22px;
                margin-bottom: 10px;
                margin-left: 505px;
                position:absolute;
            }

            @keyframes textclip {
                to {
                background-position: 200% center;
                }
            }

            body {
                display: absolute;
                align-items: center;
                justify-content: center;
            }
            h1 {
                color: #160404;
                font-family: tahoma;
                font-size: 28px;
                font-weight 900px;
                text-transform: uppercase;
                overflow: hidden;
                position: absolute;
                width: 575px;
                margin-left: 575px;
                margin-top: 20px;
            }

            h1 span {
                font-size: 28px;
                margin-left: 115px;
                margin-top: 20px;
            }

            .message {
                background-color: rgb(244, 228, 84);
                color: #333;
                display: block;
                font-weight: 900px;
                overflow: hidden;
                font-size:28px;
                position: absolute;
                left: 350px;
                animation: openclose 5s ease-in-out infinite;
            }

            .word1, .word2, .word3 {
                font-family: tahoma;
            }

            @keyframes openclose {
                0% {
                    top: 0rem;
                    width: 0;
                }
                5% {
                    width: 40px;
                }
                15% {
                    width: 100px;
                }
                30% {
                    top: 0rem;
                    width: 160px;
                }
                33% {       
                    top: 0rem;
                    width: 0;
                }
                35% {
                    top: 0rem;
                    width: 0;
                }
                38% {
                top: -2.1rem;
    
                }
                48% {
                    top: -2.1rem;
                    width: 100px;
                }
                62% {
                    top: -2.1rem;
                    width: 200px;
                }
                66% {
                    top: -2.1rem;
                    width: 0;
                    text-indent: 0;
                }
                68% {
                    top: -2.1rem;   
                    width: 0;
                    text-indent: 0;
                }
                71% {
                    top: -4.2rem;
                    width: 0;
                }
                80% {
                    top: -4.2rem;
                    width: 100px;
                }
                95% {
                    top: -4.2rem;
                    width: 200px;
                }
                98% {
                    top: -4.2rem;
                    width: 0;
                }
                100% {
                    top: 0;
                    width: 0;
                }
            }   
                .homelogo {
                    height: 21px;
                    width: 21px;
                    border-radius: 20px;
                }
                .abtlogo{
                    height: 21px;
                    width: 21px;
                }
                form{
                    border: 1px solid rgb(119, 118, 118);
                    width:840px;
                    height: 645px;
                    margin-left: 350px;
                    margin-top: 50px;
                    background-color: rgb(241, 234, 234);
                    border-radius: 20px;
                    box-shadow: 2px 2px 5px 5px rgb(175, 175, 175);
                }
                a1{
                      display:flex;
                      margin: 15px;
                      margin-top: 0px;
                }
                b1{
                    margin: 0px;
                    margin-left: 7px;
                }
                b2{
                    margin: 0px;
                    margin-left: 30px;
                }
                .input{
                    width:375px;
                    height: 30px;
                }
                .input1{
                    width:385px;
                    height: 33px;
                }
                .text{
                    margin-bottom: 0px;
                }
                .sumb{
                    margin-left: 21px;
                    border: none;
                    background-color: rgb(65, 205, 220) ;
                    padding: 7px;
                    border-radius:5px;
                    color: white;
                    cursor: pointer;
                }
                .sign{
                    font-size: 200%;
                    font-weight: 500;
                    text-align: center;
                    background-color: orange;
                    height:55px;
                    margin-top: 0px;
                    border-top-left-radius: 20px;
                    border-top-right-radius: 20px;
                }
                main{
                    margin-top: 0px;
                }
                b3{
                    margin-left: 0px;
                }
                fieldset{
                    width: -500px;
                }
        </style>
        <meta charset="UTF-8">
        <title>
            Main Page
            </title>
            <link rel="icon" href="Logo.jpg">
        </head>
    <body>
            <div>
                <div>
                    <div">
                        <h3 class="animate-charcter"> Farm Tech:</h3>
                <h1>
                    <span>Lend/Borrow</span>
                    <div class="message">
                      <div class="word1">Tractors</div>
                      <div class="word2">Implements</div>
                      <div class="word3">Harvestors</div>
                    </div>
                  </h1>
                    </div>
                </div>
            </div>
            <a href="Login.html">
                <button class="button7" type="button">
                <b> 
                <font size="4" style="font-family:verdana">
                    Login
                </font>
                </b>
                </button>
                </a>&nbsp;
                <a href="Register.html">
                <button class="button10" type="button">
                    <b> 
                    <font size="4" style="font-family:verdana">
                        Sign in
                    </font>
                    </b>
                    </button>
            </a>&nbsp;  
        <br>
        <header>
        <img src="Logo.jpg" alt="Logo.jpg" class="Logo1"/>
        <a href=Home.html>
            <button class="button1" type="button">
            <img src="homelogo.jpg" class="homelogo">

            <b>
            <font size="5.75" style="font-family:verdana">
                Home
            </font><br>
            </b>
            </button>
        </a>&nbsp;

        <a href=AboutUS.html>
            <button class="button2" type="button">
            <img src="Abt.png" alt="Logo.jpg" class="abtlogo"/>

            <b>
            <font size="5.75" style="font-family:verdana">
                About Us
            </font>
            </b>
            </button>
        </a>&nbsp;

        <a href="Harvestor.html">
            <button class="button3" type="button">
            <img src="Harvestor.png" alt="Logo.jpg" class="abtlogo"/>

            <b>
            <font size="5.75" style="font-family:verdana">
                Harvestor</font>
            </b>
            </button>
        </a>&nbsp;
        
        <a href="Implements.html">
            <button class="button4" type="button">
            <img src="Implements.png" alt="Logo.jpg" class="abtlogo"/>
            <b>
            <font size="5.75" style="font-family:verdana">
                Implements
            </font>
            </b>
            </button>
        </a>&nbsp;

        <a href="Tractor.html">
            <button class="button5" type="button">
            <img src="Tractor.png" alt="Logo.jpg" class="abtlogo"/>
            <b>
            <font size="5.75" style="font-family:verdana">
                Tractor
            </font>
            </b>
            </button>
        </a>&nbsp;
        <a href="PlantNutrition.html">
            <button class="button6" type="button">
            <img src="PlantNutrition.png" alt="Logo.jpg" class="abtlogo"/>

            <b>
            <font size="5.75" style="font-family:verdana">
                Plant Nutrition
            </font>
            </b>
            </button>
        </a>&nbsp;
        <br>
        <br>
        <br>
        <br><br><br>
            </form>
           <form action ="signin.php" method ="post">
            <p class="sign">Sign In</p>
        <main>
            <a1>
            <b1>
            <p class="text">First Name:*</p>
            <input type="text"  name ="FirstName" id ="Firstname" placeholder="Enter Name" class="input" required>
            </b1>
            <b2>
                <p class="text">Last Name:*</p>
                <input type="text" name ="LastName" id="Lastname" placeholder="Enter Name" class="input" required>
            </b2> 
            </a1>
             <a1>
                <b1>
                    <p class="text">Gender:*</p>
                    <input type="text" name ="Gender" id="Gender"  placeholder="Enter Gender" class="input" required>
                   
                    </b1>
                    <b2>
                        <b3>
                        <p class="text">Age:*</p>
                        <input type="number" name="Age" id="Age" placeholder="Enter Age" class="input" id="inputid" required>
                        </b3>
                    </b2>  
             </a1>
            <a1>
            <b1>
                    <p class="text">Mobile Number.:*</p>
                    <input type="number" name ="MobileNumber"   id="MobileNumber" placeholder="Enter Number" class="input" required>
            </b1>
            <b2>
                <p class="text">Email Id:*</p>
                <input type="Email"  name ="EmailId"  id= "EmailId" placeholder="Enter Email" class="input" required>
            </b2>
            </a1>
            <a1>
            <b1>
                <p class="text">State:*</p>
                <input type="text"  name ="State" id="State"  placeholder="Enter State" class="input" required>
            </b1>
            <b2>
            <p class="text">District:*</p>
            <input type="text"  name ="District" id="District"placeholder="Enter City" class="input" required>
            </b2>
            </a1>
            <a1>
            <b1>
            <p class="text">Tehsil:*</p>
            <input type="text"  name ="Tehsil" id= "Tehsil" placeholder="Enter Tehsil" class="input" required>
            </b1>
            <b2>
                <p class="text">Pincode:*</p>
                <input type="number" name ="Pincode" id="Pincode" placeholder="Enter PinCode" class="input" required> 
            </b2>
            </a1>
            <a1>
            <b1>
                <p class="text">Password:*</p>
                <input type="password" name ="Password" id ="Password" placeholder="Password" class="input" required>
            </b1>
            <b2>
                <p class="text">Confirm Password:*</p>
                <input type="password" name ="ConfirmPassword" id="ConfirmPassword" placeholder="Confirm Password" class="input" required>
            </b2>
            </a1>
            <input type="Submit" text="Sign In" class="sumb">
        </main>
            </form>
           </form>
        </body>
    </html>