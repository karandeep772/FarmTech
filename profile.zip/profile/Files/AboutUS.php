
<?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    
    $conn = mysqli_connect($servername, $username, $password );
    if (!$conn){
        die("Sorry we failed to connect: " . mysqli_connect_error());
    }
        //echo "Connection was successful";
session_start();
if(isset($_GET['UEmail']))
{
$EmailId = $_GET['UEmail'];

}
//echo "$EmailId";

?>


<!Doctype html>
<HTML lang="en">
    <head>
        <style>
            body{
                margin:0px;
                background-color: rgb(232, 232, 232);
            }
            .button1 {
                position:absolute;
                right: 1125px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button2 {
                position:absolute;
                right: 950px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button3 {
                position:absolute;
                right: 765px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button4 {
                position:absolute;
                right:550px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button5 {
                position:absolute;
                right: 400px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button6 {
                position:absolute;
                right: 150px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button7 {
                position:absolute;  
                right: 0px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 125px;
            }  
            .button8 {
                position:absolute;
                right:139px;
                cursor: pointer;
                margin-top: 35px;
            } 
            .button9 {
                position:absolute;
                right:8px;
                cursor: pointer;
                margin-top: 35px;
            }
            .button10 {
                position:absolute;  
                right: 10px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 20px;
            } 
            .Logo1 {
                height: 70px;
                width: 110px;
                margin:2px;
                margin-left:50px ;
                margin-top: 14px;
                border-radius: 20px;
                border:1px solid black;
                position: absolute;
            }
            header{
                background-color: aqua;
                height:100px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                margin-top:50px; 
            }
            .about1
            {
                text-align: center;
            }
           .aboutusbutton{
            padding:7px;
            border:none;
            background-color: white;
            margin:85px;
            margin-bottom: 45sspx;;
            cursor: pointer;
            border-radius: 10px;
           }
           .image{
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
           }
          .hr1{
            margin-left:150px;
            margin-right:150px;
          }
          .roles{
            margin-top: 50px;
            margin-left: 625px;
            text-decoration: underline;
            color: red;
          }
          #about2{
            font-weight:bolder;
          }
          .role{
             margin-left: 50px;;
          }
          .contant{
            margin-left: 100px;
          }
            .animate-charcter{
                text-transform: uppercase;
                background-image: linear-gradient(
                -225deg,
                #231557 0%,
                #44107a 29%,
                #ff1361 67%,
                #fff800 100%
                );
                background-size: auto auto;
                background-clip: border-box;
                background-size: 200% auto;
                color: #fff;
                background-clip: text;
                text-fill-color: transparent;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: textclip 2s linear infinite;
                display: inline-block;
                font-size: 28px;
                margin-top: 22px;
                margin-bottom: 10px;
                margin-left: 505px;
                position:absolute;
            }

            @keyframes textclip {
                to {
                background-position: 200% center;
                }
            }

            body {
                display: absolute;
                align-items: center;
                justify-content: center;
            }
            h1 {
                color: #160404;
                font-family: tahoma;
                font-size: 28px;
                font-weight :900px;
                text-transform: uppercase;
                overflow: hidden;
                position: absolute;
                width: 575px;
                margin-left: 575px;
                margin-top: 20px;
            }

            h1 span {
                font-size: 28px;
                margin-left: 115px;
                margin-top: 20px;
            }

            .message {
                background-color: rgb(244, 228, 84);
                color: #333;
                display: block;
                font-weight: 900px;
                overflow: hidden;
                font-size:28px;
                position: absolute;
                left: 350px;
                animation: openclose 5s ease-in-out infinite;
            }

            .word1, .word2, .word3 {
                font-family: tahoma;
            }

            @keyframes openclose {
                0% {
                    top: 0rem;
                    width: 0;
                }
                5% {
                    width: 40px;
                }
                15% {
                    width: 100px;
                }
                30% {
                    top: 0rem;
                    width: 160px;
                }
                33% {       
                    top: 0rem;
                    width: 0;
                }
                35% {
                    top: 0rem;
                    width: 0;
                }
                38% {
                top: -2.1rem;
    
                }
                48% {
                    top: -2.1rem;
                    width: 100px;
                }
                62% {
                    top: -2.1rem;
                    width: 200px;
                }
                66% {
                    top: -2.1rem;
                    width: 0;
                    text-indent: 0;
                }
                68% {
                    top: -2.1rem;   
                    width: 0;
                    text-indent: 0;
                }
                71% {
                    top: -4.2rem;
                    width: 0;
                }
                80% {
                    top: -4.2rem;
                    width: 100px;
                }
                95% {
                    top: -4.2rem;
                    width: 200px;
                }
                98% {
                    top: -4.2rem;
                    width: 0;
                }
                100% {
                    top: 0;
                    width: 0;
                }
                }   
                .homelogo {
                    height: 21px;
                    width: 21px;
                    border-radius: 20px;
                }
                .abtlogo{
                    height: 21px;
                    width: 21px;
                }
                .waviy {
                    position: relative;
                    font-size: 40px;
                    text-align: center;
                    margin-top: 15px;

                }
                .waviy span {
                    font-family: 'Alfa Slab One', cursive;
                    position: relative;
                    display: inline-block;
                    color: #de2929;
                    text-transform: uppercase;
                    animation: waviy 1.25s infinite;
                    animation-delay: calc(.1s * var(--i));
                }
                @keyframes waviy {
                    0%,40%,100% {
                    transform: translateY(0)
                }
                    20% {
                    transform: translateY(-20px)
                }
                }
                .para{
                    font-size: 25px;
                    margin-left: 50px;
                    margin-top: 50px;

                }
                .karan{
                    border-radius: 50%;
                    margin-left: 50px;
                    margin-top: 30px;
                    margin-bottom: 30px;
                    padding:5px
                }
                .para1{
                   margin-right: 50px;
                   margin-left: 100px;
                   text-align: justify;
                   font-size: 15px;
                }
                .aaa{
                    display: flex;
                }
                .paraa{
                    
                    font-size:25px ;
                }
                par{
                    border: 1px solid black;
                }
                .but1{
                    width: 900px;
                    margin-left: 75px;
                    background-color: white;
                    border: none;
                    margin-top: 50px;
                    border-bottom-right-radius: 100px;
                    background-color: rgb(255, 245, 232);
                }
                .jaskaran{
                    border-radius: 50%;
                    margin-right: 25px;
                    margin-top: 110px;
                }
                .paraa1{
                    text-align: justify;
                    margin-left: 50px;
                     margin-right: 125px;
                     margin-top:55px ;
                     font-size: 15px;
                }
                .but2{
                    margin-top: 50px;
                    margin-left: 450px;
                    margin-right: 50px;
                    background-color: rgb(215, 244, 244);
                    border: none;
                    border-bottom-left-radius: 100px;
                }
                #idp{
                    margin-bottom:45px;
                }
                .but3{
                    width: 900px;
                    margin-left: 75px;
                    background-color: white;
                    border: none;
                    margin-top: 50px;
                    border-bottom-right-radius: 100px;
                    background-color: rgb(237, 250, 182);
                }
                .but4{
                    margin-top: 50px;
                    margin-left: 450px;
                    margin-right: 50px;
                    background-color: rgba(153, 180, 255, 0.848);
                    border: none;
                    border-bottom-left-radius: 100px;
                }
                .daya{
                    border-radius: 50%;
                    margin-right: 25px;
                    margin-top: 150px;
                }.HarButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }

            .Harvbar {
                
                right: 760px;
                position: absolute;
                display: inline-block;
            }

            .HarvContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .HarvContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .HarvContent a:hover {
                background-color: #ddd;
            }

            .Harvbar:hover .HarvContent {
                display: block;
            }

            .Harvbar:hover .HarButton {
                background-color: #3e8e41;
            }
            
            .ImpleButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Implebar {
                
                right: 550px;
                position: absolute;
                display: inline-block;
            }

            .ImpleContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .ImpleContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .ImpleContent a:hover {
                background-color: #ddd;
            }

            .Implebar:hover .ImpleContent {
                display: block;
            }

            .Implebar:hover .ImpleButton {
                background-color: #3e8e41;
            }

            .TracButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Tracbar {
                
                right: 400px;
                position: absolute;
                display: inline-block;
            }

            .TracContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .TracContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .TracContent a:hover {
                background-color: #ddd;
            }

            .Tracbar:hover .TracContent {
                display: block;
            }

            .Tracbar:hover .TracButton {
                background-color: #3e8e41;
            }

            .PlantButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Plantbar {
                
                right: 150px;
                position: absolute;
                display: inline-block;
            }

            .PlantContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .PlantContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .PlantContent a:hover {
                background-color: #ddd;
            }

            .Plantbar:hover .PlantContent {
                display: block;
            }

            .Plantbar:hover .PlantButton {
                background-color: #3e8e41;
            }
            
.EmaillButton {
    color: black;
    padding: 4px;
    font-size: 10px;
    margin-top: 33px;
    border-bottom:1px solid rgb(0, 0, 0);
    border-top: 1px solid rgb(0, 0, 0);
    border-left: 1px solid rgb(0, 0, 0);
    border-right: 1px solid rgb(0, 0, 0);
    border-radius: 20px;
}

.Emaillbar {
    
    right: 5px;
    position: absolute;
    display: inline-block;
}

.EmaillContent {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
    text-align: center  ;
}

.EmaillContent a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.EmaillContent a:hover {
    background-color: #ddd;
}

.Emaillbar:hover .EmaillContent {
    display: block;
}

.Emaillbar:hover .EmaillButton {
    background-color: #3e8e41;

}
        </style>
        <meta charset="UTF-8">
        <title>
            Main Page
            </title>
            <link rel="icon" href="Logo.jpg">
        </head>
    <body>
            <div>
                <div>
                    <div">
                        <h3 class="animate-charcter"> Farm Tech:</h3>
                <h1>
                    <span>Lend/Borrow</span>
                    <div class="message">
                      <div class="word1">Tractors</div>
                      <div class="word2">Implements</div>
                      <div class="word3">Harvestors</div>
                    </div>
                  </h1>
                    </div>
                </div>
            </div>

           
<div class="Emaillbar">

    <button class="EmaillButton" type="button">
    <a href="Tractor.html">
    </a>&nbsp;
    <b>
    <font size="3" style="font-family:verdana">
        <?php
        echo "$EmailId";
        ?>
    </font>
    </b>
    </button>
    <div class="EmaillContent">
        <a href="Tractor.html">Profile</a>
        <a href="../Home.html">LogOut</a>    
    </div>
        </div>
        <br>
    <br>
    <header>
    <img src="../Images/Logo.jpg" alt="Logo.jpg" class="Logo1"/>
    <a href="../homeloggedin.php?UEmail=<?php echo "$EmailId";?>">
    <button class="button1" type="button">
    <img src="../Images/homelogo.jpg" class="homelogo">
    <b>
    <font size="5.75" style="font-family:verdana">
    Home
    </font><br>
    </b>
    </button>
    </a>&nbsp;
    
    <a href="AboutUS.php?UEmail=<?php echo "$EmailId";?>">
    <button class="button2" type="button">
    <img src="../Images/Abt.png" alt="Logo.jpg" class="abtlogo"/>
    
    <b>
    <font size="5.75" style="font-family:verdana">
    About Us
    </font>
    </b>
    </button>
    </a>&nbsp;
    <div class="Harvbar">
    <a href="harvester.php?UEmail=<?php echo "$EmailId";?>">
    <button class="HarButton" type="button">
    <img src="../Images/Harvestor.png" alt="Logo.jpg" class="abtlogo"/>
    
    <b>
    <font size="5.75" style="font-family:verdana">
    Harvestor</font>
    </b>
    </button>
    </a>&nbsp;
    
    <div class="HarvContent">
    <a href="harvester.php?UEmail=<?php echo "$EmailId";?>">Borrow</a>
    <a href="harv_lend_1.php?UEmail=<?php echo "$EmailId";?>">Lend</a>
    </div>
    </div>
    <div class="Implebar">
    
    <a href="implements.php?UEmail=<?php echo "$EmailId";?>">
    <button class="ImpleButton" type="button">
    <img src="../Images/Implements.png" alt="Logo.jpg" class="abtlogo"/>
    <b>
    <font size="5.75" style="font-family:verdana">
    Implements
    </font>
    </b>
    </button>
    </a>&nbsp;
    
    <div class="ImpleContent">
    <a href="Implements.php?UEmail=<?php echo "$EmailId";?>">Borrow</a>
    <a href="imple_lend_1.php?UEmail=<?php echo "$EmailId";?>">Lend</a>
    </div>
    </div>
    <div class="Tracbar">
    <a href="tractor.php?UEmail=<?php echo "$EmailId";?>">
    
    <button class="TracButton" type="button">
    <img src="../Images/Tractor.png" alt="Logo.jpg" class="abtlogo"/>
    <b>
    <font size="5.75" style="font-family:verdana">
    Tractor
    </font>
    </b>
    </button>
    </a>&nbsp;
    
    <div class="TracContent">
    <a href="tractor.php?UEmail=<?php echo "$EmailId";?>">Borrow</a>
    <a href="trac_lend_1.php?UEmail=<?php echo "$EmailId";?>">Lend</a>    
    </div>
    </div>
    <div class="Plantbar">
    
    <a href="PlantNutrition.html?UEmail=<?php echo "$EmailId";?>">
    
    <button class="PlantButton" type="button">
    <img src="../Images/PlantNutrition.png" alt="Logo.jpg" class="abtlogo"/>
    
    <b>
    <font size="5.75" style="font-family:verdana">
    Plant Nutrition
    </font>
    </b>
    </button>
    </a>&nbsp;
    <div class="PlantContent">
    <a href="Soil Health.php?UEmail=<?php echo "$EmailId";?>">Soil Health</a>
    <a href="Soilissue.php?UEmail=<?php echo "$EmailId";?>">Soil Issue</a>
    <a href="Nutritions.php?UEmail=<?php echo "$EmailId";?>">Nutrients</a>
    <a href="Elements.php?UEmail=<?php echo "$EmailId";?>">Element</a>
    <a href="pesticides.php?UEmail=<?php echo "$EmailId";?>">Pesticides</a>
    <a href="Crops.php?UEmail=<?php echo "$EmailId";?>">Crops</a>    
    <a href="Plant Growth.php?UEmail=<?php echo "$EmailId";?>">Plant Growth</a>
    <a href="Preventation.php?UEmail=<?php echo "$EmailId";?>">Preventation</a>
    </div>
    </div> 
    </header>
        <br>
        <div class="waviy">
            <b>
            <span style="--i:1">A</span>
            <span style="--i:2">B</span>
            <span style="--i:3">O</span>
            <span style="--i:4">U</span>
            <span style="--i:5">T</span>
            <span style="--i:6"> </span>
            <span style="--i:7">U</span>
            <span style="--i:8">S</span>
            </b>
            </div>
        <main>
            <!-- <a href="karan.html"> -->
    <button class="aboutusbutton">
        <img src="../Images/Karan1.jpg" width="200px" height="200px" class="image">
       <p >Karandeep Singh Ghai</p>
       <p >Computer Science, 1st Year</p>
       <p >Delhi,India</p>
    </button>
    </a>
    <!-- <a href="Jaskaran.html"> -->
    <button class="aboutusbutton">
       <img src="../Images/Jaskaran.jpg" witdh="300px" height="200px" class="image">
       <p>Jaskaran Oberoi</p>
       <p>Computer Science, 1st Year</p>
       <p>Ludhiana,Punjab</p>
    </button>
    </a>
    <!-- <a href="Deepanshu.html"> -->
    <button class="aboutusbutton">
       <img src="../Images/Deepanshu.png" width="200px" height="200px" class="image">
       <p>Deepanshu Bansal</p>
       <p>Computer Science, 1st Year</p>
       <p>Nagar(Bharatpur),Rajasthan</p>
    </button>
    </a>
    <!-- <a href="Daya.html"> -->
    <button class="aboutusbutton">
       <img src="../Images/daya.jpg" Width="200px" height="200px" class="image">
       <p>Daya Singh</p>
       <p>Compter Science, 1st Year</p> 
       <p>Gurgaon,Haryana</p>
    </button>
    </a>
    <hr class="hr1">
    <h1 class="roles">Roles in Project</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <button class="but1">
   <p class="para">Karandeep Singh Ghai</p>
   <a class="aaa">
   <img src="../Images/Karan1.jpg" width="250" height="250" class="karan">
   <aa>
   <p class="para1">I am born and brought up in Delhi.I completed my senior secondary education from Darshan Academy ,Delhi.I am currently studying at the institute UPES , Dehradun and the course  I am pursuing is computer science.</p>
   <p class="para1">I am extremely happy and proud to be part of this project with my team members. In this Project, i worked on the development of the website’s front-end using HTML, CSS ensuring that the the platform is user friendly.</p>
   </aa>
   </a>
</button>
   <br>
   <br>
   <button class="but2">
   <a class="aaa">
    <aa>
   <p class="paraa">Jaskaran Oberoi</p>
   <p class="paraa1">I am born and brought up in Delhi.I completed my senior secondary education from Darshan Academy ,Delhi.I am currently studying at the institute UPES , Dehradun and the course  I am pursuing is computer science.</p>
   <p class="paraa1">My hobbies are to play  chess, to travel and to explore new things.</p>
    <p class="paraa1">I am extremely happy and proud  to be part of this project with my team members. In this project, I worked on the development of the website’s backend using PHP ensuring that the platform is user friendly, secure and scalable. I also  collaborated with the team to design and implement key features such as messaging system  and user authentication. </p>
    <p class="paraa1" id="idp">I am always looking for new challenges and opportunities to learn and grow . I am passionate  about using  my skills to make a positive impact on society , and I believe that  this project is a great example of how technology can be used to empower communities and drive social change.Thankyou for taking the time to learn more about me and my work </p>
    </aa>
    <img src="../Images/Jaskaran.jpg"  width="250" height="250" class="jaskaran">
    </a>
    </button>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <button class="but3">
   <p class="para">Deepanshu Bansal</p>
   <a class="aaa">
   <img src="../Images/Deepanshu.png" width="250" height="250" class="karan">
   <aa>
   <p class="para1">I was born and raised in Bharatpur, Rajasthan. I complated my schooling from Vidyasthali public school, Alwar. I am currently studying at the University of Petroleum and Energy Studies, Dehradun and the course I am pursuing is Computer Science.</p>
   <p class="para1">I am extremely happy and proud to be part of this project with my team members. In this Project, i worked on the development of the website’s front-end using HTML, CSS ensuring that the the platform is user friendly.</p>
   </aa>
   </a>
</button>
   <br>
   <br>
   <button class="but4">
   <a class="aaa">
    <aa>
   <p class="paraa">Daya Singh</p>
   <p class="paraa1">I was born in Jamshedpur, did my schooling from Jamshedpur, Mumbai and Delhi. I am currently pursuing Computer Science at University of Petroleum and Energy Studies, Dehradun. </p>
   <p class="paraa1">My hobbies are playing football, badminton, volleyball, basketball, table tennis, cricket, etc. </p>
    <p class="paraa1">I am delighted to be a part of this team and excited about this project. In this project, I worked on the content part and data collection and analysis, such as information about various crops, weather seasons and suitable climatic conditions. I also worked on the home page, harvesting and about team members. </p>
    <p class="paraa1" id="idp">I am always ready to contribute to society and its betterment and I believe this project will surely make an impact in rural society where development is needed most. </p>
    </aa>
    <img src="../Images/daya.jpg"  width="250" height="250" class="daya">
    </a>
    </button>
        </body>
    </html>