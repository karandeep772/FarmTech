<?php  error_reporting(0);
$servername = "localhost";
    $username = "root";
    $password = "";
    
    $conn = mysqli_connect($servername, $username, $password );
    if (!$conn){
        die("Sorry we failed to connect: " . mysqli_connect_error());
    }
       //echo "Connection was successful";
       session_start();


       //$_SESSION['sno'] = $row['sno'];
       if (isset($_GET['sno'])) {
//                            $_SESSION['sno'] = $_GET['sno'];
           $sno = $_GET['sno'];
          // $UEmail = $_GET['UEmail'];
           }



// //$_SESSION['sno'] = $row['sno'];
// if (isset($_GET['UEmail'])) {

//     $UEmail = $_GET['UEmail'];
// }

// echo "$sno";


// if(isset($_POST['Submit'])){
//     $sql="SELECT * FROM `farmtech`.`harv_lend` where sno='$sno'";

// $result = mysqli_query($conn, $sql);
// $ab=mysqli_fetch_assoc($result);
// // if (isset($_GET['UEmail'])) {
// //     //                            $_SESSION['sno'] = $_GET['sno'];
// //                                 $sno = $_GET['sno'];
// //                                 $UEmail = $_GET['UEmail'];
// //                                 }
                
//                             $MobileNumber = $ab['MobileNumber'];
//                             $EmailId = $ab['Name'];
//                             $State = $ab['State'];
//                             $District = $ab['District'];
//                             $Tehsil = $ab['Tehsil'];
//                             $Pincode = $ab['Pincode'];
//                             $CropType= $ab['CropType'];
//                             $CuttingWidth = $ab['CuttingWidth'];
//                             $Images = $ab['Images'];
//                             $Days = $ab['Days'];
//                             $Price = $ab['Price'];
//                             //$UEmail = $_GET['UEmail'];
                
                
                
                
//                 echo"$Days";
//                             $sql ="INSERT INTO `farmtech`.`transactions` (`MobileNumber`, `EmailId`, `State`, `District`, `Tehsil`, `Pincode`, `CropType`,
//                   `CuttingWidth`, `Images`,`Days`,`Price`,`SEmail`,`dt`) VALUES ('$MobileNumber', '$EmailId', '$State', '$District', '$Tehsil','$Pincode', '$CropType',
//                   '$CuttingWidth','$Images','$Days','$Price', '$UEmail',current_timestamp())";
//                    $result = mysqli_query($conn, $sql);
                
//                         }
                        
                
                
                
                       


        $sql="SELECT * FROM `farmtech`.`harv_lend` where sno='$sno'";
        $result = mysqli_query($conn, $sql);
?>

<!Doctype html>
<HTML lang="en">
    <head>
        <style>
            body{
                margin:0px;
            }
            .button1 {
                position:absolute;
                right: 1125px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button2 {
                position:absolute;
                right: 950px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button3 {
                position:absolute;
                right: 765px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button4 {
                position:absolute;
                right:550px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button5 {
                position:absolute;
                right: 400px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button6 {
                position:absolute;
                right: 150px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button7 {
                position:absolute;  
                right: 0px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 125px;
            } 
            .button8 {
                position:absolute;
                right:139px;
                cursor: pointer;
                margin-top: 35px;
            } 
            .button9 {
                position:absolute;
                right:8px;
                cursor: pointer;
                margin-top: 35px;
            }
            .button10 {
                position:absolute;  
                right: 10px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 20px;}
            .Logo1 {
                height: 70px;
                width: 110px;
                margin:2px;
                margin-left:50px ;
                margin-top: 14px;
                border-radius: 20px;
                border:1px solid black;
                position: absolute;
            }
            header{
                background-color: aqua;
                height:100px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                margin-top:50px; 
            }
            .animate-charcter{
                text-transform: uppercase;
                background-image: linear-gradient(
                -225deg,
                #231557 0%,
                #44107a 29%,
                #ff1361 67%,
                #fff800 100%
                );
                background-size: auto auto;
                background-clip: border-box;
                background-size: 200% auto;
                color: #fff;
                background-clip: text;
                text-fill-color: transparent;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: textclip 2s linear infinite;
                display: inline-block;
                font-size: 28px;
                margin-top: 22px;
                margin-bottom: 10px;
                margin-left: 505px;
                position:absolute;
            }

            @keyframes textclip {
                to {
                background-position: 200% center;
                }
            }

            body {
                display: absolute;
                align-items: center;
                justify-content: center;
            }
            h1 {
                color: #160404;
                font-family: tahoma;
                font-size: 28px;
                font-weight 900px;
                text-transform: uppercase;
                overflow: hidden;
                position: absolute;
                width: 575px;
                margin-left: 575px;
                margin-top: 20px;
            }

            h1 span {
                font-size: 28px;
                margin-left: 115px;
                margin-top: 20px;
            }

            .message {
                background-color: rgb(244, 228, 84);
                color: #333;
                display: block;
                font-weight: 900px;
                overflow: hidden;
                font-size:28px;
                position: absolute;
                left: 350px;
                animation: openclose 5s ease-in-out infinite;
            }

            .word1, .word2, .word3 {
                font-family: tahoma;
            }

            @keyframes openclose {
                0% {
                    top: 0rem;
                    width: 0;
                }
                5% {
                    width: 40px;
                }
                15% {
                    width: 100px;
                }
                30% {
                    top: 0rem;
                    width: 160px;
                }
                33% {       
                    top: 0rem;
                    width: 0;
                }
                35% {
                    top: 0rem;
                    width: 0;
                }
                38% {
                top: -2.1rem;
    
                }
                48% {
                    top: -2.1rem;
                    width: 100px;
                }
                62% {
                    top: -2.1rem;
                    width: 200px;
                }
                66% {
                    top: -2.1rem;
                    width: 0;
                    text-indent: 0;
                }
                68% {
                    top: -2.1rem;   
                    width: 0;
                    text-indent: 0;
                }
                71% {
                    top: -4.2rem;
                    width: 0;
                }
                80% {
                    top: -4.2rem;
                    width: 100px;
                }
                95% {
                    top: -4.2rem;
                    width: 200px;
                }
                98% {
                    top: -4.2rem;
                    width: 0;
                }
                100% {
                    top: 0;
                    width: 0;
                }
                }   
                .homelogo {
                    height: 21px;
                    width: 21px;
                }
                .abtlogo{
                    height: 21px;
                    width: 21px;
                }
                .greyphoto{
                    position: absolute;

                }
                .Poto{
                    position: absolute;
                    left: 175px;
                    border-bottom:1px solid rgb(0, 0, 0);
                    border-top: 1px solid rgb(0, 0, 0);
                    border-left: 1px solid rgb(0, 0, 0);
                    border-right: 1px solid rgb(0, 0, 0);
                    border-radius: 20px;
                }
                .MName{
                    position: absolute;
                    left: 825px;
                    color: red; 
                    font-size: 30px;   
                }
                .Pprice{
                    position: absolute;
                    left: 650px;
                    font-size: 40px;    
                }
                .Llocation{
                    position: absolute;
                    left:650px;
                    font-size: 25px;
                }
                .Ddetails{
                    position: absolute;
                    left:650px;
                    font-size: 25px;
                }
                .Ccontinue{
                    position: absolute;
                    left:650px;
                    font-size: 25px;
                }
                .Rrent{
                    position: absolute;
                    left:750px;
                    font-size: 50px;
                    border-radius: 5px;
                    background-color: rgb(228, 29, 29);
                    color: white;
                    border-bottom: 7px solid rgb(228, 29, 29);
                    border-top: 7px solid rgb(228, 29, 29);
                    border-left: 7px solid rgb(228, 29, 29);
                    border-right: 7px solid rgb(228, 29, 29);
                }
                .Rrent:hover{
                background: Grey;
                color: blue;
                cursor: pointer;
                }
                .greyphotoright{
                    position: absolute;
                    right: 1px;
                }
                
            
            .HarButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }

            .Harvbar {
                
                right: 760px;
                position: absolute;
                display: inline-block;
            }

            .HarvContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .HarvContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .HarvContent a:hover {
                background-color: #ddd;
            }

            .Harvbar:hover .HarvContent {
                display: block;
            }

            .Harvbar:hover .HarButton {
                background-color: #3e8e41;
            }
            
            .ImpleButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Implebar {
                
                right: 550px;
                position: absolute;
                display: inline-block;
            }

            .ImpleContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .ImpleContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .ImpleContent a:hover {
                background-color: #ddd;
            }

            .Implebar:hover .ImpleContent {
                display: block;
            }

            .Implebar:hover .ImpleButton {
                background-color: #3e8e41;
            }

            .TracButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Tracbar {
                
                right: 400px;
                position: absolute;
                display: inline-block;
            }

            .TracContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .TracContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .TracContent a:hover {
                background-color: #ddd;
            }

            .Tracbar:hover .TracContent {
                display: block;
            }

            .Tracbar:hover .TracButton {
                background-color: #3e8e41;
            }

            .PlantButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Plantbar {
                
                right: 150px;
                position: absolute;
                display: inline-block;
            }

            .PlantContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .PlantContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .PlantContent a:hover {
                background-color: #ddd;
            }

            .Plantbar:hover .PlantContent {
                display: block;
            }

            .Plantbar:hover .PlantButton {
                background-color: #3e8e41;
            }            
            .Signn{
                text-align: center;
                font-size: 30px;
                font-family:verdana;
                color: red;

            }
        </style>
        <meta charset="UTF-8">
        <title>
            Main Page
            </title>
        </head>
    <body>
            <div>
                <div>
                    <div">
                        <h3 class="animate-charcter"> Farm Tech:</h3>
                <h1>
                    <span>Lend/Borrow</span>
                    <div class="message">
                      <div class="word1">Tractors</div>
                      <div class="word2">Implements</div>
                      <div class="word3">Harvestors</div>
                    </div>
                  </h1>
                    </div>
                </div>
            </div>
           
            <a href="Login.php">
                <button class="button7" type="button">
                <b> 
                <font size="4" style="font-family:verdana">
                    Login
                </font>
                </b>
                </button>
            </a>&nbsp;
                        <a href="signin.php">
                <button class="button10" type="button">
                <b> 
                <font size="4" style="font-family:verdana">
                    Sign in
                </font>
                </b>
                </button>
            </a>&nbsp;  
            <header>
                <img src="../Images/Logo.jpg" alt="Logo.jpg" class="Logo1"/>
                <a href=../Home.html>
                    <button class="button1" type="button">
                    <img src="../Images/homelogo.jpg" class="homelogo">
                    <b>
                    <font size="5.75" style="font-family:verdana">
                        Home
                    </font><br>
                    </b>
                    </button>
                </a>&nbsp;
        
                <a href=AboutUS_without.html>
                    <button class="button2" type="button">
                    <img src="../Images/Abt.png" alt="Logo.jpg" class="abtlogo"/>
        
                    <b>
                    <font size="5.75" style="font-family:verdana">
                        About Us
                    </font>
                    </b>
                    </button>
                </a>&nbsp;
                <div class="Harvbar">
                <a href="harvester_without.php">
                    <button class="HarButton" type="button">
                    <img src="../Images/Harvestor.png" alt="Logo.jpg" class="abtlogo"/>
        
                    <b>
                    <font size="5.75" style="font-family:verdana">
                        Harvestor</font>
                    </b>
                    </button>
                    </a>&nbsp;
        
                    <div class="HarvContent">
                    <a href="harvester_without.php">Borrow</a>
                    <a href="harv_lend_1_without.php">Lend</a>
                </div>
                    </div>
                    <div class="Implebar">
                
                <a href="implements_without.php">
                    <button class="ImpleButton" type="button">
                    <img src="../Images/Implements.png" alt="Logo.jpg" class="abtlogo"/>
                    <b>
                    <font size="5.75" style="font-family:verdana">
                        Implements
                    </font>
                    </b>
                    </button>
                </a>&nbsp;
        
                <div class="ImpleContent">
                    <a href="Implements_without.php">Borrow</a>
                    <a href="imple_lend_1_without.php">Lend</a>
                </div>
                    </div>
                    <div class="Tracbar">
                <a href="tractor_without.php">
        
                    <button class="TracButton" type="button">
                    <img src="../Images/Tractor.png" alt="Logo.jpg" class="abtlogo"/>
                    <b>
                    <font size="5.75" style="font-family:verdana">
                        Tractor
                    </font>
                    </b>
                    </button>
                </a>&nbsp;
        
                    <div class="TracContent">
                        <a href="tractor_without.php">Borrow</a>
                        <a href="trac_lend_1_without.php">Lend</a>    
                    </div>
                        </div>
                        <div class="Plantbar">
        
                <a href="PlantNutrition_without.html">
        
                    <button class="PlantButton" type="button">
                    <img src="../Images/PlantNutrition.png" alt="Logo.jpg" class="abtlogo"/>
                    
            <b>
                <font size="5.75" style="font-family:verdana">
                    Plant Nutrition
                </font>
                </b>
                </button>
            </a>&nbsp;
            <div class="PlantContent">
                <a href="Soil Health_without.html">Soil Health</a>
                <a href="Soilissue_without.html">Soil Issue</a>
                <a href="Nutritions_without.html">Nutrients</a>
                <a href="Elements_without.html">Element</a>
                <a href="pesticides_without.html">Pesticides</a>
                <a href="Crops_without.html">Crops</a>    
                <a href="Plant Growth_without.html">Plant Growth</a>
                <a href="Preventation_without.html">Preventation</a>
            </div>
            </div> </header>
        <br>
        </header>

        <main>
            <?php
        
            while($row=mysqli_fetch_assoc($result)){
            ?>
        <img src="../Images/Black.jpg" height="1px" width="1535px">
        <br>
        <img src="../Images/Grey.jpg" height="575px" width="100px" class="greyphoto">
        <img src="../Images/Grey.jpg" height="575px" width="100px" class="greyphotoright">
        <br>
        <h2 class="MName">
        <?php echo $row["Company"]; ?> 
        </h2>
        <br>
        <img src="../uploads/<?php echo $row["Images"]; ?>" height="375px" width="450px" class="Poto">
        <br>
        <h2 class="Pprice">
            Rs. <?php echo $row["Price"]; ?>
        </h2>
        <br>
        <br>
        <br>
        <br>
        <h2 class="Llocation">
            Location: <br>
            state: <?php echo $row["State"]; ?>
            District: <?php echo $row["District"]; ?>
            Tehsil: <?php echo $row["Tehsil"]; ?>
            Pincode: <?php echo $row["Pincode"]; ?>
        </h2>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <h2 class="Ddetails">
            Details: <br>
            CropType: <?php echo $row["CropType"]; ?><br>
            CuttingWidth: <?php echo $row["CuttingWidth"]; ?>
        </h2>
        <br>
        <br>
        <br>
        <br>
        <br>

        <br>
        <h2 class="Ccontinue">
            Number of Days harvesters is available: <?php echo $row["Days"]; ?>
        </h2>
        <br>
        <br>
        <br>
        <br>
        <br>
        <form action= "borrow_harv_without.php?sno=<?php echo $row['sno'];?>" method="post">
            <input type="submit" name="Submit" class="Rrent" placeholder="RENT" >
            </form>
            <br>
            <br>
            <h4 class="Signn">
        <?php if(isset($_POST['Submit'])){
            echo "Sign Up First"; 
        }?>
        </h4>
 <?php

}
//echo $row["Images"];
?>
            </main>
        </body>
        
    </html>