
<?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    
    $conn = mysqli_connect($servername, $username, $password );
    if (!$conn){
        die("Sorry we failed to connect: " . mysqli_connect_error());
    }
        //echo "Connection was successful";
session_start();
if(isset($_GET['UEmail']))
{
$EmailId = $_GET['UEmail'];

}
//echo "$EmailId";

?>


<html>
        <head>
            <title>
                PlantNutrition - Soil Health
            </title>
            <style>
                body{
                    margin: 0px;
                }
            .button1 {
                position:absolute;
                right: 1125px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button2 {
                position:absolute;
                right: 950px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button3 {
                position:absolute;
                right: 765px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button4 {
                position:absolute;
                right:550px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button5 {
                position:absolute;
                right: 400px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button6 {
                position:absolute;
                right: 150px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button7 {
                position:absolute;  
                right: 0px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 125px;
            }
            .button8 {
                position:absolute;
                right:139px;
                cursor: pointer;
                margin-top: 35px;
            } 
            .button9 {
                position:absolute;
                right:8px;
                cursor: pointer;
                margin-top: 35px;
            }
            .button10 {
                position:absolute;  
                right: 10px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 20px;
            } 
            .Logo1 {
                height: 70px;
                width: 110px;
                margin:2px;
                margin-left:50px ;
                margin-top: 14px;
                border-radius: 20px;
                border:1px solid black;
                position: absolute;
            }
            header{
                background-color: aqua;
                height:100px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                margin-top:50px; 
            }
            .animate-charcter{
                text-transform: uppercase;
                background-image: linear-gradient(
                -225deg,
                #231557 0%,
                #44107a 29%,
                #ff1361 67%,
                #fff800 100%
                );
                background-size: auto auto;
                background-clip: border-box;
                background-size: 200% auto;
                color: #fff;
                background-clip: text;
                text-fill-color: transparent;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: textclip 2s linear infinite;
                display: inline-block;
                font-size: 28px;
                margin-top: 22px;
                margin-bottom: 10px;
                margin-left: 505px;
                position:absolute;
            }

            @keyframes textclip {
                to {
                background-position: 200% center;
                }
            }

            body {
                display: absolute;
                align-items: center;
                justify-content: center;
            }
            h1 {
                color: #160404;
                font-family: tahoma;
                font-size: 28px;
                font-weight 900px;
                text-transform: uppercase;
                overflow: hidden;
                position: absolute;
                width: 575px;
                margin-left: 575px;
                margin-top: 20px;
            }

            h1 span {
                font-size: 28px;
                margin-left: 115px;
                margin-top: 20px;
            }

            .message {
                background-color: rgb(244, 228, 84);
                color: #333;
                display: block;
                font-weight: 900px;
                overflow: hidden;
                font-size:28px;
                position: absolute;
                left: 350px;
                animation: openclose 5s ease-in-out infinite;
            }

            .word1, .word2, .word3 {
                font-family: tahoma;
            }

            @keyframes openclose {
                0% {
                    top: 0rem;
                    width: 0;
                }
                5% {
                    width: 40px;
                }
                15% {
                    width: 100px;
                }
                30% {
                    top: 0rem;
                    width: 160px;
                }
                33% {       
                    top: 0rem;
                    width: 0;
                }
                35% {
                    top: 0rem;
                    width: 0;
                }
                38% {
                top: -2.1rem;
    
                }
                48% {
                    top: -2.1rem;
                    width: 100px;
                }
                62% {
                    top: -2.1rem;
                    width: 200px;
                }
                66% {
                    top: -2.1rem;
                    width: 0;
                    text-indent: 0;
                }
                68% {
                    top: -2.1rem;   
                    width: 0;
                    text-indent: 0;
                }
                71% {
                    top: -4.2rem;
                    width: 0;
                }
                80% {
                    top: -4.2rem;
                    width: 100px;
                }
                95% {
                    top: -4.2rem;
                    width: 200px;
                }
                98% {
                    top: -4.2rem;
                    width: 0;
                }
                100% {
                    top: 0;
                    width: 0;
                }
                }   
                .homelogo {
                    height: 21px;
                    width: 21px;
                    border-radius: 20px;
                }
                .abtlogo{
                    height: 21px;
                    width: 21px;
                }
                .input{
                    width:500px;
                    height:25px;
                    float:right;
                    margin-right: 70px;
            }
            .H1{
                margin-left:580px;
                font-size:px;
                margin-top: 20px;
            }
            .search{
                float:right;
                margin-top: 40px;
                margin-right: -47px;;
            }
            box{
                border:2px solid black;
            }
            .tractors{
                border:none;
                border:1px solid rgb(205, 204, 204);
                margin: 8px;
                padding: 0px;
                background-color: white;
                margin-left: 0px;
            }
            main{
                margin-left: 130px;
                margin-top: 50px;
            }
            .butimage{
                padding:0px;
                margin: 0px;
            }
            .book{
                background-color: rgb(71, 71, 245);
                height: 30px;
                margin-bottom: 0px;
                margin-top: 0px;
            }
            .book1{
                margin-bottom: 0px;;
                margin-top: -20px;
            }
            .text:hover{
                  color:red;
                  cursor:pointer;
            }
            button{
                cursor: pointer;
            }
            .book:hover
            {
                background-color: rgb(251, 41, 41);
            }

            @import url('https://fonts.googleapis.com/css2?family=Alfa+Slab+One&display=swap');
        .waviy {
                
                font-size: 20px;
                margin-top: -10x;

            }
            .waviy span {
                font-family: 'Alfa Slab One', simple;
                position: relative;
                display: inline-block;
                color: black;
                text-transform: uppercase;
                animation: waviy 1.25s infinite;
                animation-delay: calc(.1s * var(--i));
            }
            @keyframes waviy {
                0%,50%,100% {
                transform: translateY(0)
            }
                50% {
                transform: translateY(-20px)
            }
            }
            .elements{
                    background-color: rgb(56, 215, 38);
                    width: 1520px;
                    height: 100px;
                    text-align:center;
                    color: white;
                    margin: 0px;
                }
                .para2{
                    text-align: center;
                    margin-left: 100px;
                    margin-right:100px ;
                    font-size: larger;
                    margin-top: 150px;
                }
                .para1{
                    text-align: left;
                    margin-left: 100px;
                    margin-right:100px ;
                    font-size: larger;
                    margin-top: 50px;
                }
                .para3{
                    text-align: left;
                    margin-left: 100px;
                    margin-right:100px ;
                    font-size: larger;
                    margin-top: 30px;
                }
                ab{
                    display: flex;
                    margin-top: 100px;
                }
                .HarButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }

            .Harvbar {
                
                right: 760px;
                position: absolute;
                display: inline-block;
            }

            .HarvContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .HarvContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .HarvContent a:hover {
                background-color: #ddd;
            }

            .Harvbar:hover .HarvContent {
                display: block;
            }

            .Harvbar:hover .HarButton {
                background-color: #3e8e41;
            }
            
            .ImpleButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Implebar {
                
                right: 550px;
                position: absolute;
                display: inline-block;
            }

            .ImpleContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .ImpleContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .ImpleContent a:hover {
                background-color: #ddd;
            }

            .Implebar:hover .ImpleContent {
                display: block;
            }

            .Implebar:hover .ImpleButton {
                background-color: #3e8e41;
            }

            .TracButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Tracbar {
                
                right: 400px;
                position: absolute;
                display: inline-block;
            }

            .TracContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .TracContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .TracContent a:hover {
                background-color: #ddd;
            }

            .Tracbar:hover .TracContent {
                display: block;
            }

            .Tracbar:hover .TracButton {
                background-color: #3e8e41;
            }

            .PlantButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Plantbar {
                
                right: 150px;
                position: absolute;
                display: inline-block;
            }

            .PlantContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .PlantContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .PlantContent a:hover {
                background-color: #ddd;
            }

            .Plantbar:hover .PlantContent {
                display: block;
            }

            .Plantbar:hover .PlantButton {
                background-color: #3e8e41;
            }
            
.EmaillButton {
    color: black;
    padding: 4px;
    font-size: 10px;
    margin-top: 33px;
    border-bottom:1px solid rgb(0, 0, 0);
    border-top: 1px solid rgb(0, 0, 0);
    border-left: 1px solid rgb(0, 0, 0);
    border-right: 1px solid rgb(0, 0, 0);
    border-radius: 20px;
}

.Emaillbar {
    
    right: 5px;
    position: absolute;
    display: inline-block;
}

.EmaillContent {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
    text-align: center  ;
}

.EmaillContent a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.EmaillContent a:hover {
    background-color: #ddd;
}

.Emaillbar:hover .EmaillContent {
    display: block;
}

.Emaillbar:hover .EmaillButton {
    background-color: #3e8e41;

}
            </style>
        </head>
        <body>
            <div>
                <div>
                    <div">
                        <h3 class="animate-charcter"> Farm Tech:</h3>
                <h1>
                    <span>Lend/Borrow</span>
                    <div class="message">
                      <div class="word1">Tractors</div>
                      <div class="word2">Implements</div>
                      <div class="word3">Harvestors</div>
                    </div>
                  </h1>
                    </div>
                </div>
            </div>
          
<div class="Emaillbar">

    <button class="EmaillButton" type="button">
    <a href="Tractor.html">
    </a>&nbsp;
    <b>
    <font size="3" style="font-family:verdana">
        <?php
        echo "$EmailId";
        ?>
    </font>
    </b>
    </button>
    <div class="EmaillContent">
        <a href="Tractor.html">Profile</a>
        <a href="../Home.html">LogOut</a>    
    </div>
        </div>
        <br>
    <br>
    <header>
    <img src="../Images/Logo.jpg" alt="Logo.jpg" class="Logo1"/>
    <a href="../homeloggedin.html?UEmail=<?php echo "$EmailId";?>">
    <button class="button1" type="button">
    <img src="../Images/homelogo.jpg" class="homelogo">
    <b>
    <font size="5.75" style="font-family:verdana">
    Home
    </font><br>
    </b>
    </button>
    </a>&nbsp;
    
    <a href="AboutUS.html?UEmail=<?php echo "$EmailId";?>">
    <button class="button2" type="button">
    <img src="../Images/Abt.png" alt="Logo.jpg" class="abtlogo"/>
    
    <b>
    <font size="5.75" style="font-family:verdana">
    About Us
    </font>
    </b>
    </button>
    </a>&nbsp;
    <div class="Harvbar">
    <a href="harvester.php?UEmail=<?php echo "$EmailId";?>">
    <button class="HarButton" type="button">
    <img src="../Images/Harvestor.png" alt="Logo.jpg" class="abtlogo"/>
    
    <b>
    <font size="5.75" style="font-family:verdana">
    Harvestor</font>
    </b>
    </button>
    </a>&nbsp;
    
    <div class="HarvContent">
    <a href="harvester.php?UEmail=<?php echo "$EmailId";?>">Borrow</a>
    <a href="harv_lend_1.php?UEmail=<?php echo "$EmailId";?>">Lend</a>
    </div>
    </div>
    <div class="Implebar">
    
    <a href="implements.php?UEmail=<?php echo "$EmailId";?>">
    <button class="ImpleButton" type="button">
    <img src="../Images/Implements.png" alt="Logo.jpg" class="abtlogo"/>
    <b>
    <font size="5.75" style="font-family:verdana">
    Implements
    </font>
    </b>
    </button>
    </a>&nbsp;
    
    <div class="ImpleContent">
    <a href="Implements.php?UEmail=<?php echo "$EmailId";?>">Borrow</a>
    <a href="imple_lend_1.php?UEmail=<?php echo "$EmailId";?>">Lend</a>
    </div>
    </div>
    <div class="Tracbar">
    <a href="tractor.php?UEmail=<?php echo "$EmailId";?>">
    
    <button class="TracButton" type="button">
    <img src="../Images/Tractor.png" alt="Logo.jpg" class="abtlogo"/>
    <b>
    <font size="5.75" style="font-family:verdana">
    Tractor
    </font>
    </b>
    </button>
    </a>&nbsp;
    
    <div class="TracContent">
    <a href="tractor.php?UEmail=<?php echo "$EmailId";?>">Borrow</a>
    <a href="trac_lend_1.php?UEmail=<?php echo "$EmailId";?>">Lend</a>    
    </div>
    </div>
    <div class="Plantbar">
    
    <a href="PlantNutrition.php?UEmail=<?php echo "$EmailId";?>">
    
    <button class="PlantButton" type="button">
    <img src="../Images/PlantNutrition.png" alt="Logo.jpg" class="abtlogo"/>
    
    <b>
    <font size="5.75" style="font-family:verdana">
    Plant Nutrition
    </font>
    </b>
    </button>
    </a>&nbsp;
    <div class="PlantContent">
    <a href="Soil Health.php?UEmail=<?php echo "$EmailId";?>">Soil Health</a>
    <a href="Soilissue.php?UEmail=<?php echo "$EmailId";?>">Soil Issue</a>
    <a href="Nutritions.php?UEmail=<?php echo "$EmailId";?>">Nutrients</a>
    <a href="Elements.php?UEmail=<?php echo "$EmailId";?>">Element</a>
    <a href="pesticides.php?UEmail=<?php echo "$EmailId";?>">Pesticides</a>
    <a href="Crops.php?UEmail=<?php echo "$EmailId";?>">Crops</a>    
    <a href="Plant Growth.php?UEmail=<?php echo "$EmailId";?>">Plant Growth</a>
    <a href="Preventation.php?UEmail=<?php echo "$EmailId";?>">Preventation</a>
    </div>
    </div> 
    </header>
        <br>
        </header>
            <h1 class="elements">Major Elements</h1>
            <ab>
            <img src="../Images/Nutritions2.jpg" width="800px" height="250px">
            <img src="../Images/nutt.jpg" width="800px" height="250px">
            </ab>
            <br><br><br><br>
            <h2 class="para1">Nitrogen (N)</h2>
            <p class="para3">Nitrogen is a key element in plant growth. It is found in all plant cells, in plant proteins and hormones, and in chlorophyll. 

                Atmospheric nitrogen is a source of soil nitrogen. Some plants such as legumes fix atmospheric nitrogen in their roots; otherwise fertiliser factories use nitrogen from the air to make ammonium sulfate, ammonium nitrate and urea. When applied to soil, nitrogen is converted to mineral form, nitrate, so that plants can take it up. 
                
                Soils high in organic matter such as chocolate soils are generally higher in nitrogen than podzolic soils. Nitrate is easily leached out of soil by heavy rain, resulting in soil acidification. You need to apply nitrogen in small amounts often so that plants use all of it, or in organic form such as composted manure, so that leaching is reduced. </p>

                <h2 class="para1">Phosphorus (P)</h2>
            <p class="para3">Phosphorus helps transfer energy from sunlight to plants, stimulates early root and plant growth, and hastens maturity. 

                Very few Australian soils have enough phosphorus for sustained crop and pasture production and the North Coast is no exception. The most common phosphorus source on the North Coast is superphosphate, made from rock phosphate and sulfuric acid. All manures contain phosphorus; manure from grain-fed animals is a particularly rich source.  </p>

                <h2 class="para1">Potassium (K)</h2>
            <p class="para3">Potassium increases vigour and disease resistance of plants, helps form and move starches, sugars and oils in plants, and can improve fruit quality. 

                Potassium is low or deficient on many of the sandier soils of the North Coast. Also, heavy potassium removal can occur on soils used for intensive grazing and intensive horticultural crops (such as bananas and custard apples). 
                
                Muriate of potash and sulfate of potash are the most common sources of potassium.  </p>

                <h2 class="para1">Calcium (Ca) </h2>
            <p class="para3">Calcium is essential for root health, growth of new roots and root hairs, and the development of leaves. It is generally in short supply in the North Coast's acid soils. Lime, gypsum, dolomite and superphosphate (a mixture of calcium phosphate and calcium sulfate) all supply calcium. Lime is the cheapest and most suitable option for the North Coast; dolomite is useful for magnesium and calcium deficiencies, but if used over a long period will unbalance the calcium/magnesium ratio. Superphosphate is useful where calcium and phosphorus are needed.  </p>

                <h2 class="para1">Magnesium (Mg) </h2>
            <p class="para3">Magnesium is a key component of chlorophyll, the green colouring material of plants, and is vital for photosynthesis (the conversion of the sun's energy to food for the plant). Deficiencies occur mainly on sandy acid soils in high rainfall areas, especially if used for intensive horticulture or dairying. Heavy applications of potassium in fertilisers can also produce magnesium deficiency, so banana growers need to watch magnesium levels because bananas are big potassium users. 

                Magnesium deficiency can be overcome with dolomite (a mixed magnesium-calcium carbonate), magnesite (magnesium oxide) or epsom salts (magnesium sulfate).  </p>

                <h2 class="para1">Sulfur (S) </h2>
            <p class="para3">Sulfur is a constituent of amino acids in plant proteins and is involved in energy-producing processes in plants. It is responsible for many flavour and odour compounds in plants such as the aroma of onions and cabbage. 

                Sulfur deficiency is not a problem in soils high in organic matter, but it leaches easily. On the North Coast seaspray is a major source of atmospheric sulfur. Superphosphate, gypsum, elemental sulfur and sulfate of ammonia are the main fertiliser sources. 
                
                Trace elements </p>
             </body>
</html>