<?php   error_reporting(0);


if(isset($_POST['Name'])){
$servername = "localhost";
$username = "root";
$password = "";

$conn = mysqli_connect($servername, $username, $password );
if (!$conn){
    die("Sorry we failed to connect: " . mysqli_connect_error());
}
    //echo "Connection was successful";

    $Name = $_POST['Name'];
    $MobileNumber = $_POST['MobileNumber'];
    $State = $_POST['State'];
    $District = $_POST['District'];
    $Tehsil = $_POST['Tehsil'];
    $Pincode = $_POST['Pincode']; 

    $sql="INSERT INTO `farmtech`.`tractor_lend` ( `Name`, `MobileNumber`, `State`, `District`, `Tehsil`,
     `Pincode`,`dt`) VALUES('$Name', '$MobileNumber', '$State', '$District', '$Tehsil', '$Pincode',current_timestamp());";
     

    if($conn->query($sql)==true){
        //echo"successfully inserted";
        header('Location: /PROFILE/Files/trac_lend_2_without.php');
    }else{
        // echo"ERROR: $sql<br> $conn->error";
    }
    
   
    }
    ?>
    
    
    




    
<!Doctype html>
<HTML lang="en">
    <head>
        <style>
            body{
                margin:0px;
            }
            .button1 {
                position:absolute;
                right: 1125px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button2 {
                position:absolute;
                right: 950px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button3 {
                position:absolute;
                right: 765px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;

            }
            .button4 {
                position:absolute;
                right:550px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button5 {
                position:absolute;
                right: 400px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button6 {
                position:absolute;
                right: 150px;
                cursor: pointer;
                margin-top: 35px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            .button7 {
                position:absolute;  
                right: 0px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 125px;
            } 
            .button8 {
                position:absolute;
                right:139px;
                cursor: pointer;
                margin-top: 35px;
            } 
            .button9 {
                position:absolute;
                right:8px;
                cursor: pointer;
                margin-top: 35px;
            }
            .button10 {
                position:absolute;  
                right: 10px;
                cursor: pointer;
                margin-top: 20px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
                margin-right: 20px;
            } 
            .Logo1 {
                height: 70px;
                width: 110px;
                margin:2px;
                margin-left:50px ;
                margin-top: 14px;
                border-radius: 20px;
                border:1px solid black;
                position: absolute;
            }
            header{
                background-color: aqua;
                height:100px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                margin-top:50px; 
            }
            .about1
            {
                text-align: center;
            }
           .aboutusbutton{
            padding:0px;
            border:none;
            background-color: white;
            margin:85px;
            margin-bottom: 45sspx;;
            cursor: pointer;
            border-radius: 10px;
           }
           .image{
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
           }
          .hr1{
            margin-left:150px;
            margin-right:150px;
          }
          .roles{
            margin-top: 50px;
            text-align: center;
          }
          #about2{
            font-weight:bolder;
          }
          .role{
             margin-left: 50px;;
          }
          .contant{
            margin-left: 100px;
          }
            .animate-charcter{
                text-transform: uppercase;
                background-image: linear-gradient(
                -225deg,
                #231557 0%,
                #44107a 29%,
                #ff1361 67%,
                #fff800 100%
                );
                background-size: auto auto;
                background-clip: border-box;
                background-size: 200% auto;
                color: #fff;
                background-clip: text;
                text-fill-color: transparent;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: textclip 2s linear infinite;
                display: inline-block;
                font-size: 28px;
                margin-top: 22px;
                margin-bottom: 10px;
                margin-left: 505px;
                position:absolute;
            }

            @keyframes textclip {
                to {
                background-position: 200% center;
                }
            }

            body {
                display: absolute;
                align-items: center;
                justify-content: center;
            }
            h1 {
                color: #160404;
                font-family: tahoma;
                font-size: 28px;
                font-weight :900px;
                text-transform: uppercase;
                overflow: hidden;
                position: absolute;
                width: 575px;
                margin-left: 575px;
                margin-top: 20px;
            }

            h1 span {
                font-size: 28px;
                margin-left: 115px;
                margin-top: 20px;
            }

            .message {
                background-color: rgb(244, 228, 84);
                color: #333;
                display: block;
                font-weight: 900px;
                overflow: hidden;
                font-size:28px;
                position: absolute;
                left: 350px;
                animation: openclose 5s ease-in-out infinite;
            }

            .word1, .word2, .word3 {
                font-family: tahoma;
            }

            @keyframes openclose {
                0% {
                    top: 0rem;
                    width: 0;
                }
                5% {
                    width: 40px;
                }
                15% {
                    width: 100px;
                }
                30% {
                    top: 0rem;
                    width: 160px;
                }
                33% {       
                    top: 0rem;
                    width: 0;
                }
                35% {
                    top: 0rem;
                    width: 0;
                }
                38% {
                top: -2.1rem;
    
                }
                48% {
                    top: -2.1rem;
                    width: 100px;
                }
                62% {
                    top: -2.1rem;
                    width: 200px;
                }
                66% {
                    top: -2.1rem;
                    width: 0;
                    text-indent: 0;
                }
                68% {
                    top: -2.1rem;   
                    width: 0;
                    text-indent: 0;
                }
                71% {
                    top: -4.2rem;
                    width: 0;
                }
                80% {
                    top: -4.2rem;
                    width: 100px;
                }
                95% {
                    top: -4.2rem;
                    width: 200px;
                }
                98% {
                    top: -4.2rem;
                    width: 0;
                }
                100% {
                    top: 0;
                    width: 0;
                }
            }  
                .homelogo {
                    height: 21px;
                    width: 21px;
                    border-radius: 20px;
                }
                .abtlogo{
                    height: 21px;
                    width: 21px;
                }
                form{
                    border: 1px solid black;
                    margin-left: 375px;
                    margin-top: 110px;
                    width: 800px;
                    height: 355px;
                    padding: 20px;
                    box-shadow: 0px 5px 10px black;
                }
                one{
                    display: flex;
                    margin-top:25px ;
                }
                one1,one2{
                    margin: 10px;
                }
                .input{
                    width:375px;
                    height: 30px;
                }
                h2{
                    text-align: center;
                    background-color: orange;
                    margin-left: -20px;
                    margin-right: -20px;
                    margin-top: -20px;
                    height:50px ;
                }
                .one{
                    margin: 0px;
                }a{
                    font-size: larger;
                }
                .atab{
                        border: 1px solid rgb(147, 144, 144);
                        padding: 3px;
                        text-decoration: none;
                        margin-top: 45px;
                        margin-left: 10px;
                        background-color: rgb(123, 251, 251);
                        color: black;
                }
                .at{
                 margin-left: 7px;
                 padding: 5px;
                 cursor: pointer;
                 background-color:rgb(127, 249, 249);
                 border: 1px solid rgb(147, 144, 144);
                }
                
            
            .HarButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }

            .Harvbar {
                
                right: 760px;
                position: absolute;
                display: inline-block;
            }

            .HarvContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .HarvContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .HarvContent a:hover {
                background-color: #ddd;
            }

            .Harvbar:hover .HarvContent {
                display: block;
            }

            .Harvbar:hover .HarButton {
                background-color: #3e8e41;
            }
            
            .ImpleButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Implebar {
                
                right: 550px;
                position: absolute;
                display: inline-block;
            }

            .ImpleContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .ImpleContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .ImpleContent a:hover {
                background-color: #ddd;
            }

            .Implebar:hover .ImpleContent {
                display: block;
            }

            .Implebar:hover .ImpleButton {
                background-color: #3e8e41;
            }

            .TracButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Tracbar {
                
                right: 400px;
                position: absolute;
                display: inline-block;
            }

            .TracContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .TracContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .TracContent a:hover {
                background-color: #ddd;
            }

            .Tracbar:hover .TracContent {
                display: block;
            }

            .Tracbar:hover .TracButton {
                background-color: #3e8e41;
            }

            .PlantButton {
                color: black;
                padding: 4px;
                font-size: 16px;
                margin-top: 33px;
                border-bottom:1px solid rgb(0, 0, 0);
                border-top: 1px solid rgb(0, 0, 0);
                border-left: 1px solid rgb(0, 0, 0);
                border-right: 1px solid rgb(0, 0, 0);
                border-radius: 20px;
            }
            
            .Plantbar {
                
                right: 150px;
                position: absolute;
                display: inline-block;
            }

            .PlantContent {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                text-align: center  ;
            }

            .PlantContent a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            .PlantContent a:hover {
                background-color: #ddd;
            }

            .Plantbar:hover .PlantContent {
                display: block;
            }

            .Plantbar:hover .PlantButton {
                background-color: #3e8e41;
            }
        </style>
        <meta charset="UTF-8">
        <title>
            Main Page
            </title>
            <link rel="icon" href="Logo.jpg">
        </head>
    <body>
            <div>
                <div>
                    <div">
                        <h3 class="animate-charcter"> Farm Tech:</h3>
                <h1>
                    <span>Lend/Borrow</span>
                    <div class="message">
                      <div class="word1">Tractors</div>
                      <div class="word2">Implements</div>
                      <div class="word3">Harvestors</div>
                    </div>
                  </h1>
                    </div>
                </div>
            </div>
            

<a href="Login.php">
    <button class="button7" type="button">
    <b> 
    <font size="4" style="font-family:verdana">
        Login
    </font>
    </b>
    </button>
</a>&nbsp;
            <a href="signin.php">
    <button class="button10" type="button">
    <b> 
    <font size="4" style="font-family:verdana">
        Sign in
    </font>
    </b>
    </button>
</a>&nbsp;  
<header>
    <img src="../Images/Logo.jpg" alt="Logo.jpg" class="Logo1"/>
    <a href=../Home.html>
        <button class="button1" type="button">
        <img src="../Images/homelogo.jpg" class="homelogo">
        <b>
        <font size="5.75" style="font-family:verdana">
            Home
        </font><br>
        </b>
        </button>
    </a>&nbsp;

    <a href=AboutUS.html>
        <button class="button2" type="button">
        <img src="../Images/Abt.png" alt="Logo.jpg" class="abtlogo"/>

        <b>
        <font size="5.75" style="font-family:verdana">
            About Us
        </font>
        </b>
        </button>
    </a>&nbsp;
    <div class="Harvbar">
    <a href="harvester.php">
        <button class="HarButton" type="button">
        <img src="../Images/Harvestor.png" alt="Logo.jpg" class="abtlogo"/>

        <b>
        <font size="5.75" style="font-family:verdana">
            Harvestor</font>
        </b>
        </button>
        </a>&nbsp;

        <div class="HarvContent">
        <a href="harvester.php">Borrow</a>
        <a href="harv_lend_1.php">Lend</a>
    </div>
        </div>
        <div class="Implebar">
    
    <a href="implements.php">
        <button class="ImpleButton" type="button">
        <img src="../Images/Implements.png" alt="Logo.jpg" class="abtlogo"/>
        <b>
        <font size="5.75" style="font-family:verdana">
            Implements
        </font>
        </b>
        </button>
    </a>&nbsp;

    <div class="ImpleContent">
        <a href="Implements.php">Borrow</a>
        <a href="imple_lend_1.php">Lend</a>
    </div>
        </div>
        <div class="Tracbar">
    <a href="tractor.php">

        <button class="TracButton" type="button">
        <img src="../Images/Tractor.png" alt="Logo.jpg" class="abtlogo"/>
        <b>
        <font size="5.75" style="font-family:verdana">
            Tractor
        </font>
        </b>
        </button>
    </a>&nbsp;

        <div class="TracContent">
            <a href="tractor.php">Borrow</a>
            <a href="trac_lend_1.php">Lend</a>    
        </div>
            </div>
            <div class="Plantbar">

    <a href="PlantNutrition.html">

        <button class="PlantButton" type="button">
        <img src="../Images/PlantNutrition.png" alt="Logo.jpg" class="abtlogo"/>
        
<b>
    <font size="5.75" style="font-family:verdana">
        Plant Nutrition
    </font>
    </b>
    </button>
</a>&nbsp;
<div class="PlantContent">
    <a href="Soil Health.html">Soil Health</a>
    <a href="Soilissue.html">Soil Issue</a>
    <a href="Nutritions.html">Nutrients</a>
    <a href="Elements.html">Element</a>
    <a href="pesticides.html">Pesticides</a>
    <a href="Crops.html">Crops</a>    
    <a href="Plant Growth.html">Plant Growth</a>
    <a href="Preventation.html">Preventation</a>
</div>
</div> </header>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
            </form>
        <form action ="trac_lend_1_without.php" method ="post">
            <main>
                <h2><a class="a">Personal Information</a></h2>
            <one>
            <one1>
           <p class="one">Name:*</p>
           <input  type="text" name ="Name" id="Name" placeholder="Name" class="input" required>
           </one1>
           <one2>
           <p class="one">Mobile Number:*</p>
           <input type="number" name ="MobileNumber" id="MobileNumber" placeholder="Mobile Number" class="input"  required>
           </one2>
           </one>
           <one>
            <one1>
           <p class="one">State:*</p>
           <input type="text" name ="State" id="State" placeholder="State" class="input"  required>
        </one1>
         <one2>
           <p class="one">District:*</p>
           <input type="text" name ="District" id="District"placeholder="District" class="input"  required>
        </one2>
    </one>
    <one>
        <one1>
           <p class="one">Tehsil:*</p>
           <input type="text" name ="Tehsil" id="Tehsil"placeholder="Tehsil"  class="input" required>
           </one1>
           <one2>
           <p class="one">Pincode:*</p>
           <input type="number"name ="Pincode" id="Pincode" placeholder="Pincode" class="input"  required>
           </one2>
           </one>
           <input type="submit" value="submit" class="at">
           
        </main>
           </form>
           </form>
        </body>
    </html>